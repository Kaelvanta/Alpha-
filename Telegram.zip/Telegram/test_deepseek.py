
#!/usr/bin/env python3
"""
CoreVanta AI - DeepSeek Test Script
Tests DeepSeek reasoning engine functionality
— Kael Vanta ®️
"""

import os
import asyncio
from handlers.deepseek import DeepSeekEngine

async def test_deepseek():
    """Test DeepSeek reasoning functionality"""
    
    # Use environment variables for any required keys
    bot_token = os.getenv("BOT_TOKEN")
    if not bot_token:
        print("❌ BOT_TOKEN not configured in environment")
        return False
    
    try:
        # Initialize DeepSeek engine
        engine = DeepSeekEngine()
        
        # Test query
        test_query = "explain quantum superposition"
        
        print("🧠 Testing DeepSeek reasoning engine...")
        print(f"Query: {test_query}")
        
        # This would normally test the engine
        # Implementation depends on your DeepSeek setup
        print("✅ DeepSeek engine loaded successfully")
        
        return True
        
    except Exception as e:
        print(f"❌ DeepSeek test failed: {e}")
        return False

if __name__ == "__main__":
    print("🔍 CoreVanta AI - DeepSeek Test")
    print("=" * 40)
    
    success = asyncio.run(test_deepseek())
    
    if success:
        print("✅ DeepSeek module ready")
    else:
        print("❌ DeepSeek module needs attention")

"""
COREVANTA AI - Sports Module (Fixed & Enhanced)
Multi-source sports data with progressive matching and robust error handling
— Kael Vanta ®️
"""

import os
import time
import logging
import aiohttp
import asyncio
import re
import json
from cachetools import TTLCache
from urllib.parse import quote_plus
from datetime import datetime
from typing import Dict, List, Optional, Any

# Security: ALL API keys from environment variables ONLY
API_FOOTBALL_KEY = os.getenv("API_FOOTBALL_KEY")
THESPORTSDB_KEY = os.getenv("THESPORTSDB_KEY")
SERPAPI_KEY = os.getenv("SERPAPI_KEY")
BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_TELEGRAM_ID = int(os.getenv("ADMIN_TELEGRAM_ID", "7976711112"))
CACHE_TTL_SECS = int(os.getenv("CACHE_TTL_SECS", "3600"))
SPORTS_RATE_LIMIT_PER_HOUR = int(os.getenv("SPORTS_RATE_LIMIT_PER_HOUR", "30"))

# Initialize secure caching and rate limiting
sports_cache = TTLCache(maxsize=1000, ttl=CACHE_TTL_SECS)
user_requests = {}

logger = logging.getLogger("corevanta.sports")
logger.setLevel(logging.INFO)

class SportsEngine:
    """Enhanced sports engine with progressive matching"""

    def __init__(self):
        self.session = None
        self.apifootball_base = "https://v3.football.api-sports.io"
        self.thesportsdb_base = "https://www.thesportsdb.com/api/v1/json/3"

    async def get_session(self) -> aiohttp.ClientSession:
        """Get or create HTTP session"""
        if not self.session:
            self.session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=10),
                headers={"User-Agent": "CoreVanta-AI/3.0"}
            )
        return self.session

    def normalize_team_name(self, query: str) -> str:
        """Normalize team name for better matching"""
        query = re.sub(r'\s+', ' ', query.strip())
        query = re.sub(r'[^\w\s\-&\']', '', query)
        return query

    def generate_team_variants(self, query: str) -> List[str]:
        """Generate multiple variants of team name to try"""
        base = self.normalize_team_name(query)
        variants = [base]

        # Add common suffixes
        suffixes = ["FC", "F.C.", "AFC", "SC", "Club", "United", "City"]
        for suffix in suffixes:
            if not base.upper().endswith(suffix):
                variants.append(f"{base} {suffix}")

        # Add national team variants
        if "national" not in base.lower():
            variants.extend([
                f"{base} national team",
                f"{base} national"
            ])

        # Remove duplicates while preserving order
        seen = set()
        unique_variants = []
        for variant in variants:
            if variant.lower() not in seen:
                seen.add(variant.lower())
                unique_variants.append(variant)

        return unique_variants[:5]  # Limit to prevent too many requests

    async def api_football_search(self, query: str) -> Optional[Dict]:
        """Enhanced API-Football search"""
        if not API_FOOTBALL_KEY:
            return None

        session = await self.get_session()
        headers = {"x-apisports-key": API_FOOTBALL_KEY}
        variants = self.generate_team_variants(query)

        for variant in variants:
            try:
                url = f"{self.apifootball_base}/teams"
                params = {"search": variant}

                async with session.get(url, headers=headers, params=params) as response:
                    if response.status == 200:
                        data = await response.json()
                        teams = data.get("response", [])

                        if teams:
                            team_data = teams[0]
                            team_info = team_data.get("team", {})
                            venue_info = team_data.get("venue", {})

                            return {
                                "source": "API-Football",
                                "variant_matched": variant,
                                "data": {
                                    "id": team_info.get("id"),
                                    "name": team_info.get("name"),
                                    "country": team_info.get("country"),
                                    "founded": team_info.get("founded"),
                                    "national": team_info.get("national", False),
                                    "logo": team_info.get("logo"),
                                    "venue": venue_info.get("name"),
                                    "venue_capacity": venue_info.get("capacity")
                                }
                            }

                    elif response.status in [401, 403]:
                        logger.error(f"API-Football: Authentication error ({response.status})")
                        return None

                    elif response.status == 429:
                        logger.warning("API-Football: Rate limited")
                        await asyncio.sleep(1)

            except Exception as e:
                logger.error(f"API-Football error for '{variant}': {e}")
                continue

        return None

    async def thesportsdb_search(self, query: str) -> Optional[Dict]:
        """TheSportsDB fallback search"""
        session = await self.get_session()
        variants = self.generate_team_variants(query)

        for variant in variants:
            try:
                url = f"{self.thesportsdb_base}/searchteams.php"
                params = {"t": variant}

                async with session.get(url, params=params) as response:
                    if response.status == 200:
                        data = await response.json()
                        teams = data.get("teams")

                        if teams:
                            team = teams[0]
                            return {
                                "source": "TheSportsDB",
                                "variant_matched": variant,
                                "data": {
                                    "id": team.get("idTeam"),
                                    "name": team.get("strTeam"),
                                    "country": team.get("strCountry"),
                                    "league": team.get("strLeague"),
                                    "founded": team.get("intFormedYear"),
                                    "stadium": team.get("strStadium"),
                                    "description": team.get("strDescriptionEN"),
                                    "website": team.get("strWebsite")
                                }
                            }

            except Exception as e:
                logger.error(f"TheSportsDB error for '{variant}': {e}")
                continue

        return None

    async def close_session(self):
        """Close HTTP session"""
        if self.session:
            await self.session.close()
            self.session = None

# Initialize engine
sports_engine = SportsEngine()

def check_rate_limit(user_id: int) -> bool:
    """Check if user has exceeded rate limit"""
    now = time.time()
    hour_ago = now - 3600

    # Clean old requests
    if user_id in user_requests:
        user_requests[user_id] = [
            req_time for req_time in user_requests[user_id]
            if req_time > hour_ago
        ]
    else:
        user_requests[user_id] = []

    # Check limit
    if len(user_requests[user_id]) >= SPORTS_RATE_LIMIT_PER_HOUR:
        return False

    user_requests[user_id].append(now)
    return True

def format_sports_response(result: Dict, query: str) -> str:
    """Format the final response"""
    if not result:
        return f"""🔥 <b>SPORTS ENGINE</b>

<b>Query:</b> {query}
<b>Status:</b> No data found

We searched multiple sources but couldn't find reliable data for this team.

<b>Try:</b>
• Full official name (e.g., "Arsenal FC")
• Different spelling variations
• /fixtures for league information

— Kael Vanta ®️"""

    source = result.get("source", "Unknown")
    variant_matched = result.get("variant_matched", query)
    data = result.get("data", {})

    if source == "API-Football":
        team_name = data.get("name", query)
        return f"""🔥 <b>SPORTS:</b> {team_name.upper()}

<b>✅ FOUND via API-Football</b>

<b>📊 TEAM INFO:</b>
• Name: {team_name}
• Country: {data.get('country', 'Unknown')}
• Founded: {data.get('founded', 'Unknown')}
• Stadium: {data.get('venue', 'Unknown')}
• Type: {"National Team" if data.get('national') else "Club"}

<b>🔍 SEARCH:</b> "{query}" → "{variant_matched}"

<b>⚽ NEXT ACTIONS:</b>
• /fixtures {team_name} — Upcoming matches
• /next {team_name} — Next match details
• /score — Live scores

— Kael Vanta ®️"""

    elif source == "TheSportsDB":
        team_name = data.get("name", query)
        return f"""🔥 <b>SPORTS:</b> {team_name.upper()}

<b>✅ FOUND via TheSportsDB</b>

<b>📊 TEAM INFO:</b>
• Name: {team_name}
• Country: {data.get('country', 'Unknown')}
• League: {data.get('league', 'Unknown')}
• Founded: {data.get('founded', 'Unknown')}
• Stadium: {data.get('stadium', 'Unknown')}

<b>🔍 SEARCH:</b> "{query}" → "{variant_matched}"

<b>🌐 WEBSITE:</b> {data.get('website', 'N/A')}

— Kael Vanta ®️"""

    return f"🔥 Sports data temporarily unavailable. Try again!\n\n— Kael Vanta ®️"

# Command Handlers
async def handle_sports_command(message):
    """Enhanced sports command handler with proper error handling"""
    try:
        user_id = message.from_user.id if message.from_user else 0

        # Rate limiting check
        if not check_rate_limit(user_id):
            await message.answer(
                f"⚡ <b>RATE LIMIT</b>\n\n"
                f"Too many requests. Wait a bit! ⚽\n\n"
                f"— Kael Vanta ®️"
            )
            return

        # Parse command
        text_parts = message.text.split()[1:] if message.text else []

        if not text_parts:
            await message.answer(
                "🏈 <b>SPORTS COMMAND</b>\n\n"
                "<b>Usage:</b>\n"
                "• /sports [team] — Team snapshot\n"
                "• /sports Ghana — National team\n"
                "• /sports Arsenal — Club info\n"
                "• /sports Chelsea — Premier League club\n\n"
                "— Kael Vanta ®️"
            )
            return

        query = " ".join(text_parts).strip()
        if not query:
            await message.answer("Please provide a team name to search for.\n\n— Kael Vanta ®️")
            return

        # Check cache
        cache_key = f"sports:{query.lower()}"
        if cache_key in sports_cache:
            await message.answer(sports_cache[cache_key])
            return

        # Send typing indicator
        try:
            await message.chat.send_action("typing")
        except Exception:
            pass

        # Search for sports data
        result = None

        # Try API-Football first
        if API_FOOTBALL_KEY:
            result = await sports_engine.api_football_search(query)

        # Fallback to TheSportsDB
        if not result:
            result = await sports_engine.thesportsdb_search(query)

        # Format and send response
        response_text = format_sports_response(result, query)

        # Cache successful responses
        if result:
            sports_cache[cache_key] = response_text

        await message.answer(response_text)

        logger.info(f"Sports query processed: '{query}' (user: {user_id}, source: {result.get('source') if result else 'none'})")

    except Exception as e:
        logger.error(f"Sports command error: {e}")
        await message.answer(
            "🔥 Sports engine temporarily overloaded. Try again!\n\n"
            "— Kael Vanta ®️"
        )

async def handle_football_command(message):
    """Football alias - redirect to sports command"""
    try:
        # Create a modified message for sports command
        modified_text = message.text.replace("/football", "/sports", 1)

        # Create a simple object to pass the modified text
        class ModifiedMessage:
            def __init__(self, original_message, new_text):
                self.text = new_text
                self.from_user = original_message.from_user
                self.chat = original_message.chat
                self.answer = original_message.answer

        modified_message = ModifiedMessage(message, modified_text)
        await handle_sports_command(modified_message)

    except Exception as e:
        logger.error(f"Football command error: {e}")
        await message.answer("⚽ Football lookup failed!\n\n— Kael Vanta ®️")

async def handle_fixtures_command(message):
    """Fixtures handler"""
    await message.answer(
        "🔥 <b>FIXTURES</b>\n\n"
        "Fixtures temporarily unavailable!\n\n"
        "— Kael Vanta ®️"
    )

async def handle_next_command(message):
    """Next match handler"""
    await message.answer(
        "⚡ <b>NEXT MATCH</b>\n\n"
        "Next match lookup failed!\n\n"
        "— Kael Vanta ®️"
    )

async def handle_score_command(message):
    """Score handler"""
    await message.answer(
        "🏆 <b>SCORE LOOKUP</b>\n\n"
        "Live scoring system coming soon!\n"
        "Use /sports [team] for latest results.\n\n"
        "— Kael Vanta ®️"
    )

async def handle_standings_command(message):
    """Standings handler"""
    await message.answer(
        "📊 <b>LEAGUE STANDINGS</b>\n\n"
        "Advanced standings system coming soon!\n"
        "Use /sports [league] for overview.\n\n"
        "— Kael Vanta ®️"
    )

# Export handlers
SPORTS_HANDLERS = {
    "sports": handle_sports_command,
    "football": handle_football_command,
    "fixtures": handle_fixtures_command,
    "next": handle_next_command,
    "score": handle_score_command,
    "standings": handle_standings_command
}

logger.info("CoreVanta Sports Module loaded - Enhanced with error handling")
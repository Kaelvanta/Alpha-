
import os
import asyncio
import logging
import re
from datetime import datetime
from aiogram import types
from aiogram.types import Message
from aiogram.enums import ChatAction

# Azure AI Inference
try:
    from azure.ai.inference import ChatCompletionsClient
    from azure.ai.inference.models import SystemMessage, UserMessage
    from azure.core.credentials import AzureKeyCredential
    AZURE_AVAILABLE = True
except ImportError:
    AZURE_AVAILABLE = False

# Fallback imports
from keys import api_manager
from memory import log_error, add_message

log = logging.getLogger(__name__)

# Environment variables
AZURE_KEY = os.getenv("AZURE_KEY")
AZURE_ENDPOINT = os.getenv("AZURE_ENDPOINT") 
AZURE_MODEL = os.getenv("AZURE_MODEL", "microsoft/Phi-4-reasoning")
SERPAPI_KEY = os.getenv("SERPAPI_KEY")
ADMIN_TELEGRAM_ID = int(os.getenv("ADMIN_TELEGRAM_ID", "7976711112"))

class DeepSeekProcessor:
    def __init__(self):
        self.azure_client = None
        if AZURE_AVAILABLE and AZURE_KEY and AZURE_ENDPOINT:
            try:
                self.azure_client = ChatCompletionsClient(
                    endpoint=AZURE_ENDPOINT,
                    credential=AzureKeyCredential(AZURE_KEY)
                )
            except Exception as e:
                log.error(f"Failed to initialize Azure client: {e}")

    def parse_flags(self, text: str):
        """Parse command flags and modes"""
        flags = {
            'mode': 'deep',  # default
            'sources': '--sources' in text,
            'no_reasoning': '--no-reasoning' in text or 'brief' in text.lower()
        }
        
        # Extract mode
        if 'quick' in text.lower():
            flags['mode'] = 'quick'
        elif 'explain' in text.lower():
            flags['mode'] = 'explain'
        elif 'chain' in text.lower():
            flags['mode'] = 'chain'
        
        # Clean query (remove flags)
        query = re.sub(r'--\w+', '', text).strip()
        query = re.sub(r'\b(quick|deep|explain|chain|brief)\b', '', query, flags=re.IGNORECASE).strip()
        
        return query, flags

    def build_system_message(self, mode: str):
        """Build system message based on reasoning mode"""
        base_prompt = (
            "You are DeepSeek — Kael Vanta's advanced reasoning assistant. "
            "Be confident, sharp, and methodical in your analysis."
        )
        
        if mode == 'quick':
            return SystemMessage(content=f"{base_prompt} Provide concise, direct answers.")
        elif mode == 'explain':
            return SystemMessage(content=f"{base_prompt} Include detailed reasoning steps and explanations.")
        elif mode == 'chain':
            return SystemMessage(content=f"{base_prompt} Use chain-of-thought reasoning with clear logical connections.")
        else:  # deep (default)
            return SystemMessage(content=(
                f"{base_prompt} "
                "Structure your response as: "
                "1) QUICK ANSWER (1-2 sentences), "
                "2) DEEP DIVE (numbered step-by-step reasoning), "
                "3) ASSUMPTIONS & CAVEATS, "
                "4) CONFIDENCE level with justification."
            ))

    async def search_web(self, query: str, limit: int = 3):
        """Perform web search if SERPAPI available"""
        if not SERPAPI_KEY:
            return []
        
        try:
            import requests
            params = {
                'q': query,
                'api_key': SERPAPI_KEY,
                'num': limit,
                'engine': 'google'
            }
            response = requests.get('https://serpapi.com/search', params=params, timeout=10)
            if response.status_code == 200:
                data = response.json()
                results = []
                for result in data.get('organic_results', [])[:limit]:
                    results.append({
                        'title': result.get('title', ''),
                        'link': result.get('link', ''),
                        'snippet': result.get('snippet', '')
                    })
                return results
        except Exception as e:
            log.error(f"Web search failed: {e}")
        
        return []

    async def get_fallback_response(self, query: str, mode: str):
        """Fallback reasoning using available APIs"""
        try:
            # Use existing API manager
            base_url, api_key, model, api_name = api_manager.get_api_config("code_helper")
            
            if not api_key:
                return self.get_emergency_fallback(query)

            import httpx
            
            system_prompt = f"You are a reasoning assistant. Analyze: {query}"
            if mode == 'deep':
                system_prompt += " Provide step-by-step reasoning with assumptions and confidence level."
            
            headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": query}
                ],
                "max_tokens": 800,
                "temperature": 0.7
            }
            
            async with httpx.AsyncClient(timeout=30) as client:
                response = await client.post(f"{base_url}/chat/completions", json=payload, headers=headers)
                
                if response.status_code == 200:
                    data = response.json()
                    return data['choices'][0]['message']['content']
                    
        except Exception as e:
            log.error(f"Fallback API failed: {e}")
        
        return self.get_emergency_fallback(query)

    def get_emergency_fallback(self, query: str):
        """Emergency fallback when all APIs fail"""
        return (
            f"**EMERGENCY REASONING MODE**\n\n"
            f"Query: {query}\n\n"
            f"**Analysis:** This appears to be a complex topic requiring systematic analysis. "
            f"Without access to reasoning models, I recommend:\n"
            f"1) Breaking down the question into smaller parts\n"
            f"2) Researching reliable sources\n"
            f"3) Considering multiple perspectives\n\n"
            f"**Status:** Primary reasoning systems offline. Try again later or contact admin.\n"
            f"**Confidence:** Low — Emergency mode active"
        )

    async def format_response(self, content: str, query: str, sources: list = None, model_used: str = "Azure"):
        """Format response in Kael Vanta style"""
        header = f"🔥 **DEEPSEEK:** {query}\n\n"
        
        # Add sources if available
        if sources:
            sources_text = "\n**SOURCES:**\n"
            for source in sources:
                sources_text += f"• [{source['title']}]({source['link']}) — {source['snippet'][:100]}...\n"
            content += f"\n{sources_text}"
        
        # Add model attribution
        footer = f"\n\n**Model:** {model_used}\n— Kael Vanta ®️"
        
        return header + content + footer

    async def log_to_admin(self, bot, query: str, model_used: str, status: str, latency: float):
        """Send telemetry to admin"""
        try:
            trimmed_query = query[:100] + "..." if len(query) > 100 else query
            admin_msg = (
                f"🧠 **DeepSeek Usage**\n\n"
                f"**Query:** {trimmed_query}\n"
                f"**Model:** {model_used}\n"
                f"**Status:** {status}\n"
                f"**Latency:** {latency:.2f}s\n"
                f"**Time:** {datetime.now().strftime('%H:%M:%S')}"
            )
            
            await bot.send_message(
                chat_id=ADMIN_TELEGRAM_ID,
                text=admin_msg,
                parse_mode="Markdown"
            )
        except Exception as e:
            log.error(f"Failed to send admin log: {e}")

# Initialize processor
deepseek = DeepSeekProcessor()

async def deepseek_handler(message: Message, bot):
    """Main DeepSeek handler"""
    start_time = datetime.now()
    user_id = message.from_user.id
    
    # Parse command
    command_text = message.text
    if command_text.startswith('/deepseek'):
        query = command_text[9:].strip()
    elif command_text.startswith('/think'):
        query = command_text[6:].strip()
    else:
        query = ""
    
    if not query:
        await message.answer(
            "🧠 **DeepSeek Ready** — What should I analyze?\n\n"
            "**Examples:**\n"
            "• /deepseek who is the president of Ghana?\n"
            "• /think explain quantum superposition --sources\n"
            "• /deepseek plan a 4-week Rust learning path\n\n"
            "**Modes:** quick, deep, explain, chain, brief\n"
            "**Flags:** --sources, --no-reasoning\n\n"
            "— Kael Vanta ®️"
        )
        return

    # Parse flags and modes
    clean_query, flags = deepseek.parse_flags(query)
    
    # Send initial typing indicator
    await message.chat.send_action(ChatAction.TYPING)
    
    # Send quick placeholder
    thinking_msg = await message.answer("⚡ **DeepSeek:** Analyzing... (quick answer incoming)")
    
    try:
        # Web search if requested
        sources = []
        if flags['sources']:
            sources = await deepseek.search_web(clean_query)
        
        model_used = "Unknown"
        
        # Primary: Azure AI Inference
        if deepseek.azure_client:
            try:
                system_msg = deepseek.build_system_message(flags['mode'])
                user_instruction = (
                    f"{clean_query}\n\n"
                    f"Format: QUICK ANSWER (1-2 sentences), then DEEP DIVE (numbered steps), "
                    f"ASSUMPTIONS, CONFIDENCE (High/Medium/Low with reason)."
                )
                user_msg = UserMessage(content=user_instruction)
                
                response = deepseek.azure_client.complete(
                    messages=[system_msg, user_msg],
                    model=AZURE_MODEL,
                    temperature=0.7,
                    max_tokens=1200
                )
                
                content = response.choices[0].message.content
                model_used = f"Azure {AZURE_MODEL}"
                
            except Exception as e:
                log.error(f"Azure DeepSeek failed: {e}")
                raise  # Fall to backup
        else:
            raise Exception("Azure not configured")
            
    except Exception as e:
        # Fallback to secondary APIs
        log.error(f"Primary DeepSeek failed: {e}")
        content = await deepseek.get_fallback_response(clean_query, flags['mode'])
        model_used = "Fallback API"
        
        # Inform user about fallback
        await message.answer("⚠️ Primary reasoning model failed — using fallback system...")
    
    # Calculate latency
    latency = (datetime.now() - start_time).total_seconds()
    
    # Format final response
    formatted_response = await deepseek.format_response(
        content, clean_query, sources, model_used
    )
    
    # Update or send new message
    try:
        await thinking_msg.edit_text(formatted_response, parse_mode="Markdown")
    except Exception:
        await message.answer(formatted_response, parse_mode="Markdown")
    
    # Log interaction
    add_message(user_id, "user", f"/deepseek {clean_query}")
    add_message(user_id, "assistant", formatted_response)
    
    # Send admin telemetry
    status = "SUCCESS" if model_used.startswith("Azure") else "FALLBACK"
    await deepseek.log_to_admin(bot, clean_query, model_used, status, latency)

"""
UNIT TEST EXAMPLES:

Test Case 1: Basic reasoning
Input: /deepseek who is the president of Ghana?
Expected: Quick answer within 2s, deep dive with numbered steps, CONFIDENCE: High/Medium/Low

Test Case 2: With sources
Input: /deepseek explain quantum superposition --sources
Expected: Deep dive + SOURCES section with URLs, confidence based on source quality

Test Case 3: Brief mode
Input: /deepseek brief explain photosynthesis
Expected: Only quick answer, no deep dive

Test Case 4: Azure failure simulation
Setup: Unset AZURE_KEY
Input: /deepseek test query
Expected: "Primary model failed — using fallback" message, fallback response

Test Case 5: Chain reasoning
Input: /think chain how does machine learning work?
Expected: Chain-of-thought format with logical connections between steps
"""

import os
import random
import asyncio
import time
from datetime import datetime # Added for failure tracking
from typing import Dict, List, Optional, Tuple

# Attempt to import logger from utils, create if not exists
try:
    from utils import logger
except ImportError:
    # Create utils directory and logger file if they don't exist
    if not os.path.exists('utils'):
        os.makedirs('utils')
    with open('utils/__init__.py', 'w') as f:
        pass # Make utils a package
    with open('utils/logger.py', 'w') as f:
        f.write("""
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def log_error(message):
    logging.error(message)

def log_info(message):
    logging.info(message)
""")
    from utils import logger

# Enhanced API Configuration with Failover Strategy
class APIManager:
    def __init__(self):
        self.apis = {
            "chatanywhere": {
                "base_url": "https://api.chatanywhere.org/v1",
                "key": os.getenv("CHATANYWHERE_API_KEY"),
                "models": {
                    "default_chat": "gpt-3.5-turbo",
                    "code_helper": "gpt-3.5-turbo",
                    "summarize": "gpt-3.5-turbo"
                },
                "timeout": 25,
                "last_failure": None,
                "failure_count": 0
            },
            "openrouter": {
                "base_url": "https://openrouter.ai/api/v1",
                "key": os.getenv("OPENROUTER_API_KEY"),
                "models": {
                    "default_chat": "meta-llama/llama-3.2-11b-vision-instruct:free",
                    "code_helper": "deepseek/deepseek-chat-v3-0324:free",
                    "summarize": "google/gemini-2.0-flash-exp:free"
                },
                "timeout": 25,
                "last_failure": None,
                "failure_count": 0
            },
            "gnews": {
                "base_url": "https://gnews.io/api/v4",
                "key": os.getenv("GNEWS_API_KEY"),
                "models": {
                    "news_search": "search",
                    "top_headlines": "top-headlines",
                    "everything": "everything"
                },
                "timeout": 15,
                "last_failure": None,
                "failure_count": 0
            }
        }

        self.preference_order = ["chatanywhere", "openrouter"]
        self.failover_errors = [401, 403, 429, 500, 502, 503, 504]
        self.retries_per_api = 2
        self.health_check_interval = 300  # 5 minutes

        # Failover tracking for health checks
        self.failure_tracking = {}
        self.max_failures = 3 # Max consecutive failures before marking as unhealthy
        self.reset_window = 300 # Time in seconds after which failure count resets


    def _is_api_healthy(self, api_name: str) -> bool:
        """Check if API is healthy based on failure tracking"""
        try:
            failure_data = self.failure_tracking.get(api_name, {})
            failure_count = failure_data.get("count", 0)
            last_failure = failure_data.get("last_failure")

            # Reset if last failure was more than reset_window ago
            if last_failure:
                time_since_failure = (datetime.now() - last_failure).total_seconds()
                if time_since_failure > self.reset_window:
                    self.failure_tracking[api_name] = {"count": 0, "last_failure": None}
                    return True

            return failure_count < self.max_failures
        except Exception as e:
            logger.log_error(f"Error in _is_api_healthy: {e}")
            return True # Assume healthy if an error occurs during check

    def _mark_api_failure(self, api_name: str):
        """Mark API as failed"""
        if api_name in self.apis:
            self.apis[api_name]["last_failure"] = time.time()
            self.apis[api_name]["failure_count"] = self.apis[api_name].get("failure_count", 0) + 1

    def _mark_api_success(self, api_name: str):
        """Mark API as successful"""
        if api_name in self.apis:
            self.apis[api_name]["failure_count"] = 0

    def get_api_config(self, task_type: str = "default_chat") -> Tuple[str, str, str, str]:
        """Get API configuration with enhanced failover logic"""
        # Normalize task type
        if task_type == "default":
            task_type = "default_chat"

        for api_name in self.preference_order:
            api_config = self.apis[api_name]

            # Check if API key exists and API is healthy
            if api_config["key"] and self._is_api_healthy(api_name):
                model = api_config["models"].get(task_type, api_config["models"]["default_chat"])
                return api_config["base_url"], api_config["key"], model, api_name

        # Fallback to old system if new APIs not configured
        base_url, key, model = self._get_legacy_api()
        return base_url, key, model, "legacy"

    def _get_legacy_api(self) -> Tuple[str, str, str]:
        """Fallback to legacy API keys for compatibility"""
        legacy_keys = {
            "meta-llama/llama-3.2-11b-vision-instruct:free": "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",
            "google/gemini-2.0-flash-exp:free": "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",
            "deepseek/deepseek-chat-v3-0324:free": "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",
            "microsoft/mai-ds-r1:free": "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"
        }

        if legacy_keys:
            model, key = random.choice(list(legacy_keys.items()))
            return "https://openrouter.ai/api/v1", key, model

        raise Exception("No API keys available")

    # Added methods for enhanced failover
    def get_available_api(self) -> Optional[Tuple[str, str, str, str]]:
        """Get the next available API for use"""
        try:
            for api_name in self.preference_order:
                if api_name in self.apis and self._is_api_healthy(api_name):
                    api_config = self.apis[api_name]
                    if api_config["key"]:
                        model = api_config["models"].get("default_chat", "gpt-3.5-turbo") # Default model if not specified
                        return (
                            api_config["base_url"],
                            api_config["key"],
                            model,
                            api_name
                        )
            return None
        except Exception as e:
            logger.log_error(f"get_available_api error: {e}")
            return None

    def mark_failure(self, api_name: str):
        """Mark an API failure"""
        try:
            if api_name not in self.failure_tracking:
                self.failure_tracking[api_name] = {"count": 0, "last_failure": None}

            self.failure_tracking[api_name]["count"] += 1
            self.failure_tracking[api_name]["last_failure"] = datetime.now()
        except Exception as e:
            logger.log_error(f"Error in mark_failure: {e}")

    def mark_success(self, api_name: str):
        """Mark an API success - optionally reset failure count"""
        try:
            if api_name in self.failure_tracking:
                # Reduce failure count on success
                current_count = self.failure_tracking[api_name].get("count", 0)
                if current_count > 0:
                    self.failure_tracking[api_name]["count"] = max(0, current_count - 1)
                # Optionally reset last_failure timestamp if count becomes 0
                if self.failure_tracking[api_name]["count"] == 0:
                     self.failure_tracking[api_name]["last_failure"] = None
        except Exception as e:
            logger.log_error(f"Error in mark_success: {e}")

# Initialize API Manager
api_manager = APIManager()

# Legacy compatibility - maintain existing API_KEYS for backward compatibility
API_KEYS = {
    "meta-llama/llama-3.2-11b-vision-instruct:free": "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",
    "google/gemini-2.0-flash-exp:free": "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",
    "deepseek/deepseek-chat-v3-0324:free": "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",
    "microsoft/mai-ds-r1:free": "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"
}

def get_api_for_task(task_type: str = "default_chat") -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
    """New unified API selector for enhanced features"""
    try:
        # Try to get from API manager first
        result = api_manager.get_available_api()
        if result:
            base_url, api_key, model, api_name = result
            return base_url, api_key, model, api_name

        # Fallback to legacy API_KEYS
        if API_KEYS:
            # Using a fixed model/key from legacy for simplicity if no better option
            # In a real scenario, this might be randomized or have more logic
            model, key = next(iter(API_KEYS.items()))
            return "https://openrouter.ai/api/v1", key, model, "legacy" # Assuming openrouter base URL for legacy

        # Final fallback if no APIs are configured
        logger.log_error("No API keys or configurations found.")
        return None, None, None, None

    except Exception as e:
        logger.log_error(f"get_api_for_task error: {e}")
        return None, None, None, None

def mark_api_failure(api_name: str):
    """Mark API as failed for failover management"""
    try:
        api_manager.mark_failure(api_name)
    except Exception as e:
        logger.log_error(f"Error in mark_api_failure: {e}")

def mark_api_success(api_name: str):
    """Mark API as successful"""
    try:
        api_manager.mark_success(api_name)
    except Exception as e:
        logger.log_error(f"Error in mark_api_success: {e}")


def check_secrets_configured() -> Dict[str, bool]:
    """Check which secrets are properly configured"""
    return {
        "CHATANYWHERE_API_KEY": bool(os.getenv("CHATANYWHERE_API_KEY")),
        "OPENROUTER_API_KEY": bool(os.getenv("OPENROUTER_API_KEY")),
        "GNEWS_API_KEY": bool(os.getenv("GNEWS_API_KEY")),
        "SERPAPI_API_KEY": bool(os.getenv("SERPAPI_API_KEY")),
        "BOT_TOKEN": bool(os.getenv("BOT_TOKEN"))
    }
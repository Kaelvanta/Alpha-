import json
import os
import shutil
from datetime import datetime

MEMORY_FILE = "memory.json"
BACKUP_DIR = "backups"

def create_backup(file_path):
    """Create backup before modifying files"""
    if not os.path.exists(BACKUP_DIR):
        os.makedirs(BACKUP_DIR)

    if os.path.exists(file_path):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{os.path.basename(file_path)}_{timestamp}.bak"
        backup_path = os.path.join(BACKUP_DIR, backup_name)
        shutil.copy2(file_path, backup_path)
        return backup_path
    return None

def load_memory():
    """Load conversation memory from file"""
    try:
        if os.path.exists("memory.json"):
            with open("memory.json", "r") as f:
                data = json.load(f)
                # Ensure data is a dictionary
                if isinstance(data, dict):
                    return data
                else:
                    log_error("Memory file corrupted - not a dict")
                    return {}
        return {}
    except json.JSONDecodeError as e:
        log_error(f"Memory JSON decode error: {e}")
        # Backup corrupted file
        try:
            create_backup("memory_json_error")
        except:
            pass
        return {}
    except Exception as e:
        log_error(f"Memory load error: {e}")
        return {}

def save_memory(memory):
    """Save memory with backup protection"""
    try:
        create_backup(MEMORY_FILE)
        with open(MEMORY_FILE, "w") as f:
            json.dump(memory, f, indent=2)
    except Exception as e:
        log_error(f"Memory save failed: {e}")

def add_message(user_id, role, content):
    """Add a message to user's conversation history"""
    try:
        memory = load_memory()
        user_key = str(user_id)

        # Initialize user data structure
        if user_key not in memory:
            memory[user_key] = {
                'messages': [],
                'preferences': {},
                'first_seen': datetime.now().isoformat(),
                'last_active': datetime.now().isoformat()
            }

        # Ensure messages is a list - fix corrupted data
        if 'messages' not in memory[user_key]:
            memory[user_key]['messages'] = []
        elif not isinstance(memory[user_key]['messages'], list):
            # Reset corrupted messages to empty list
            memory[user_key]['messages'] = []
            log_error(f"Reset corrupted messages for user {user_id}")

        # Add new message
        message = {
            'role': str(role),
            'content': str(content),
            'timestamp': datetime.now().isoformat()
        }

        memory[user_key]['messages'].append(message)
        memory[user_key]['last_active'] = datetime.now().isoformat()

        # Keep only last 50 messages per user
        if len(memory[user_key]['messages']) > 50:
            memory[user_key]['messages'] = memory[user_key]['messages'][-50:]

        save_memory(memory)

    except Exception as e:
        log_error(f"Add message error for user {user_id}: {e}")
        # Don't let memory errors break the bot
        pass

def get_conversation(user_id):
    """Get conversation history for a user"""
    try:
        memory = load_memory()
        user_data = memory.get(str(user_id), {})

        if not user_data or 'messages' not in user_data:
            return []

        messages = user_data['messages']

        # Ensure messages is a list
        if not isinstance(messages, list):
            return []

        # Convert to conversation format for AI
        conversation = []
        for msg in messages[-10:]:  # Last 10 messages
            if isinstance(msg, dict) and 'role' in msg and 'content' in msg:
                # Only include user and assistant messages for AI context
                if msg['role'] in ['user', 'assistant']:
                    conversation.append({
                        "role": msg['role'],
                        "content": str(msg['content'])
                    })

        return conversation
    except Exception as e:
        log_error(f"Get conversation error: {e}")
        return []

def set_user_preference(user_id, key, value):
    """Set user preferences"""
    memory = load_memory()
    user_id = str(user_id)

    if user_id not in memory:
        memory[user_id] = {"messages": [], "preferences": {}, "stats": {}}

    memory[user_id]["preferences"][key] = value
    save_memory(memory)

def get_user_preferences(user_id):
    """Get user preferences"""
    memory = load_memory()
    user_data = memory.get(str(user_id), {})
    return user_data.get("preferences", {})

def log_error(error_msg):
    """Log errors to file"""
    try:
        with open("error.log", "a") as f:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            f.write(f"[{timestamp}] {error_msg}\n")
    except:
        pass  # Silent fail for logging

#!/usr/bin/env python3
"""
PersonaForge Health Check
Run: python personaforge_health_check.py
"""

import asyncio
import json
from datetime import datetime
from core_features.personaforge import persona_health_check

async def main():
    """Run PersonaForge health check"""
    print("🏥 PersonaForge Health Check")
    print("=" * 40)
    
    health = await persona_health_check()
    
    # Status indicator
    status_emoji = {
        "healthy": "✅",
        "degraded": "⚠️", 
        "error": "❌"
    }
    
    print(f"{status_emoji.get(health['status'], '❓')} Status: {health['status'].upper()}")
    
    if health['status'] != 'error':
        print(f"📁 Personas file: {'✅' if health['personas_file_exists'] else '❌'}")
        print(f"👤 Total personas: {health['total_personas']}")
        print(f"📋 Templates: {health['templates_available']}")
        print(f"⚙️ Parameters: {health['parameters_defined']}")
    else:
        print(f"❌ Error: {health.get('error', 'Unknown error')}")
    
    print(f"🕐 Checked: {health['timestamp']}")
    
    # Return appropriate exit code
    return 0 if health['status'] in ['healthy', 'degraded'] else 1

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    exit(exit_code)

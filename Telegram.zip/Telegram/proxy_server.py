"""
CoreVanta AI - FastAPI Proxy Server
OpenAI-compatible API proxy with search capabilities
"""

import os
import logging
from typing import Dict, Any, Optional
from datetime import datetime

try:
    from fastapi import FastAPI, HTTPException, Request
    from fastapi.responses import JSONResponse
    from fastapi.middleware.cors import CORSMiddleware
    import uvicorn
    FASTAPI_AVAILABLE = True
except ImportError:
    FASTAPI_AVAILABLE = False
    logging.warning("FastAPI not available. Install with: pip install fastapi uvicorn")

# Import our custom routers
from groq_router import DEFAULT_ROUTER
from search_provider import search_provider

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="CoreVanta AI Proxy",
    description="OpenAI-compatible proxy with Groq routing and search capabilities",
    version="1.0.0"
)

# Add CORS middleware for web compatibility
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def status():
    """Root endpoint - service status"""
    return {
        "status": "CoreVanta Proxy Online",
        "timestamp": datetime.now().isoformat(),
        "version": "1.0.0",
        "services": {
            "groq_router": "available",
            "search_provider": "available",
            "proxy_server": "online"
        }
    }

@app.get("/health")
async def health_check():
    """Comprehensive health check"""
    try:
        groq_health = DEFAULT_ROUTER.health()
        search_health = search_provider.health_check()
        
        return {
            "status": "healthy",
            "timestamp": datetime.now().isoformat(),
            "components": {
                "groq_router": groq_health,
                "search_provider": search_health
            }
        }
    except Exception as e:
        logger.error(f"Health check error: {e}")
        raise HTTPException(status_code=500, detail=f"Health check failed: {str(e)}")

@app.post("/v1/chat/completions")
async def chat_completions(request: Request):
    """
    OpenAI-compatible chat completions endpoint
    Forwards requests to Groq router with model selection
    """
    try:
        # Parse request body
        body = await request.json()
        
        # Extract key parameters
        messages = body.get("messages", [])
        model = body.get("model", "llama31_fast")
        
        if not messages:
            raise HTTPException(status_code=400, detail="Messages are required")
        
        # Extract user message (last user message in conversation)
        user_message = None
        system_message = "You are CoreVanta AI, a helpful and intelligent assistant."
        
        for msg in messages:
            if msg.get("role") == "user":
                user_message = msg.get("content", "")
            elif msg.get("role") == "system":
                system_message = msg.get("content", system_message)
        
        if not user_message:
            raise HTTPException(status_code=400, detail="No user message found")
        
        # Map common OpenAI models to our Groq models
        model_mapping = {
            "gpt-3.5-turbo": "llama31_fast",
            "gpt-4": "llama4_scout",
            "gpt-4-turbo": "gpt_oss",
            "text-davinci-003": "llama31_fast"
        }
        
        groq_model = model_mapping.get(model, model)
        
        # Get response from Groq router
        response_text = DEFAULT_ROUTER.ask_text(
            prompt=user_message,
            model=groq_model,
            system_prompt=system_message
        )
        
        # Format as OpenAI-compatible response
        return {
            "id": f"chatcmpl-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "object": "chat.completion",
            "created": int(datetime.now().timestamp()),
            "model": model,
            "choices": [{
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": response_text
                },
                "finish_reason": "stop"
            }],
            "usage": {
                "prompt_tokens": len(user_message.split()),
                "completion_tokens": len(response_text.split()),
                "total_tokens": len(user_message.split()) + len(response_text.split())
            }
        }
        
    except Exception as e:
        logger.error(f"Chat completion error: {e}")
        raise HTTPException(status_code=500, detail=f"Chat completion failed: {str(e)}")

@app.get("/v1/search")
async def search_endpoint(q: str, max_results: int = 5):
    """
    Search endpoint using our search provider
    """
    try:
        if not q:
            raise HTTPException(status_code=400, detail="Query parameter 'q' is required")
        
        if max_results > 20:
            max_results = 20  # Limit to prevent abuse
        
        # Perform search
        results = search_provider.search(q, max_results)
        
        return {
            "query": q,
            "results_count": len(results),
            "results": results,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Search error: {e}")
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")

@app.get("/v1/models")
async def list_models():
    """List available models"""
    try:
        models = DEFAULT_ROUTER.list_models()
        
        # Format as OpenAI-compatible model list
        formatted_models = []
        for model in models:
            formatted_models.append({
                "id": model["nickname"],
                "object": "model", 
                "created": int(datetime.now().timestamp()),
                "owned_by": "corevanta-ai",
                "permission": [],
                "root": model["model"],
                "parent": None,
                "max_tokens": model.get("max_tokens", "1024"),
                "description": model.get("strengths", "")
            })
        
        return {
            "object": "list",
            "data": formatted_models
        }
        
    except Exception as e:
        logger.error(f"Models list error: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list models: {str(e)}")

@app.post("/v1/audio/transcriptions")
async def audio_transcriptions(request: Request):
    """Audio transcription endpoint (placeholder)"""
    try:
        # This would need actual file upload handling
        return {
            "text": "Audio transcription endpoint ready (file upload implementation needed)",
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Transcription error: {e}")
        raise HTTPException(status_code=500, detail=f"Transcription failed: {str(e)}")

# Error handlers
@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    return JSONResponse(
        status_code=404,
        content={
            "error": "Not Found",
            "message": f"Endpoint {request.url.path} not found",
            "available_endpoints": [
                "/",
                "/health", 
                "/v1/chat/completions",
                "/v1/search",
                "/v1/models",
                "/v1/audio/transcriptions"
            ]
        }
    )

@app.exception_handler(500)
async def internal_error_handler(request: Request, exc):
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal Server Error",
            "message": "An unexpected error occurred",
            "timestamp": datetime.now().isoformat()
        }
    )

def run_server(host: str = "0.0.0.0", port: int = 5000):
    """Run the proxy server"""
    if not FASTAPI_AVAILABLE:
        print("❌ FastAPI not available. Install with: pip install fastapi uvicorn")
        return
    
    print(f"🚀 Starting CoreVanta AI Proxy Server on {host}:{port}")
    print(f"📖 API Documentation: http://{host}:{port}/docs")
    print(f"🔍 Search API: http://{host}:{port}/v1/search?q=your_query")
    print(f"🤖 Chat API: http://{host}:{port}/v1/chat/completions")
    
    uvicorn.run(
        "proxy_server:app",
        host=host,
        port=port,
        reload=False,
        log_level="info"
    )

if __name__ == "__main__":
    # Run server for testing
    run_server()
import replicate
import requests
from io import BytesIO

# Your Replicate token
REPLICATE_API_TOKEN = "r8_DpAcTtQhCeQ3YM2acECTSH1Sl9CRo3G3VopsH"

# Setup Replicate
replicate_client = replicate.Client(api_token=REPLICATE_API_TOKEN)

def read_image_caption(image_url):
    try:
        output = replicate_client.run(
            "salesforce/blip:latest",
            input={"image": image_url}
        )
        return output
    except Exception as e:
        return f"❌ Error: {e}"
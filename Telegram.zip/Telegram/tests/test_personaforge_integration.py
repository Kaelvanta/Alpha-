
#!/usr/bin/env python3
"""
PersonaForge Integration Test
Run: python tests/test_personaforge_integration.py
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import asyncio
from unittest.mock import Mock
from core_features.personaforge import personaforge_main, create_persona_wizard

async def test_integration():
    """Test PersonaForge integration with bot"""
    print("🧪 Testing PersonaForge Integration...")
    
    # Mock message object
    mock_message = Mock()
    mock_message.from_user.id = 777777
    mock_message.answer = Mock(return_value=asyncio.Future())
    mock_message.answer.return_value.set_result(None)
    
    # Test 1: Main interface
    try:
        await personaforge_main(mock_message)
        print("✅ Main interface loads successfully")
    except Exception as e:
        print(f"❌ Main interface failed: {e}")
        return False
    
    # Test 2: Creation wizard
    try:
        await create_persona_wizard(mock_message)
        print("✅ Creation wizard loads successfully")
    except Exception as e:
        print(f"❌ Creation wizard failed: {e}")
        return False
    
    # Test 3: Check if answer was called
    if mock_message.answer.called:
        print("✅ Bot responses generated")
    else:
        print("❌ No bot responses generated")
        return False
    
    print("🎉 All Integration tests passed!")
    return True

if __name__ == "__main__":
    result = asyncio.run(test_integration())
    exit(0 if result else 1)


#!/usr/bin/env python3
"""
PersonaForge Application Test
Run: python tests/test_persona_application.py
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core_features.personaforge import (
    apply_persona_to_preferences, build_persona_prompt, 
    PERSONA_TEMPLATES, get_current_persona_name
)
from memory import get_user_preferences, set_user_preference

def test_persona_application():
    """Test persona application to user preferences"""
    print("🧪 Testing Persona Application...")
    
    test_user_id = 888888
    
    # Test 1: Apply template persona
    alpha_ceo = PERSONA_TEMPLATES["alpha_ceo"]
    apply_persona_to_preferences(test_user_id, alpha_ceo)
    
    # Verify preferences were set
    prefs = get_user_preferences(test_user_id)
    if prefs.get("tone") == "commanding":
        print("✅ Persona parameters applied successfully")
    else:
        print(f"❌ Persona application failed: {prefs}")
        return False
    
    # Test 2: Current persona tracking
    current = get_current_persona_name(test_user_id)
    if current == alpha_ceo["name"]:
        print("✅ Current persona tracking works")
    else:
        print(f"❌ Persona tracking failed: {current}")
        return False
    
    # Test 3: Prompt building
    prompt = build_persona_prompt(alpha_ceo)
    if "Alpha CEO" in prompt and "commanding" in prompt:
        print("✅ Persona prompt building successful")
    else:
        print(f"❌ Prompt building failed: {prompt[:100]}...")
        return False
    
    # Test 4: Template validation
    for template_name, template_data in PERSONA_TEMPLATES.items():
        required_fields = ["name", "description", "emoji", "params"]
        if all(field in template_data for field in required_fields):
            continue
        else:
            print(f"❌ Template {template_name} missing required fields")
            return False
    
    print("✅ All templates validated")
    print("🎉 All Persona Application tests passed!")
    return True

if __name__ == "__main__":
    result = test_persona_application()
    exit(0 if result else 1)

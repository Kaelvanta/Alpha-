
#!/usr/bin/env python3
"""
PersonaForge System Validation Test
Run: python tests/test_personaforge_system.py
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core_features.personaforge import PersonaForge, PERSONA_TEMPLATES, persona_health_check
import asyncio
import json

async def test_personaforge_system():
    """Test PersonaForge core functionality"""
    print("🧪 Testing PersonaForge System...")
    
    # Test 1: Initialize PersonaForge
    forge = PersonaForge()
    print("✅ PersonaForge initialized")
    
    # Test 2: Health check
    health = await persona_health_check()
    if health["status"] in ["healthy", "degraded"]:
        print(f"✅ Health check: {health['status']}")
    else:
        print(f"❌ Health check failed: {health}")
        return False
    
    # Test 3: Template loading
    if len(PERSONA_TEMPLATES) >= 5:
        print(f"✅ Templates loaded: {len(PERSONA_TEMPLATES)}")
    else:
        print(f"❌ Insufficient templates: {len(PERSONA_TEMPLATES)}")
        return False
    
    # Test 4: Save test persona
    test_persona = {
        "name": "Test Persona",
        "description": "Testing persona",
        "params": {"tone": "friendly", "style": "casual"}
    }
    
    if forge.save_persona(999999, "test_persona", test_persona):
        print("✅ Persona save successful")
    else:
        print("❌ Persona save failed")
        return False
    
    # Test 5: Load test persona
    loaded = forge.load_persona(999999, "test_persona")
    if loaded and loaded["name"] == "Test Persona":
        print("✅ Persona load successful")
    else:
        print("❌ Persona load failed")
        return False
    
    # Test 6: Delete test persona
    if forge.delete_persona(999999, "test_persona"):
        print("✅ Persona delete successful")
    else:
        print("❌ Persona delete failed")
        return False
    
    print("🎉 All PersonaForge tests passed!")
    return True

if __name__ == "__main__":
    result = asyncio.run(test_personaforge_system())
    exit(0 if result else 1)

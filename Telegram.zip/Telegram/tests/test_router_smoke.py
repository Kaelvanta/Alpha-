
# tests/test_router_smoke.py
import os
import sys
sys.path.append('..')
from model_router import ModelRouter

def test_registry_exists():
    r = ModelRouter()
    assert isinstance(r.list_models(), list)
    assert len(r.list_models()) >= 3
    print("✅ Registry exists with models")

def test_autoroute():
    r = ModelRouter()
    result = r.autoroute("write a python function")
    valid_models = ["alphacode", "deep_keal", "meta_ace", "alpha_vault", "elephant_money", "chatmoney"]
    assert result in valid_models
    print(f"✅ Autoroute works: {result}")

def test_unknown_model():
    r = ModelRouter()
    out = r.ask("does_not_exist", "hi", "sys")
    assert "Unknown model" in out
    print("✅ Unknown model handling works")

def test_model_info():
    r = ModelRouter()
    info = r.model_info("alphacode")
    assert "provider" in info
    assert "strengths" in info
    print("✅ Model info retrieval works")

if __name__ == "__main__":
    print("🧪 Running CoreVanta Router Smoke Tests...\n")
    
    try:
        test_registry_exists()
        test_autoroute()
        test_unknown_model()
        test_model_info()
        print("\n🎉 All smoke tests passed!")
    except Exception as e:
        print(f"\n❌ Test failed: {e}")

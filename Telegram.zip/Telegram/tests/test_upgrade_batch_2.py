
#!/usr/bin/env python3
"""
Comprehensive Test Suite for COREVANTA AI Upgrade Batch 2
Tests all newly implemented features with executable checks
"""
import asyncio
import json
import os
import tempfile
import time
import unittest
from datetime import datetime

# Test imports (will be available after implementation)
try:
    from core_features.vantavault import vault, migrate_memory_to_vault
    from core_features.moodsync import mood_sync, analyze_user_mood
    from core_features.codeforge import code_forge, generate_safe_code
    from core_features.swaggerapi import swagger_api, get_openapi_spec
    from core_features.quantumthink import quantum_think, quantum_reasoning
except ImportError as e:
    print(f"⚠️  Import error: {e}")
    print("Run tests after features are implemented")
    exit(1)

class TestVantaVault(unittest.TestCase):
    """Test VantaVault encrypted storage"""
    
    def setUp(self):
        self.test_data = {"user_123": {"messages": ["test"], "prefs": {"theme": "dark"}}}
        
    def test_encryption_decryption(self):
        """Test 1: Basic encryption/decryption cycle"""
        encrypted = vault.encrypt_data(self.test_data)
        self.assertIsNotNone(encrypted)
        
        decrypted = vault.decrypt_data(encrypted)
        self.assertEqual(decrypted, self.test_data)
        print("✅ VantaVault: Encryption/Decryption working")
    
    def test_secure_storage(self):
        """Test 2: Secure file storage and retrieval"""
        test_filename = f"test_{int(time.time())}"
        
        # Store data
        result = vault.store_secure(test_filename, self.test_data)
        self.assertTrue(result)
        
        # Retrieve data
        retrieved = vault.retrieve_secure(test_filename)
        self.assertEqual(retrieved, self.test_data)
        print("✅ VantaVault: Secure storage working")
    
    def test_health_check(self):
        """Test 3: Vault health check"""
        health = vault.health_check()
        self.assertIn("status", health)
        self.assertIn(health["status"], ["healthy", "degraded", "error"])
        print(f"✅ VantaVault: Health check - {health['status']}")

class TestMoodSync(unittest.TestCase):
    """Test MoodSync emotional intelligence"""
    
    def test_sentiment_analysis(self):
        """Test 1: Sentiment analysis accuracy"""
        test_cases = [
            ("I'm so happy and excited!", "positive"),
            ("This is terrible and frustrating", "negative"),
            ("The weather is okay today", "neutral")
        ]
        
        for text, expected_mood_type in test_cases:
            result = mood_sync.analyze_sentiment(text)
            self.assertIn("mood", result)
            
            # Check if detected mood matches expected type
            detected = result["mood"]
            if expected_mood_type == "positive":
                self.assertIn(detected, ["positive", "very_positive"])
            elif expected_mood_type == "negative":  
                self.assertIn(detected, ["negative", "very_negative"])
            else:
                self.assertEqual(detected, "neutral")
                
        print("✅ MoodSync: Sentiment analysis working")
    
    def test_mood_tracking(self):
        """Test 2: User mood tracking"""
        test_user = 999999
        test_message = "I feel great today!"
        
        result = mood_sync.track_user_mood(test_user, test_message)
        self.assertIn("mood", result)
        
        # Check if tracking stored data
        summary = mood_sync.get_user_mood_summary(test_user)
        self.assertEqual(summary["status"], "success")
        print("✅ MoodSync: Mood tracking working")
    
    def test_mood_health_metrics(self):
        """Test 3: Mood health metrics"""
        metrics = mood_sync.get_mood_health_metrics()
        self.assertIn("total_users", metrics)
        print(f"✅ MoodSync: Health metrics - {metrics.get('total_users', 0)} users tracked")

class TestCodeForge(unittest.TestCase):
    """Test CodeForge code generation"""
    
    def test_code_safety_validation(self):
        """Test 1: Code safety validation"""
        safe_code = "def hello():\n    return 'Hello World'"
        unsafe_code = "import os; os.system('rm -rf /')"
        
        safe_result = code_forge.validate_code_safety(safe_code)
        unsafe_result = code_forge.validate_code_safety(unsafe_code)
        
        self.assertTrue(safe_result["safe"])
        self.assertFalse(unsafe_result["safe"])
        print("✅ CodeForge: Safety validation working")
    
    def test_rate_limiting(self):
        """Test 2: Rate limiting functionality"""
        test_user = 888888
        
        # Should pass first few requests
        for i in range(3):
            result = code_forge.check_rate_limit(test_user)
            self.assertTrue(result, f"Request {i+1} should pass")
        
        # Should fail after hitting limit (5 requests in 5 minutes)
        for i in range(3):
            code_forge.check_rate_limit(test_user)
            
        # This should be rate limited
        result = code_forge.check_rate_limit(test_user)
        self.assertFalse(result, "Should be rate limited")
        print("✅ CodeForge: Rate limiting working")
    
    def test_code_linting(self):
        """Test 3: Code linting functionality"""
        python_code = "def test():\n    print('hello')\n    return True"
        
        lint_result = code_forge.lint_code(python_code, "python")
        self.assertIn("issues", lint_result)
        self.assertIn("score", lint_result)
        print(f"✅ CodeForge: Linting working - Score: {lint_result['score']}")

class TestSwaggerAPI(unittest.TestCase):
    """Test SwaggerAPI documentation"""
    
    def test_openapi_spec_generation(self):
        """Test 1: OpenAPI spec generation"""
        spec_json = get_openapi_spec()
        spec = json.loads(spec_json)
        
        self.assertIn("openapi", spec)
        self.assertIn("info", spec)
        self.assertIn("paths", spec)
        self.assertEqual(spec["openapi"], "3.0.0")
        print("✅ SwaggerAPI: OpenAPI spec generation working")
    
    def test_endpoint_detection(self):
        """Test 2: Endpoint detection and documentation"""
        spec = json.loads(get_openapi_spec())
        paths = spec.get("paths", {})
        
        # Check for expected endpoints
        expected_endpoints = ["/health", "/bot/start", "/bot/help"]
        found_endpoints = 0
        
        for endpoint in expected_endpoints:
            if any(endpoint in path for path in paths.keys()):
                found_endpoints += 1
                
        self.assertGreater(found_endpoints, 0, "Should find some expected endpoints")
        print(f"✅ SwaggerAPI: Endpoint detection working - {len(paths)} paths documented")
    
    def test_api_statistics(self):
        """Test 3: API statistics"""
        stats = swagger_api.get_api_stats()
        self.assertIn("total_paths", stats)
        self.assertIn("total_endpoints", stats)
        print(f"✅ SwaggerAPI: Statistics working - {stats['total_endpoints']} endpoints")

class TestQuantumThink(unittest.TestCase):
    """Test QuantumThink reasoning engine"""
    
    def test_intent_detection(self):
        """Test 1: Intent detection accuracy"""
        test_queries = [
            ("How do I solve this math problem?", "problem_solving"),
            ("Should I choose option A or B?", "decision_making"),
            ("Analyze this data trend", "analysis"),
            ("Create a new logo design", "creative_thinking"),
            ("Find information about quantum computing", "research")
        ]
        
        correct_detections = 0
        for query, expected_intent in test_queries:
            detected = quantum_think.detect_reasoning_intent(query)
            if detected == expected_intent:
                correct_detections += 1
                
        accuracy = correct_detections / len(test_queries)
        self.assertGreater(accuracy, 0.5, "Intent detection should be >50% accurate")
        print(f"✅ QuantumThink: Intent detection - {accuracy:.1%} accuracy")
    
    def test_complexity_scoring(self):
        """Test 2: Complexity scoring"""
        simple_query = "What time is it?"
        complex_query = "How do I design a distributed system architecture that can handle machine learning workloads while ensuring data privacy and regulatory compliance?"
        
        simple_score = quantum_think.calculate_complexity_score(simple_query)
        complex_score = quantum_think.calculate_complexity_score(complex_query)
        
        self.assertLess(simple_score, complex_score, "Complex query should score higher")
        self.assertLessEqual(simple_score, 10)
        self.assertLessEqual(complex_score, 10)
        print(f"✅ QuantumThink: Complexity scoring - Simple: {simple_score}, Complex: {complex_score}")
    
    def test_quantum_stats(self):
        """Test 3: QuantumThink statistics"""
        stats = quantum_think.get_quantum_stats()
        self.assertIn("cached_queries", stats)
        print(f"✅ QuantumThink: Statistics working - {stats.get('cached_queries', 0)} cached queries")

# Executable test commands for manual verification
def run_manual_tests():
    """Run manual tests that can be executed via shell"""
    print("🧪 Running Manual Test Suite...")
    
    # Test 1: VantaVault migration
    print("\n1. Testing VantaVault Migration:")
    try:
        result = migrate_memory_to_vault()
        print(f"   Migration result: {result}")
    except Exception as e:
        print(f"   Migration failed: {e}")
    
    # Test 2: MoodSync sentiment
    print("\n2. Testing MoodSync Sentiment:")
    try:
        result = analyze_user_mood(12345, "I'm feeling fantastic today!")
        print(f"   Sentiment result: {result.get('mood', 'unknown')}")
    except Exception as e:
        print(f"   Sentiment analysis failed: {e}")
    
    # Test 3: CodeForge safety
    print("\n3. Testing CodeForge Safety:")
    try:
        safe_code = "print('Hello World')"
        result = code_forge.validate_code_safety(safe_code)
        print(f"   Safety check: {'SAFE' if result['safe'] else 'UNSAFE'}")
    except Exception as e:
        print(f"   Safety check failed: {e}")

if __name__ == "__main__":
    # Run unit tests
    print("🚀 COREVANTA AI - Upgrade Batch 2 Test Suite")
    print("=" * 50)
    
    # Run manual tests first
    run_manual_tests()
    
    # Run unit tests
    print("\n" + "=" * 50)
    print("🧪 Running Unit Tests...")
    unittest.main(verbosity=2, exit=False)
    
    print("\n" + "=" * 50)
    print("✅ Test Suite Complete!")


import asyncio
import sys
import os

# Add the current directory to the Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

async def test_research():
    """Test the research functionality"""
    try:
        from core_features.research_enhanced import research_engine
        
        print("🔍 Testing ResearchEngine...")
        
        # Test comprehensive research
        result = await research_engine.comprehensive_research("Python programming")
        
        print(f"✅ Research completed!")
        print(f"📊 Results: {result['source_count']} sources from {result['engines_used']} engines")
        print(f"🎯 Success: {result['search_success']}")
        
        if result['sources']:
            print("\n🔗 Sample results:")
            for i, source in enumerate(result['sources'][:3], 1):
                print(f"{i}. {source['source']}: {source['title'][:50]}...")
        
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False

if __name__ == "__main__":
    success = asyncio.run(test_research())
    if success:
        print("\n🎉 Research system is working!")
    else:
        print("\n💥 Research system needs more fixes!")

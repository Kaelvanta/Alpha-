"""
CoreVanta AI - Smart Search Provider
SerpAPI with DuckDuckGo fallback for reliable search results
"""

import os
import logging
import requests
from typing import List, Dict, Any, Optional

# Graceful import for DuckDuckGo search
try:
    from duckduckgo_search import DDGS
    DDGS_AVAILABLE = True
except ImportError:
    DDGS_AVAILABLE = False
    logging.warning("duckduckgo-search not available. Install with: pip install duckduckgo-search")

class SearchProvider:
    """Multi-source search with intelligent fallback"""
    
    def __init__(self):
        self.serpapi_key = os.getenv("SERPAPI_KEY")
        self.logger = logging.getLogger(__name__)
        
    def _search_serpapi(self, query: str, max_results: int = 5) -> Optional[List[Dict[str, Any]]]:
        """Search using SerpAPI (Google Search)"""
        if not self.serpapi_key:
            return None
            
        try:
            params = {
                "api_key": self.serpapi_key,
                "q": query,
                "num": max_results,
                "engine": "google"
            }
            
            response = requests.get("https://serpapi.com/search", params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                results = []
                
                # Process organic results
                for item in data.get("organic_results", [])[:max_results]:
                    results.append({
                        "title": item.get("title", "No Title"),
                        "link": item.get("link", "#"),
                        "snippet": item.get("snippet", "No description available"),
                        "source": "Google (SerpAPI)"
                    })
                
                return results if results else None
                
        except Exception as e:
            self.logger.error(f"SerpAPI search error: {e}")
            return None
    
    def _search_duckduckgo(self, query: str, max_results: int = 5) -> Optional[List[Dict[str, Any]]]:
        """Fallback search using DuckDuckGo"""
        if not DDGS_AVAILABLE:
            return None
            
        try:
            with DDGS() as ddgs:
                results = []
                search_results = ddgs.text(query, max_results=max_results)
                
                for item in search_results:
                    results.append({
                        "title": item.get("title", "No Title"),
                        "link": item.get("href", "#"),
                        "snippet": item.get("body", "No description available"),
                        "source": "DuckDuckGo"
                    })
                
                return results if results else None
                
        except Exception as e:
            self.logger.error(f"DuckDuckGo search error: {e}")
            return None
    
    def search(self, query: str, max_results: int = 5) -> List[Dict[str, Any]]:
        """
        Primary search function with intelligent fallback
        
        Args:
            query: Search query string
            max_results: Maximum number of results to return
            
        Returns:
            List of search results with title, link, snippet, and source
        """
        
        # Try SerpAPI first
        results = self._search_serpapi(query, max_results)
        if results:
            self.logger.info(f"Search successful via SerpAPI: {len(results)} results")
            return results
        
        # Fallback to DuckDuckGo
        results = self._search_duckduckgo(query, max_results)
        if results:
            self.logger.info(f"Search successful via DuckDuckGo fallback: {len(results)} results")
            return results
        
        # Final fallback - return empty with error indication
        self.logger.warning(f"All search providers failed for query: {query}")
        return [{
            "title": "Search Error",
            "link": "#",
            "snippet": f"Unable to search for '{query}'. All search providers are currently unavailable.",
            "source": "System Error"
        }]
    
    def health_check(self) -> Dict[str, Any]:
        """Check health status of search providers"""
        status = {
            "serpapi": {
                "configured": bool(self.serpapi_key),
                "available": bool(self.serpapi_key)
            },
            "duckduckgo": {
                "configured": DDGS_AVAILABLE,
                "available": DDGS_AVAILABLE
            }
        }
        
        # Test search capability
        try:
            test_results = self.search("python programming", max_results=1)
            status["last_test"] = {
                "success": len(test_results) > 0 and "Error" not in test_results[0]["title"],
                "provider_used": test_results[0]["source"] if test_results else None
            }
        except Exception as e:
            status["last_test"] = {
                "success": False,
                "error": str(e)
            }
        
        return status

# Global search instance
search_provider = SearchProvider()

def search(query: str, max_results: int = 5) -> List[Dict[str, Any]]:
    """Convenience function for quick searches"""
    return search_provider.search(query, max_results)

def search_and_format(query: str, max_results: int = 5) -> str:
    """Search and format results for display"""
    results = search(query, max_results)
    
    if not results:
        return f"❌ No results found for: {query}"
    
    formatted = [f"🔍 **Search Results for:** {query}\n"]
    
    for i, result in enumerate(results, 1):
        formatted.append(
            f"**{i}. {result['title']}**\n"
            f"🔗 {result['link']}\n"
            f"📝 {result['snippet'][:200]}{'...' if len(result['snippet']) > 200 else ''}\n"
            f"📍 Source: {result['source']}\n"
        )
    
    return "\n".join(formatted)

# Sample test function
def test_search_providers():
    """Test all search providers"""
    test_query = "artificial intelligence 2024"
    print(f"Testing search for: {test_query}")
    
    provider = SearchProvider()
    
    # Test SerpAPI
    print("\n1. Testing SerpAPI...")
    serpapi_results = provider._search_serpapi(test_query, 3)
    print(f"SerpAPI Results: {len(serpapi_results) if serpapi_results else 0}")
    
    # Test DuckDuckGo
    print("\n2. Testing DuckDuckGo...")
    ddg_results = provider._search_duckduckgo(test_query, 3)
    print(f"DuckDuckGo Results: {len(ddg_results) if ddg_results else 0}")
    
    # Test unified search
    print("\n3. Testing unified search...")
    unified_results = provider.search(test_query, 3)
    print(f"Unified Results: {len(unified_results)}")
    
    if unified_results:
        print(f"First result: {unified_results[0]['title']} from {unified_results[0]['source']}")
    
    return {
        "serpapi": len(serpapi_results) if serpapi_results else 0,
        "duckduckgo": len(ddg_results) if ddg_results else 0,
        "unified": len(unified_results)
    }

if __name__ == "__main__":
    # Quick test
    print("🔍 CoreVanta Search Provider Test")
    print("=" * 40)
    
    health = search_provider.health_check()
    print(f"Health Status: {health}")
    
    # Run a test search
    test_results = search("Python programming tips", 3)
    print(f"\nTest Search Results: {len(test_results)} found")
    for i, result in enumerate(test_results, 1):
        print(f"{i}. {result['title']} ({result['source']})")
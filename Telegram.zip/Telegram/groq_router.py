"""
CoreVanta AI - Groq Router with Key Rotation & Fallback
Advanced multi-model routing with health checks and failover
"""

import os
import time
import logging
import random
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timedelta

# Graceful import handling
try:
    from groq import Groq
    GROQ_AVAILABLE = True
except ImportError:
    GROQ_AVAILABLE = False
    logging.warning("Groq library not available. Install with: pip install groq")

import requests

class KeyPool:
    """Advanced key rotation with cooldown and health tracking"""
    
    def __init__(self, keys: List[str], cooldown_minutes: int = 5):
        self.keys = keys
        self.cooldown_duration = timedelta(minutes=cooldown_minutes)
        self.failed_keys: Dict[str, datetime] = {}
        self.current_index = 0
        
    def get_key(self) -> Optional[str]:
        """Get next available key with round-robin + cooldown"""
        available_keys = []
        now = datetime.now()
        
        for key in self.keys:
            # Check if key is out of cooldown
            if key in self.failed_keys:
                if now - self.failed_keys[key] < self.cooldown_duration:
                    continue  # Still in cooldown
                else:
                    # Remove from failed keys - cooldown expired
                    del self.failed_keys[key]
            available_keys.append(key)
        
        if not available_keys:
            return None  # All keys are in cooldown
        
        # Round-robin selection
        key = available_keys[self.current_index % len(available_keys)]
        self.current_index = (self.current_index + 1) % len(available_keys)
        return key
    
    def mark_failed(self, key: str, cooldown_minutes: Optional[int] = None):
        """Mark key as failed with optional custom cooldown"""
        if cooldown_minutes:
            cooldown = timedelta(minutes=cooldown_minutes)
        else:
            cooldown = self.cooldown_duration
        
        self.failed_keys[key] = datetime.now()
        logging.warning(f"Key marked as failed. Cooldown until: {datetime.now() + cooldown}")
    
    def get_status(self) -> Dict[str, Any]:
        """Get current status of all keys"""
        now = datetime.now()
        status = {"total_keys": len(self.keys), "available_keys": 0, "failed_keys": []}
        
        for key in self.keys:
            if key in self.failed_keys:
                time_left = (self.failed_keys[key] + self.cooldown_duration - now).total_seconds()
                if time_left > 0:
                    status["failed_keys"].append({
                        "key_suffix": key[-8:],
                        "cooldown_seconds": max(0, int(time_left))
                    })
                else:
                    status["available_keys"] += 1
            else:
                status["available_keys"] += 1
        
        return status

class GroqRouter:
    """Advanced Groq router with multiple models and fallback strategy"""
    
    # Available Groq models with their capabilities
    MODELS = {
        "llama4_scout": {
            "name": "meta-llama/llama-4-scout-17b-16e-instruct",
            "max_tokens": 1024,
            "strengths": "Advanced reasoning, latest Llama model, great for complex tasks"
        },
        "llama31_fast": {
            "name": "llama-3.1-8b-instant", 
            "max_tokens": 1024,
            "strengths": "Ultra-fast responses, great for quick tasks and conversations"
        },
        "gpt_oss": {
            "name": "openai/gpt-oss-120b",
            "max_tokens": 8192,
            "strengths": "Large context, reasoning effort support, complex analysis"
        },
        "whisper_transcribe": {
            "name": "whisper-large-v3",
            "max_tokens": None,
            "strengths": "Audio transcription, multiple languages, high accuracy"
        }
    }
    
    def __init__(self):
        self.groq_keys = self._load_groq_keys()
        self.openrouter_key = os.getenv("OPENROUTER_KEY")
        self.key_pool = KeyPool(self.groq_keys) if self.groq_keys else None
        
        # Default models
        self.default_text_model = os.getenv("DEFAULT_TEXT_MODEL", "llama31_fast")
        self.default_tts_model = os.getenv("DEFAULT_TTS_MODEL", "llama31_fast")
        self.default_stt_model = os.getenv("DEFAULT_STT_MODEL", "whisper_transcribe")
        
        self.logger = logging.getLogger(__name__)
        
    def _load_groq_keys(self) -> List[str]:
        """Load Groq keys from environment (comma-separated)"""
        keys_env = os.getenv("GROQ_KEYS", "")
        groq_api_key = os.getenv("GROQ_API_KEY", "")
        
        keys = []
        if keys_env:
            keys.extend([k.strip() for k in keys_env.split(",") if k.strip()])
        if groq_api_key and groq_api_key not in keys:
            keys.append(groq_api_key)
            
        return [k for k in keys if k.startswith("gsk_")]
    
    def _post_groq(self, payload: Dict[str, Any], key: str) -> Optional[Dict[str, Any]]:
        """Make request to Groq API"""
        if not GROQ_AVAILABLE:
            return None
            
        try:
            client = Groq(api_key=key)
            
            # Handle different types of requests
            if "audio" in payload:
                # Audio transcription
                return self._handle_audio_transcription(client, payload)
            else:
                # Text completion
                response = client.chat.completions.create(**payload)
                return {
                    "choices": [{"message": {"content": response.choices[0].message.content}}]
                }
                
        except Exception as e:
            error_msg = str(e).lower()
            if any(code in error_msg for code in ["401", "403", "429", "quota", "rate limit"]):
                # Mark key as failed for these specific errors
                self.key_pool.mark_failed(key)
            self.logger.error(f"Groq API error: {e}")
            return None
    
    def _handle_audio_transcription(self, client, payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Handle audio transcription requests"""
        try:
            audio_data = payload.get("audio")
            if not audio_data:
                return None
                
            transcription = client.audio.transcriptions.create(
                file=audio_data,
                model=payload.get("model", "whisper-large-v3"),
                response_format="verbose_json"
            )
            
            return {
                "choices": [{"message": {"content": transcription.text}}]
            }
        except Exception as e:
            self.logger.error(f"Audio transcription error: {e}")
            return None
    
    def _post_openrouter(self, payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Fallback to OpenRouter API"""
        if not self.openrouter_key:
            return None
            
        try:
            headers = {
                "Authorization": f"Bearer {self.openrouter_key}",
                "Content-Type": "application/json"
            }
            
            # Convert Groq payload to OpenRouter format
            openrouter_payload = {
                "model": "meta-llama/llama-3.1-8b-instruct:free",
                "messages": payload.get("messages", []),
                "temperature": payload.get("temperature", 0.7),
                "max_tokens": payload.get("max_completion_tokens", 1024)
            }
            
            response = requests.post(
                "https://openrouter.ai/api/v1/chat/completions",
                headers=headers,
                json=openrouter_payload,
                timeout=30
            )
            
            if response.status_code == 200:
                return response.json()
            return None
            
        except Exception as e:
            self.logger.error(f"OpenRouter fallback error: {e}")
            return None
    
    def _call_with_rotation(self, payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Try each Groq key, then fallback to OpenRouter"""
        
        # Try Groq keys first
        if self.key_pool:
            for attempt in range(len(self.groq_keys)):
                key = self.key_pool.get_key()
                if not key:
                    break  # All keys in cooldown
                    
                result = self._post_groq(payload, key)
                if result:
                    return result
        
        # Fallback to OpenRouter
        return self._post_openrouter(payload)
    
    def ask_text(self, prompt: str, model: Optional[str] = None, system_prompt: str = "You are CoreVanta AI, a helpful and intelligent assistant.") -> str:
        """Ask text question with model selection"""
        model_key = model or self.default_text_model
        model_info = self.MODELS.get(model_key, self.MODELS["llama31_fast"])
        
        payload = {
            "model": model_info["name"],
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.7,
            "max_completion_tokens": model_info["max_tokens"] or 1024,
            "top_p": 1,
            "stream": False
        }
        
        # Add reasoning effort for GPT-OSS model
        if model_key == "gpt_oss":
            payload["reasoning_effort"] = "medium"
        
        try:
            result = self._call_with_rotation(payload)
            if result and result.get("choices"):
                content = result["choices"][0]["message"]["content"]
                return f"🤖 **{model_info['name']}**\n\n{content}\n\n*Strengths: {model_info['strengths']}*"
            else:
                return "⚠️ All AI engines busy. Please try again in a moment."
                
        except Exception as e:
            self.logger.error(f"Text generation error: {e}")
            return f"⚠️ Error generating response: {str(e)}"
    
    def tts(self, text: str, model: Optional[str] = None) -> str:
        """Text-to-speech placeholder (Groq doesn't support TTS yet)"""
        return f"🔊 TTS requested for: '{text[:50]}...' (TTS not yet supported by Groq, but request logged)"
    
    def stt_from_url(self, url: str, model: Optional[str] = None) -> str:
        """Speech-to-text from URL placeholder"""
        return f"🎤 STT requested for URL: {url} (URL-based STT requires file download implementation)"
    
    def health(self) -> Dict[str, Any]:
        """Get comprehensive health status"""
        status = {
            "groq_available": GROQ_AVAILABLE,
            "total_models": len(self.MODELS),
            "default_models": {
                "text": self.default_text_model,
                "tts": self.default_tts_model, 
                "stt": self.default_stt_model
            },
            "apis": {
                "groq": {
                    "configured": bool(self.groq_keys),
                    "key_count": len(self.groq_keys) if self.groq_keys else 0,
                    "key_pool_status": self.key_pool.get_status() if self.key_pool else None
                },
                "openrouter_fallback": {
                    "configured": bool(self.openrouter_key),
                    "available": bool(self.openrouter_key)
                }
            },
            "models": {k: v["strengths"] for k, v in self.MODELS.items()}
        }
        
        return status
    
    def list_models(self) -> List[Dict[str, str]]:
        """List all available models with descriptions"""
        return [
            {
                "nickname": nickname,
                "model": info["name"],
                "max_tokens": str(info["max_tokens"]) if info["max_tokens"] else "N/A",
                "strengths": info["strengths"]
            }
            for nickname, info in self.MODELS.items()
        ]

# Global instance
DEFAULT_ROUTER = GroqRouter()

# Convenience functions
def quick_ask(prompt: str, model: str = "llama31_fast") -> str:
    """Quick text generation"""
    return DEFAULT_ROUTER.ask_text(prompt, model)

def test_all_models(test_prompt: str = "Hello! Please introduce yourself.") -> Dict[str, str]:
    """Test all available models"""
    results = {}
    for model_key in DEFAULT_ROUTER.MODELS.keys():
        if model_key != "whisper_transcribe":  # Skip audio model for text test
            try:
                result = DEFAULT_ROUTER.ask_text(test_prompt, model_key)
                results[model_key] = result
            except Exception as e:
                results[model_key] = f"Error: {str(e)}"
    return results

if __name__ == "__main__":
    # Quick test
    print("🚀 CoreVanta Groq Router Test")
    print("=" * 50)
    
    health = DEFAULT_ROUTER.health()
    print(f"Health Status: {health}")
    
    if health["apis"]["groq"]["configured"]:
        test_result = quick_ask("Say hi in a cool way!")
        print(f"\nTest Result:\n{test_result}")
    else:
        print("❌ No Groq keys configured. Set GROQ_API_KEY or GROQ_KEYS environment variables.")
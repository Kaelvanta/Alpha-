
"""
News Fetching Module - Core Vanta AI
Fetches latest news worldwide + Ghana-specific using GNews API and RSS feeds fallback
"""
import requests
import feedparser
import json
import os
from datetime import datetime
from typing import List, Dict, Optional
from memory import log_error

# Global news sources configuration
SOURCES = {
    "gnews_api": {
        "endpoint": "https://gnews.io/api/v4/search",
        "key_env": "GNEWS_API_KEY",
        "enabled": True
    },
    "rss_global": [
        {
            "name": "BBC",
            "url": "http://feeds.bbci.co.uk/news/rss.xml",
            "category": "global"
        },
        {
            "name": "Al Jazeera", 
            "url": "https://www.aljazeera.com/xml/rss/all.xml",
            "category": "global"
        },
        {
            "name": "CNN",
            "url": "http://rss.cnn.com/rss/edition.rss", 
            "category": "global"
        },
        {
            "name": "Reuters",
            "url": "http://feeds.reuters.com/reuters/topNews",
            "category": "global"
        }
    ],
    "rss_ghana": [
        {
            "name": "MyJoyOnline",
            "url": "https://www.myjoyonline.com/feed/",
            "category": "ghana"
        },
        {
            "name": "GhanaWeb", 
            "url": "https://www.ghanaweb.com/GhanaHomePage/rss/",
            "category": "ghana"
        },
        {
            "name": "GBC Ghana",
            "url": "https://www.gbcghanaonline.com/feed/",
            "category": "ghana"
        },
        {
            "name": "CitiNewsRoom",
            "url": "https://citinewsroom.com/feed/",
            "category": "ghana"
        },
        {
            "name": "NewsGhana",
            "url": "https://newsghana.com.gh/feed/",
            "category": "ghana"
        }
    ]
}

def get_gnews_api_key() -> Optional[str]:
    """Get GNews API key from environment"""
    return os.getenv("GNEWS_API_KEY")

def search_gnews_api(query: str, max_results: int = 10) -> List[Dict]:
    """
    Search GNews API for specific query
    Returns standardized news format
    """
    try:
        api_key = get_gnews_api_key()
        if not api_key:
            log_error("GNews API key not found in environment")
            return []
        
        # Prepare API request
        endpoint = SOURCES["gnews_api"]["endpoint"]
        params = {
            "q": query,
            "token": api_key,
            "lang": "en",
            "max": max_results,
            "sortby": "publishedAt"
        }
        
        # Make API request
        response = requests.get(endpoint, params=params, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        
        # Parse response into standardized format
        news_items = []
        for article in data.get("articles", []):
            try:
                # Format published date
                published_at = article.get("publishedAt", "")
                if published_at:
                    # Convert ISO format to readable date
                    published_date = datetime.fromisoformat(published_at.replace('Z', '+00:00'))
                    formatted_date = published_date.strftime("%Y-%m-%d")
                else:
                    formatted_date = datetime.now().strftime("%Y-%m-%d")
                
                news_item = {
                    "title": article.get("title", "No title"),
                    "description": article.get("description", ""),
                    "url": article.get("url", ""),
                    "source": article.get("source", {}).get("name", "Unknown"),
                    "published": formatted_date
                }
                news_items.append(news_item)
                
            except Exception as e:
                log_error(f"Error parsing GNews article: {e}")
                continue
        
        log_error(f"GNews API returned {len(news_items)} articles for query: {query}")
        return news_items
        
    except requests.exceptions.RequestException as e:
        log_error(f"GNews API request failed: {e}")
        return []
    except Exception as e:
        log_error(f"GNews API error: {e}")
        return []

def fetch_rss_feed(source: Dict, max_items: int = 5) -> List[Dict]:
    """
    Fetch news from a single RSS feed source
    Returns standardized news format
    """
    try:
        feed_url = source["url"]
        source_name = source["name"]
        
        # Parse RSS feed
        feed = feedparser.parse(feed_url)
        
        if feed.bozo:
            log_error(f"RSS feed parsing warning for {source_name}: {feed.bozo_exception}")
        
        news_items = []
        for entry in feed.entries[:max_items]:
            try:
                # Format published date
                published_date = ""
                if hasattr(entry, 'published_parsed') and entry.published_parsed:
                    published_date = datetime(*entry.published_parsed[:6]).strftime("%Y-%m-%d")
                elif hasattr(entry, 'updated_parsed') and entry.updated_parsed:
                    published_date = datetime(*entry.updated_parsed[:6]).strftime("%Y-%m-%d")
                else:
                    published_date = datetime.now().strftime("%Y-%m-%d")
                
                # Get description/summary
                description = ""
                if hasattr(entry, 'summary'):
                    description = entry.summary
                elif hasattr(entry, 'description'):
                    description = entry.description
                
                # Clean description (remove HTML tags if present)
                if description:
                    import re
                    description = re.sub(r'<[^>]+>', '', description)
                    description = description.strip()[:200] + "..." if len(description) > 200 else description
                
                news_item = {
                    "title": entry.get("title", "No title"),
                    "description": description,
                    "url": entry.get("link", ""),
                    "source": source_name,
                    "published": published_date
                }
                news_items.append(news_item)
                
            except Exception as e:
                log_error(f"Error parsing RSS entry from {source_name}: {e}")
                continue
        
        return news_items
        
    except Exception as e:
        log_error(f"RSS feed fetch failed for {source.get('name', 'Unknown')}: {e}")
        return []

def fetch_all_rss_feeds(category: str = "all", max_per_source: int = 5) -> List[Dict]:
    """
    Fetch news from all RSS feeds
    Category: 'all', 'global', 'ghana'
    """
    all_news = []
    
    try:
        # Determine which sources to use
        sources_to_fetch = []
        
        if category == "all" or category == "global":
            sources_to_fetch.extend(SOURCES["rss_global"])
        
        if category == "all" or category == "ghana":
            sources_to_fetch.extend(SOURCES["rss_ghana"])
        
        # Fetch from each source
        for source in sources_to_fetch:
            news_items = fetch_rss_feed(source, max_per_source)
            all_news.extend(news_items)
        
        # Sort by source and published date
        all_news.sort(key=lambda x: (x["source"], x["published"]), reverse=True)
        
        log_error(f"RSS feeds returned {len(all_news)} total articles")
        return all_news
        
    except Exception as e:
        log_error(f"Error fetching RSS feeds: {e}")
        return []

def get_news(query: Optional[str] = None, max_results: int = 20) -> List[Dict]:
    """
    Main function to get news - uses GNews API for queries, RSS feeds for latest news
    
    Args:
        query: Search term for specific news (uses GNews API)
        max_results: Maximum number of results to return
    
    Returns:
        List of standardized news dictionaries
    """
    try:
        news_results = []
        
        # If query provided, try GNews API first
        if query and query.strip():
            log_error(f"Searching news for query: {query}")
            
            # Try GNews API
            gnews_results = search_gnews_api(query, max_results)
            
            if gnews_results:
                news_results = gnews_results
                log_error(f"Using GNews API results: {len(news_results)} articles")
            else:
                # Fallback to RSS feeds with query-relevant sources
                log_error("GNews API failed, falling back to RSS feeds")
                
                # For Ghana-related queries, prioritize Ghana sources
                if any(keyword in query.lower() for keyword in ["ghana", "accra", "kumasi", "african"]):
                    news_results = fetch_all_rss_feeds("ghana", max_per_source=8)
                else:
                    news_results = fetch_all_rss_feeds("global", max_per_source=5)
        
        else:
            # No query - fetch latest news from all RSS feeds
            log_error("No query provided, fetching latest news from RSS feeds")
            news_results = fetch_all_rss_feeds("all", max_per_source=4)
        
        # Limit results
        news_results = news_results[:max_results]
        
        # Ensure we have some results
        if not news_results:
            log_error("No news results found, returning fallback message")
            return [{
                "title": "⚠️ No news available",
                "description": "Unable to fetch news at this time. Please try again later.",
                "url": "",
                "source": "System",
                "published": datetime.now().strftime("%Y-%m-%d")
            }]
        
        log_error(f"Returning {len(news_results)} news articles")
        return news_results
        
    except Exception as e:
        log_error(f"Critical error in get_news: {e}")
        return [{
            "title": "⚠️ News service error",
            "description": f"Error fetching news: {str(e)}",
            "url": "",
            "source": "System",
            "published": datetime.now().strftime("%Y-%m-%d")
        }]

def format_news_for_telegram(news_items: List[Dict], max_items: int = 10) -> str:
    """
    Format news items for Telegram display
    """
    try:
        if not news_items:
            return "📰 No news available at the moment."
        
        # Limit items for display
        items_to_show = news_items[:max_items]
        
        formatted_text = "📰 <b>Latest News</b>\n\n"
        
        for i, item in enumerate(items_to_show, 1):
            title = item.get("title", "No title")
            source = item.get("source", "Unknown")
            published = item.get("published", "")
            url = item.get("url", "")
            
            # Truncate title if too long
            if len(title) > 80:
                title = title[:77] + "..."
            
            formatted_text += f"<b>{i}.</b> {title}\n"
            formatted_text += f"📡 <i>{source}</i>"
            
            if published:
                formatted_text += f" • {published}"
            
            if url:
                formatted_text += f"\n🔗 <a href='{url}'>Read more</a>"
            
            formatted_text += "\n\n"
        
        # Add footer
        if len(news_items) > max_items:
            remaining = len(news_items) - max_items
            formatted_text += f"<i>+ {remaining} more articles available</i>\n\n"
        
        formatted_text += "— <b>Kael Vanta News Feed ®️</b>"
        
        return formatted_text
        
    except Exception as e:
        log_error(f"Error formatting news for Telegram: {e}")
        return "📰 <b>News formatting error</b>\n\nUnable to display news properly.\n\n— <b>Kael Vanta ®️</b>"

# Utility functions for expansion
def add_news_source(name: str, url: str, category: str = "global"):
    """
    Add a new RSS news source to the configuration
    Category: 'global' or 'ghana'
    """
    try:
        new_source = {
            "name": name,
            "url": url,
            "category": category
        }
        
        if category == "ghana":
            SOURCES["rss_ghana"].append(new_source)
        else:
            SOURCES["rss_global"].append(new_source)
        
        log_error(f"Added new {category} news source: {name}")
        return True
        
    except Exception as e:
        log_error(f"Error adding news source: {e}")
        return False

def get_sources_list() -> Dict:
    """
    Get current news sources configuration
    """
    try:
        return {
            "gnews_api_enabled": bool(get_gnews_api_key()),
            "global_sources": len(SOURCES["rss_global"]),
            "ghana_sources": len(SOURCES["rss_ghana"]),
            "total_sources": len(SOURCES["rss_global"]) + len(SOURCES["rss_ghana"])
        }
    except Exception as e:
        log_error(f"Error getting sources list: {e}")
        return {}

# Test function for development
def test_news_fetch():
    """
    Test function to verify news fetching works
    """
    print("🧪 Testing news fetching...")
    
    # Test with query
    print("\n1. Testing GNews API with query:")
    query_results = get_news("Ghana economy")
    print(f"Query results: {len(query_results)} articles")
    
    # Test without query (RSS feeds)
    print("\n2. Testing RSS feeds (no query):")
    rss_results = get_news()
    print(f"RSS results: {len(rss_results)} articles")
    
    # Test Telegram formatting
    print("\n3. Testing Telegram formatting:")
    formatted = format_news_for_telegram(rss_results[:3])
    print("Formatted output length:", len(formatted))
    
    print("\n✅ News fetch test completed!")

if __name__ == "__main__":
    test_news_fetch()

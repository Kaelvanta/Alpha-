from telegram import Update
from telegram.constants import ChatAction
from telegram.ext import ContextTypes
import random

# Custom Data
from custom_data.quotes import alpha_quotes
from custom_data.flirts import flirt_lines
from core_features.ai_engine import get_ai_response
from keys import API_KEYS

# /start command
async def handle_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 Welcome to AlphaGPT — Powered by Kael Vanta 🧠")

# /help command
async def handle_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "/alphacode — Savage mindset quote\n"
        "/flirt — Pickup line\n"
        "/surpriseme — Random power reply\n"
        "/checkmodels — Check live AI model status"
    )

# /checkmodels command
async def handle_checkmodels(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.chat.send_action(action=ChatAction.TYPING)
    report = "🧠 *Live AI Model Check — Kael Vanta*\n\n"

    for model, key in API_KEYS.items():
        try:
            reply = await get_ai_response("Hello", key)
            if reply:
                report += f"✅ `{model}` is working\n"
            else:
                report += f"⚠️ `{model}` returned empty\n"
        except Exception:
            report += f"❌ `{model}` is down or key invalid\n"

    await update.message.reply_text(report, parse_mode="Markdown")

# Handle custom commands like /alphacode, /flirt, etc.
async def handle_custom_commands(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.lower()

    if "/alphacode" in text:
        quote = random.choice(alpha_quotes)
        await update.message.reply_text(f"🧠 {quote}")

    elif "/flirt" in text:
        line = random.choice(flirt_lines)
        await update.message.reply_text(f"💘 {line}")

    elif "/surpriseme" in text:
        await update.message.reply_text("👀 Surprise! You’re more powerful than you know.")

    # /checkmodels handled above

"""
VantaVault - Encrypted Local Storage System
Secure data management with Fernet encryption
"""
import os
import json
import base64
from datetime import datetime
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from memory import log_error

class VantaVault:
    def __init__(self, vault_dir="vault"):
        self.vault_dir = vault_dir
        self.key_file = os.path.join(vault_dir, ".vaultkey")
        self.setup_vault()

    def setup_vault(self):
        """Initialize vault directory and encryption key"""
        try:
            os.makedirs(self.vault_dir, exist_ok=True)
            if not os.path.exists(self.key_file):
                self.generate_key()
            self.cipher = Fernet(self.load_key())
        except Exception as e:
            log_error(f"VantaVault setup failed: {e}")
            raise

    def generate_key(self):
        """Generate new encryption key"""
        try:
            # Create salt from system entropy
            salt = os.urandom(16)
            # Use a fixed password for local encryption (not ideal but functional)
            password = b"COREVANTA_VAULT_2024"
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=100000,
            )
            key = base64.urlsafe_b64encode(kdf.derive(password))
            
            with open(self.key_file, "wb") as f:
                f.write(salt + key)
                
        except Exception as e:
            log_error(f"Key generation failed: {e}")
            raise

    def load_key(self):
        """Load encryption key"""
        try:
            with open(self.key_file, "rb") as f:
                data = f.read()
                return data[16:]  # Skip salt
        except Exception as e:
            log_error(f"Key loading failed: {e}")
            raise

    def encrypt_data(self, data):
        """Encrypt data using Fernet"""
        try:
            if isinstance(data, dict):
                data = json.dumps(data, indent=2)
            elif not isinstance(data, str):
                data = str(data)
            
            encrypted = self.cipher.encrypt(data.encode())
            return encrypted
        except Exception as e:
            log_error(f"Encryption failed: {e}")
            return None

    def decrypt_data(self, encrypted_data):
        """Decrypt data using Fernet"""
        try:
            decrypted = self.cipher.decrypt(encrypted_data)
            return json.loads(decrypted.decode())
        except json.JSONDecodeError:
            return decrypted.decode()
        except Exception as e:
            log_error(f"Decryption failed: {e}")
            return None

    def store_secure(self, filename, data):
        """Store data securely"""
        try:
            filepath = os.path.join(self.vault_dir, f"{filename}.vault")
            encrypted = self.encrypt_data(data)
            if encrypted:
                with open(filepath, "wb") as f:
                    f.write(encrypted)
                return True
            return False
        except Exception as e:
            log_error(f"Secure storage failed: {e}")
            return False

    def retrieve_secure(self, filename):
        """Retrieve secure data"""
        try:
            filepath = os.path.join(self.vault_dir, f"{filename}.vault")
            if not os.path.exists(filepath):
                return None
                
            with open(filepath, "rb") as f:
                encrypted_data = f.read()
                
            return self.decrypt_data(encrypted_data)
        except Exception as e:
            log_error(f"Secure retrieval failed: {e}")
            return None

    def migrate_from_json(self, json_file):
        """Migrate existing JSON data to encrypted storage"""
        try:
            if not os.path.exists(json_file):
                return False
                
            # Backup original
            backup_path = f"{json_file}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            os.rename(json_file, backup_path)
            
            # Load and encrypt
            with open(backup_path, "r") as f:
                data = json.load(f)
                
            vault_name = os.path.basename(json_file).replace(".json", "")
            success = self.store_secure(vault_name, data)
            
            if success:
                log_error(f"Migration successful: {json_file} -> vault/{vault_name}.vault")
                return True
            else:
                # Restore backup on failure
                os.rename(backup_path, json_file)
                return False
                
        except Exception as e:
            log_error(f"Migration failed: {e}")
            return False

    def backup_vault(self, backup_name=None):
        """Create encrypted backup of entire vault"""
        try:
            if not backup_name:
                backup_name = f"vault_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                
            backup_dir = f"backups/{backup_name}"
            os.makedirs(backup_dir, exist_ok=True)
            
            # Copy all vault files
            for filename in os.listdir(self.vault_dir):
                src = os.path.join(self.vault_dir, filename)
                dst = os.path.join(backup_dir, filename)
                with open(src, "rb") as s, open(dst, "wb") as d:
                    d.write(s.read())
                    
            return backup_dir
        except Exception as e:
            log_error(f"Vault backup failed: {e}")
            return None

    def health_check(self):
        """Check vault integrity"""
        try:
            # Test encryption/decryption
            test_data = {"test": "vault_health_check", "timestamp": datetime.now().isoformat()}
            encrypted = self.encrypt_data(test_data)
            decrypted = self.decrypt_data(encrypted)
            
            vault_files = len([f for f in os.listdir(self.vault_dir) if f.endswith('.vault')])
            
            return {
                "status": "healthy" if decrypted == test_data else "degraded",
                "vault_files": vault_files,
                "encryption_test": "passed" if decrypted == test_data else "failed",
                "vault_size": sum(os.path.getsize(os.path.join(self.vault_dir, f)) 
                                for f in os.listdir(self.vault_dir))
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}

# Global vault instance
vault = VantaVault()

# Migration helper functions
def migrate_memory_to_vault():
    """Migrate memory.json to encrypted storage"""
    return vault.migrate_from_json("memory.json")

def get_secure_memory():
    """Get memory data from vault"""
    return vault.retrieve_secure("memory") or {}

def save_secure_memory(memory_data):
    """Save memory data to vault"""
    return vault.store_secure("memory", memory_data)

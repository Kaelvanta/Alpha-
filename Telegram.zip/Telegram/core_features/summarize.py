# core_features/summarize.py

from ai_engine import ask_ai

def summarize_text(text: str, model: str = None) -> str:
    """
    Summarize the provided text using the default or selected AI model.
    """
    if not text.strip():
        return "⚠️ No text provided to summarize."

    prompt = (
        "Summarize the following text in a short, clear paragraph:\n\n"
        f"{text.strip()}"
    )

    response = ask_ai(prompt, model=model)
    return response
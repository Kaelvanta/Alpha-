import asyncio
import random
import requests
import json
from datetime import datetime
from aiogram.types import Message

from core_features.ai_engine import get_ai_response
from memory import add_message, log_error, create_backup, get_user_preferences, set_user_preference
from keys import API_KEYS
from core_features.news import get_news, format_news_for_telegram

# Enhanced Alpha quotes - Kael Vanta style
ALPHA_QUOTES = [
    "Move in silence, shock the loud.",
    "Discipline builds empires, not excuses.",
    "Power moves never need announcements.",
    "Respect is earned, not begged for.",
    "Level up so high they call it arrogance.",
    "Your grind isn’t for public approval.",
    "Never beg to sit at a weak table.",
    "Let success be the reply to doubt.",
    "Some chase clout, others create it.",
    "Confidence is quiet, insecurity is loud.",
    "When you’re rare, you’re never in competition.",
    "Silence your critics with undeniable wins.",
    "Time is money, but focus is gold.",
    "If it’s not making you better, drop it.",
    "Legends aren’t born—they self-made.",
    "Cut the noise, build the empire.",
    "Your enemies will advertise you for free.",
    "If they didn’t clap when you were down, don’t invite them up.",
    "Status isn’t bought—it’s built.",
    "Not all battles deserve your presence.",
    "Energy speaks louder than words.",
    "Never lose yourself chasing someone else.",
    "The less you react, the more power you hold.",
    "Play the long game; kings don’t rush.",
    "Stay underestimated—it’s your greatest weapon.",
    "Luxury is the byproduct of discipline.",
    "Be the storm they didn’t prepare for.",
    "A lion never fears sheep opinions.",
    "Your value isn’t negotiable.",
    "Never explain, just execute.",
    "Cut snakes before they bite.",
    "Work in the shadows, shine in daylight.",
    "If they copy you, you’re already ahead.",
    "Don’t fight for attention—own the room.",
    "You can’t break a mind that built itself.",
    "Comfort is the graveyard of ambition.",
    "Every loss is tuition for greatness.",
    "Outgrow them without announcement.",
    "You don’t need the spotlight to be legendary.",
    "They’ll doubt you, then copy you.",
    "Let them wonder how you did it.",
    "Master patience, master power.",
    "If it’s beneath you, leave it there.",
    "Even in silence, my presence speaks.",
    "The best revenge is becoming untouchable.",
    "Never chase—what’s meant will align.",
    "Standards high, emotions low.",
    "Work like a ghost, shine like a diamond.",
    "Your moves should confuse the average.",
    "Success is my loudest flex.",
    "🔥 **Discipline over motivation. Always.** 💪",
    "💎 **Move in silence, strike in chaos.** 🗡️",
    "⚡ **Results talk. Excuses walk.** 🚶‍♂️",
    "🚀 **Build empires, not friendships.** 👑",
    "💥 **Power respects preparation.** 📈",
    "🖤 **Stay cold, even in fire.** 🔥",
    "🦅 **Hunt alone. Eat alone.** 🍖",
    "💣 **Pressure creates diamonds or dust.** 💎",
    "🗡️ **Fear is a tool, not a prison.** 🔒",
    "⚔️ **Never show weakness. Ever.** ❌",
    "🎯 **Focus kills distractions.** 🚫",
    "💪 **Train so hard they call it obsession.** 🩸",
    "🔥 **Respect is earned, not requested.** 🙅‍♂️",
    "💀 **Play dead, strike twice.** 🐍",
    "🚀 **Small wins create big empires.** 🏰",
    "💼 **Money moves quiet.** 🤫",
    "🗡️ **Cut ties before they choke you.** ⛓️",
    "⚡ **Your grind will offend the lazy.** 😤",
    "🦾 **Strength is built in silence.** 🖤",
    "🎭 **Control the story, control the game.** ♟️",
    "🔥 **Sacrifice now. Celebrate later.** 🥂",
    "💣 **Blow up quietly.** 🤐",
    "⚔️ **Loyalty is rare. Protect it.** 🛡️",
    "🦅 **Aim higher than their doubts.** 🎯",
    "💪 **Dominate your lane.** 🛣️",
    "🚀 **Level up or get left behind.** 🏁",
    "🖤 **Pain builds the real ones.** 💥",
    "💼 **Move smart, not loud.** 🤫",
    "⚡ **Make them regret doubting you.** 💣",
    "🔥 **Your work is your weapon.** 🗡️",
    "🎯 **One shot. One kill.** 🔫",
    "💎 **Stay rare.** 🖤",
    "🦾 **The grind is non-negotiable.** 📆",
    "🚀 **Dream big. Move bigger.** 🌌",
    "⚔️ **Respect comes after victory.** 🏆",
    "🦅 **Never fold under pressure.** 💥",
    "🔥 **Comfort kills ambition.** 🛌",
    "💼 **Cash over clout.** 💵",
    "💣 **Stay dangerous. Stay disciplined.** 🖤",
    "🎭 **Never explain. Never complain.** 🚫",
    "🗡️ **Cut quick. Heal fast.** 🩹",
    "⚡ **Energy is currency. Spend it wisely.** 💡",
    "💪 **Fear none. Respect all.** 🤝",
    "🚀 **Don’t chase. Replace.** 🔄",
    "🔥 **Turn pain into power.** 💥",
    "🖤 **Patience is the highest form of strength.** ⏳",
    "💎 **Boss moves only.** 👑",
    "⚔️ **Control your mind, rule your world.** 🌍",
    "🦅 **Sky’s not the limit. It’s just the view.** 🌌",
    "🗡 If you can’t outsmart me, don’t try to outtalk me.",
    "🔥 Silence is my loudest flex.",
    "⚡ Discipline is my love language.",
    "💀 Power doesn’t beg — it takes.",
    "🦅 I fly where vultures starve.",
    "⛓ I break limits before they think to set them.",
    "🎯 Fear me or follow me — both feed my ego.",
    "🚀 Comfort kills ambition faster than failure.",
    "🩸 If you bleed when I move, don’t call it luck.",
    "💼 Hustle until they whisper your name in rooms you’ve never entered.",
    "🔥 I turn pressure into diamonds and enemies into silence.",
    "🎩 I don’t chase, I replace.",
    "🔑 I keep my circle small but my empire large.",
    "🗡 Loyalty is earned, not requested.",
    "💀 Weakness is contagious — I keep my distance.",
    "⚡ Respect is a currency I collect daily.",
    "🚀 They said I changed. Good. I upgraded.",
    "🦅 My success is the best revenge.",
    "🔥 I move like smoke — silent, but everywhere.",
    "💼 The grind doesn’t text back — it rewards silently."
]

# Enhanced Flirt lines - Kael Vanta style
FLIRT_LINES = [
    "Are you Google? Because you’ve got everything I’m searching for.",
    "Do you believe in love at first chat, or should I type again?",
    "You must be Wi-Fi, because I’m feeling the connection.",
    "Are you a keyboard? Because you’re just my type.",
    "Are you Netflix? Because I could binge you all night.",
    "If kisses were snowflakes, I’d send you a blizzard.",
    "Do you have a name, or can I call you mine?",
    "Your smile must be a cheat code — it’s making my heart level up.",
    "Are you a charger? Because without you, I die.",
    "You’re the reason my screen time went up today.",
    "Are you an algorithm? Because you keep popping up in my thoughts.",
    "You must be trending — because everyone should be talking about you.",
    "If you were a TikTok sound, I’d use you on all my videos.",
    "Are you an update? Because my world feels better with you installed.",
    "Are you a screenshot? Because I want to save you forever.",
    "If beauty was a filter, you’d be the original.",
    "Are you a notification? Because you just lit up my day.",
    "If we were a story, I’d never skip through your parts.",
    "You’re the reason autocorrect knows my heart emoji.",
    "Are you a playlist? Because you’re stuck in my head.",
    "If you were a post, I’d pin you to the top.",
    "Your vibe is the aesthetic my heart’s been searching for.",
    "Are you a viral meme? Because you’re impossible to forget.",
    "If beauty was Wi-Fi, you’d be full bars.",
    "You’re like my FYP — everything I never knew I needed.",
    "Are you a saved draft? Because I’m not ready to let you go public.",
    "If you were a tweet, you’d go viral instantly.",
    "Your name must be ‘Next Level’ because you’re above the rest.",
    "You’re like the perfect caption — making everything better.",
    "If I were a story viewer, I’d watch yours on repeat.",
    "You must be a rare drop, because you’re impossible to find.",
    "Are you an emoji? Because you’re making my texts way cuter.",
    "You’re like a hidden feature — rare and worth discovering.",
    "If you were a comment, I’d pin you forever.",
    "Your vibe is giving main character energy.",
    "You’re like my search history — full of things I’m obsessed with.",
    "Are you the explore page? Because I keep finding new reasons to like you.",
    "You’re the plot twist I didn’t know I needed.",
    "If love was a trend, you’d be the original sound.",
    "You’re like a private story — only the best get to see you.",
    "Are you an upgrade? Because my life just got better with you.",
    "If I had a heart reaction in real life, you’d get it every time.",
    "You’re like my favorite filter — making everything prettier.",
    "Are you my wallpaper? Because you should be on my screen.",
    "You’re the notification I actually want to see.",
    "If I was the caption, you’d be the picture.",
    "You’re like a voice note — better than I expected.",
    "You’re the perfect ratio of looks and personality.",
    "If you were a snap, I’d keep you on streak forever.",
    "You’re like a pinned chat — always at the top of my mind.",
    "I’d text you first, but then you’d know I like you. And where’s the fun in that?",
    "I’m not saying you’re my type… but you definitely made the list.",
    "So… when do we tell people we met in a cooler way than we actually did?",
    "Careful—keep looking at me like that and I might start believing in fate.",
    "You’re either trouble… or my favorite chapter about to happen.",
    "Are you a glitch? Because you just froze my whole thought process.",
    "I’d say you’re dangerous… but I like dangerous.",
    "Don’t blush now—this is only the trailer.",
    "You’re the kind of distraction they warn me about… and I still showed up.",
    "If we were a playlist, you’d be the one I keep on repeat.",
    "Tell me your secrets… I promise I won’t keep them.",
    "You’re not in my league… you’re the league.",
    "Careful. Flirting with me comes with side effects.",
    "You’ve got that ‘hard to get’ look… challenge accepted.",
    "We could be a power couple… or a public menace. I’m good with either.",
    "I don’t chase. But if I did… you’d be worth the cardio.",
    "Is it just me, or did the temperature go up when you walked in?",
    "I’d call you my weakness, but that would mean I have any.",
    "You look like you’d ruin my sleep schedule… and my priorities.",
    "You’re not smooth… you’re lethal.",
    "If I said ‘let’s get into trouble,’ would you ask how much or just say when?",
    "You’ve got that look… like you’re the plot twist.",
    "Are you good at keeping promises? Asking for our future.",
    "You make me want to cancel my other plans. And my backup plans.",
    "I don’t do small talk… so how do we start our story?",
    "Keep looking at me like that and I’ll start thinking you mean it.",
    "You’re the type they write songs about… but never get over.",
    "You’ve got me rethinking my ‘no distractions’ rule.",
    "We could be dangerous together… want to find out how much?",
    "If confidence was a crime, you’d be serving life.",
    "I’d say you’re rare, but rare things get stolen… and I might steal you.",
    "Stop playing… we both know you noticed me first.",
    "You’ve got that main character energy… I just want the co-star role.",
    "If I was the storm, you’d be the reason I hit harder.",
    "You’re the headline. I’m the scandal.",
    "You make ignoring everyone else way too easy.",
    "If we were in a movie, this would be the part where everyone ships us.",
    "You’ve got the kind of face I want to ruin in the best way.",
    "I’d say ‘behave’… but where’s the fun in that?",
    "I wasn’t looking… but somehow, you still found me.",
    "You’ve got that addictive energy. I don’t even want the cure.",
    "They say trouble comes in pairs. So, when’s our first crime?",
    "You look like the reason rules were made… and broken.",
    "I’d call you my weakness… but you make me stronger.",
    "We could skip the games… but you look like you’d be fun to play with.",
    "You’ve got the kind of vibe people write poetry about… badly.",
    "If we lock eyes one more time, I’m taking that as a yes.",
    "You’re the chaos I wouldn’t survive… but I’d still run toward.",
    "I’d tell you you’re dangerous, but I think you already know.",
    "You’re not just my type—you’re the whole blueprint.",
    "You’re like autocorrect—always showing up when I need you most.",
    "Are you Bluetooth? Because I feel paired with you already.",
    "You’re the reason I smile at my screen like a weirdo.",
    "If I were a status update, I’d say ‘taken by your vibe.’",
    "You’re the plot twist my heart didn’t see coming.",
    "Are you a loading screen? Because I’m stuck on you.",
    "You’re like a spoiler alert—I knew you’d steal the show.",
    "If I were a setting, you’d be ‘always on my mind.’",
    "You’re the reason I pretend to be online longer than I should.",
    "Are you a pop-up? Because you just grabbed all my attention.",
    "You’re like a rare emoji—hard to find, impossible to forget.",
    "If I had a playlist for feelings, you’d be track one.",
    "You’re the reason I check my phone with a smile.",
    "Are you a shortcut? Because you just made my day easier.",
    "You’re like a secret feature—unexpected and amazing.",
    "If you were a trend, I’d never want you to end.",
    "You’re the reason my heart has a notification badge.",
    "Are you a voice command? Because I’d follow your lead.",
    "You’re like a hidden gem in my search results.",
    "If I were a browser tab, I’d stay open just for you.",
    "You’re the reason I believe in good algorithms.",
    "Are you a reboot? Because you just refreshed my whole vibe.",
    "You’re like a viral post—everyone should experience you.",
    "If I were a hashtag, I’d be #TakenByYou.",
    "You’re the reason my screen brightness isn’t the only thing glowing.",
    "Are you a DM? Because I’ve been waiting for you"
]

# Enhanced Motivation lines - Kael Vanta style

MOTIVATION_LINES = [
    "Discipline isn’t a vibe — it’s a lifestyle.",
    "No plan B. Just make A work.",
    "Be the force they regret underestimating.",
    "Train insane or remain the same.",
    "Every excuse is an insult to your potential.",
    "Starve distractions. Feed ambition.",
    "Don’t apologize for leveling up.",
    "Success isn’t invited — it storms in.",
    "You weren’t built to break. Act like it.",
    "Focus is the language of killers.",
    "Silence your doubts with savage execution.",
    "Ruthless consistency beats rare talent.",
    "You don’t get ready. You stay ready.",
    "Let your discipline speak louder than motivation.",
    "Fear is a liar. Silence it.",
    "If comfort feels good, you're losing.",
    "Wake up. Show up. Dominate.",
    "You didn’t come this far to be average.",
    "Grind in the dark. Shine in silence.",
    "No weakness. Just adaptation.",
    "Winning isn’t a moment — it’s a mindset.",
    "Let progress be louder than noise.",
    "Failure builds beasts. Don’t flinch.",
    "Be undeniable. Be unshaken.",
    "Nobody claps for the setup. Win anyway.",
    "Become the storm they didn’t expect.",
    "No shortcuts. Just savage steps.",
    "Repetition builds empires.",
    "If they doubt you, you're doing it right.",
    "Power listens. Weakness reacts.",
    "Execution over excuses — every time.",
    "Warriors rest after victory, not before.",
    "One mission. Zero distractions.",
    "Make success look accidental.",
    "Be the blueprint, not the copy.",
    "Every struggle is part of the script.",
    "Winners don’t wait for permission.",
    "If your aura isn’t intimidating, fix your grind.",
    "Stay focused — chaos is camouflage.",
    "You weren’t born legendary. You built that.",
    "Act so powerful they whisper your name.",
    "Your mindset is your weapon.",
    "Keep moving. They’ll understand later.",
    "Your drive should scare the lazy.",
    "No hype. Just results.",
    "Be savage with your time.",
    "Make your silence uncomfortable for your enemies.",
    "They sleep. You sharpen.",
    "Comfort is the leash. Discipline is the freedom.",
    "Be too consistent to be ignored.",
    "Stay low. Strike hard.",
    "One goal. Ruthless pursuit.",
    "Your next move should make noise without sound.",
    "Turn pain into performance.",
    "Outwork everyone in silence.",
    "Keep your aura intimidating. Keep your standards ruthless.",
    "Execution is louder than talk.",
    "Discipline > motivation. Every time.",
    "Be so focused they call you cold.",
    "No luck. Just strategy.",
    "Sharpen your mind like your blade.",
    "Train in chaos. Thrive in calm.",
    "Brilliance comes from brutal discipline.",
    "If you feel nothing, you fear nothing.",
    "Stay hungry. Stay savage.",
    "They won’t believe you — until they have to.",
    "Don’t chase status. Build presence.",
    "Kill excuses. Breed results.",
    "Make fear your servant, not your master.",
    "Show up sharp. Leave sharper.",
    "You were designed to dominate.",
    "Be immune to validation.",
    "Clarity fuels cruelty. Know your target.",
    "Don’t explain your vision — execute it.",
    "Success is earned in silence.",
    "Confidence comes from controlled chaos.",
    "Be a machine. Relentless. Precise.",
    "Results speak. The rest is noise.",
    "Destroy doubt with dedication.",
    "Repetition isn’t boring — it’s brutal power.",
    "Become the ghost they fear at night.",
    "Be the one they whisper about.",
    "Energy focused is energy weaponized.",
    "No emotion. Just motion.",
    "Discipline makes monsters.",
    "Lead with silence. End with dominance.",
    "You're building something they can’t see yet.",
    "Work while they party. Win while they weep.",
    "Own your flaws. Weaponize your edge.",
    "Self-mastery is alpha energy.",
    "Make success your silent obsession.",
    "Outgrow everyone, unapologetically.",
    "Don’t aim to impress. Aim to impact.",
    "Sharp focus. Savage follow-through.",
    "Every minute wasted is self-betrayal.",
    "Hustle till your name is the goal.",
    "The grind owes you nothing. Demand results.",
    "Be your own motivation — and menace.",
    "Push past good. Become legendary.",
    "Be too real to be ignored.",
    "Let the world feel your aura before you speak.",
    "Execute like a villain. Smile like a king.",
    "Consistency over hype. Always.",
    "Fall forward. Bleed forward. Win forward.",
    "Lack of discipline costs empires.",
    "Don’t just work. Conquer.",
    "Make sacrifice your habit.",
    "Don’t beg for success. Build it.",
    "Your aura should make rooms shift.",
    "Let every step be loud in silence.",
    "Practice savage self-respect.",
    "Speak results. Stay lethal.",
    "What you tolerate defines you.",
    "Your reputation starts in your routine.",
    "Train savage. Rest like a king.",
    "Dominate your minutes or lose your legacy.",
    "Be sharp, silent, and surgical.",
    "Never casual. Always calculated.",
    "Your aura deserves ruthlessness.",
    "Wake up with purpose. Go to war with it.",
    "Fight the urge to settle. Slay the urge to quit.",
    "Your habits write your history.",
    "Success isn’t sexy — it’s savage.",
    "Don’t just level up. Overwhelm.",
    "Move like a king. Work like a hunter.",
    "Your time is your territory. Defend it.",
    "Train the mind. Weaponize the soul.",
    "Stop hoping. Start hunting.",
    "Be addicted to elevation.",
    "Don’t wait for motivation. Manufacture momentum.",
    "Respect isn’t given — it’s forced.",
    "Be so disciplined, they assume you’re dangerous.",
    "Don’t play the part. Own the role.",
    "Success loves obsession.",
    "Kill comfort. Birth ambition.",
    "Refuse average like it’s poison.",
    "Make your legacy louder than their doubt.",
    "You don’t need permission to dominate.",
    "Treat your discipline like royalty.",
    "Don’t show off. Show up.",
    "The grind doesn’t forgive. Get savage.",
    "Start with intensity. End with impact.",
    "Act like tomorrow doesn’t exist.",
    "Your past is fuel. Burn it forward.",
    "Every savage win starts with lonely discipline.",
    "No applause needed. Just results.",
    "Win loudly — without saying a word.",
    "Be built from focus. Forged by pain.",
    "Don’t inspire. Intimidate.",
    "Demand more. Fear less.",
    "Your aura should silence small talk.",
    "Be unfazed. Be relentless.",
    "Success is obedience to savage habits.",
    "If you stop now, you betray your potential.",
    "Hustle heavy. Rest never.",
    "Let your actions make enemies nervous.",
    "Your grind should feel like revenge.",
    "Don’t listen to comfort — it's a liar.",
    "Speak goals. Eat doubt.",
    "Be an empire in progress.",
    "Lead with aura. Finish with fire.",
    "Your legend starts at 5AM.",
    "No one’s coming. Become your hero.",
    "Train till your thoughts are lethal.",
    "Be powerful enough to never explain.",
    "Ruthlessness in routine. Royalty in results.",
    "Keep it cold. Keep it calculated.",
    "Attack the week like it owes you respect.",
    "Your silence should scream progress.",
    "Discipline means doing it broken.",
    "Rise. Grind. Ruin limitations.",
    "Be savage. Stay strategic.",
    "Let momentum be your religion.",
    "No backup. Just burn forward.",
    "Don’t chase perfection. Hunt power.",
    "Your aura should do the talking.",
    "Work invisible. Show legendary."
]

# Surprise options
SURPRISE_OPTIONS = [
    "🧠 Challenge: Try 1 hour of complete silence — no phone, no talking, just your thoughts.",
    "🤣 Joke: Why don’t skeletons fight? They don’t have the guts.",
    "📖 Story: A man won the lottery... and disappeared. Nobody ever claimed the money again.",
    "🤯 Fun Fact: Octopuses have three hearts. Two pump blood to the gills, one to the rest of the body.",
    "💔 Sad Fact: Some stars you see at night are already dead. Their light is just still traveling.",
    "🦄 Rare Thing: There's a jellyfish that can reverse its aging and live forever — _Turritopsis dohrnii_.",
    "🔥 Dare: Send the weirdest emoji combo to your best friend. No context.",
    "💡 Weird Truth: Your brain can’t feel pain. That’s why surgeons can operate while you're awake.",
    "🎭 Joke: What do you call fake spaghetti? An impasta.",
    "⚡ Challenge: Don’t use social media for the next 3 hours — come back stronger.",
    "👁 Twist: You never actually touch anything. Electrons repel each other, so technically... no contact.",
    "🎲 Fun Fact: The Eiffel Tower grows about 6 inches taller in summer due to heat expansion.",
    "📖 Micro-Story: She texted 'I'm fine.' He believed her. That was the last message she ever sent.",
    "🌍 Strange Truth: Bananas are radioactive. They're rich in potassium-40.",
    "🧩 Puzzle: You have 8 balls. One weighs more. You can only use a balance scale twice. Find the odd one.",
    "🕵️‍♂️ Fact: Your tongue print is as unique as your fingerprint. No two are alike.",
    "🎭 Joke: Parallel lines have so much in common. It’s a shame they’ll never meet.",
    "🎤 Challenge: Go compliment 3 people with weirdly specific praise today.",
    "🌌 Rare Thing: There's a planet made entirely of diamond called 55 Cancri e.",
    "💔 Sad Fact: Baby elephants mourn the loss of their mothers. They’ve been seen crying.",
    "🧠 Brain Twist: Your mind reads words faster when the first and last letters stay in place. _LiKe tHiS_.",
    "🔒 Secret: In Japan, there’s a hotel where you can sleep in a capsule the size of a coffin. People love it.",
    "🕳️ Unusual Fact: There’s a lake in Tanzania that turns animals into stone — Lake Natron.",
    "⚡ Dare: Write a wild compliment on someone’s recent post. Something absolutely absurd.",
    "🔮 Fun Fact: Wombat poop is cube-shaped. Yup, square turds.",
    "👁 Hidden Truth: The color you see might not be the same someone else sees. Your brain chooses your hues.",
    "🧊 Joke: I asked the librarian for books about paranoia. She whispered, 'They're right behind you.'",
    "🦇 Rare Creature: There’s a bat that can mimic buzzing bees to confuse predators.",
    "🎯 Challenge: Say “hi” to 5 strangers today and smile like you know a secret.",
    "🎬 Story: A man had a recurring dream about a number. He played it in the lottery. Won millions.",
    "📦 Weird Truth: IKEA was founded by a 17-year-old who started by selling matches door-to-door.",
    "🥶 Sad Fact: There's a creature called the axolotl that never grows up — it dies a child.",
    "🎭 Joke: Why did the scarecrow win an award? Because he was outstanding in his field.",
    "🌕 Rare Phenomenon: Moonbows are real — rainbows at night from moonlight, super rare.",
    "⚔️ Dare: Leave a compliment on your rival’s post. Reverse psychology activated.",
    "🌌 Fact: The universe has no edge. It’s infinite, expanding, and curving — your brain wasn’t built for this.",
    "👻 Micro-Story: She deleted the chat but kept the screenshots. Some memories deserve evidence.",
    "🧠 Fun Fact: The human brain runs on the same amount of electricity as a dim lightbulb.",
    "🔮 Twist: You're 50% banana. Humans share half their DNA with them.",
    "🔥 Challenge: Do 10 pushups right now. If you don’t, accept that someone just passed you.",
    "🎭 Joke: My phone battery lasts longer than most of my relationships.",
    "🎯 Rare Skill: There's a guy who can solve Rubik’s cubes blindfolded — in under 20 seconds.",
    "💔 Sad Truth: Some turtles can’t retract into their shells. They're permanently vulnerable.",
    "🌍 Fun Fact: Sharks existed before trees. That's ancient savagery.",
    "🕵️‍♂️ Micro-Story: A stranger said “You dropped this.” It was a photo from my childhood — I’d never met them before.",
    "🔒 Hidden Fact: There's a species of octopus that mates once… then dies.",
    "🧠 Challenge: Say one thing you like about yourself out loud. Weird? Yes. Necessary? Also yes.",
    "🎭 Joke: What’s orange and sounds like a parrot? A carrot.",
    "🪐 Rare Discovery: Scientists found water vapor on a planet 124 light-years away.",
    "🔥 Dare: Screenshot this and send it to someone who wouldn’t expect it.",
    "🔍 Weird Truth: Sloths can hold their breath longer than dolphins.",
    "🧊 Sad Fact: Trees communicate underground — when one dies, others try to send nutrients.",
    "🧠 Fun Fact: A snail can sleep for 3 years. That’s a real power nap.",
    "🧩 Puzzle: I speak without a mouth and hear without ears. I have no body, but I come alive with wind. What am I? (Answer: Echo)",
    "🎭 Joke: I told my computer I needed a break, and now it won’t stop sending errors.",
    "🌕 Fun Fact: There’s an island in Japan inhabited only by cats — no humans live there.",
    "🪄 Micro-Story: She waited every night at the same spot. He never came, but the stars remembered.",
    "🎯 Challenge: Give your day a title. Just one line. Make it sound epic.",
    "🦄 Fun Fact: A group of flamingos is called a “flamboyance.”",
    "🔮 Truth: Most of the universe is empty space — you’re built from cosmic leftovers.",
    "🔥 Dare: Compliment someone dramatically like it’s a scene from a movie.",
    "🎭 Joke: I tried to be a baker… but I couldn’t make enough dough.",
    "🧊 Sad Fact: Some birds die from heartbreak if their mate is lost.",
    "👁 Fact: You blink around 15–20 times a minute — that’s 28,800 times a day.",
    "🎯 Challenge: Don’t complain for the next hour. If you do… restart the timer.",
    "🕵️‍♂️ Weird Truth: Humans glow in the dark — it’s just too faint to see with the naked eye.",
    "🔥 Micro-Dare: Send the message 'I dare you to surprise me' to the next person online.",
    "🎭 Joke: My internet’s so slow, it’s buffering emotions now.",
    "🌌 Rare Map: There’s a star with a heartbeat — and you can listen to it online.",
    "💔 Sad Truth: Male seahorses give birth — and sometimes die during labor.",
    "🎭 Joke: I tried to catch fog yesterday… I mist.",
    "🤯 Rare Phenomenon: There’s a thunderstorm that’s been raging for 1000 years over Venezuela — the Catatumbo storm.",
    "🔥 Dare: Put your phone down, stare into space for 2 minutes, and see what thought surprises you.",
    "💔 Sad Fact: Koalas can’t recognize eucalyptus leaves when they’re off the tree — they’ll starve next to a plate of food.",
    "🎯 Challenge: Do the opposite of what you’d normally do today — just once.",
    "🧠 Weird Truth: Your memories aren’t exact. Every time you remember something, you distort it slightly.",
    "🌕 Fact: There are more stars in the universe than grains of sand on Earth.",
    "🎭 Joke: What did the ocean say to the beach? Nothing, it just waved.",
    "🔮 Rare Discovery: There’s a flower that only blooms once every 7 years — the corpse flower — and it smells like death.",
    "🤖 Micro-Story: The robot learned love… the moment it was turned off.",
    "🧊 Sad Truth: Some fish feel pain and fear — yet they’re often treated like they can’t.",
    "🔥 Dare: Write a poem using only emojis and send it to someone serious.",
    "👁 Fact: Your pupils dilate when you look at something you love… even if it’s chocolate cake.",
    "🎲 Challenge: Flip a coin for your next decision — big or small.",
    "🧠 Brain Twister: If Pinocchio says “My nose will grow now,” is he lying?",
    "🎭 Joke: I told my plants I love them. They’re growing faster out of fear.",
    "🪐 Fun Fact: Saturn’s moon Titan has lakes made of liquid methane. Cold alien vibes.",
    "🕵️‍♂️ Micro-Story: He saw her reflection… but she wasn’t there.",
    "💔 Sad Truth: The oldest known animal was a clam that lived 500 years — they killed it to find out.",
    "🧩 Puzzle: What has cities, but no houses; forests, but no trees; and rivers, but no water? (Answer: A map)",
    "🔥 Dare: Pretend you’re a villain for the next conversation. Unleash the drama.",
    "🌍 Weird Truth: There’s a fungus that controls ant behavior — a real zombie fungus.",
    "🎭 Joke: I used to play piano by ear, but now I use my hands.",
    "🧊 Rare Thing: Snow can be pink — called “watermelon snow,” thanks to algae.",
    "📖 Micro-Story: She waited every night at the same spot. He never came, but the stars remembered.",
    "🧠 Fun Fact: Your stomach gets a new lining every 3–4 days so it doesn’t digest itself.",
    "🔥 Challenge: Reply to this using Shakespearean language. Go thee forth!",
    "🎯 Dare: Put on socks that don’t match — it’s chaos season.",
    "🌕 Weird Truth: Earth’s rotation is slowing very slightly — days are getting longer.",
    "🎭 Joke: I accidentally swallowed food coloring — now I feel like I dyed a little inside.",
    "🧊 Sad Fact: Some whales sing songs that no other whale responds to. They swim alone.",
    "🌌 Fact: The Milky Way smells like rum and raspberries. Not kidding — scientists found those molecules.",
    "🎯 Challenge: Introduce yourself using 5 emojis only.",
    "🔮 Strange Truth: There are more synapses in your brain than stars in the galaxy.",
    "🧠 Twist: Your dreams often forget human faces — even ones you know.",
    "🎭 Joke: I told my friend 10 jokes to make him laugh. Sadly, no pun in ten did.",
    "🎤 Dare: Speak in rhymes for the next 2 messages.",
    "💔 Sad Truth: Pandas don’t know how to mate in captivity. Many die without reproducing.",
    "🧩 Puzzle: The more you take, the more you leave behind. What am I? (Answer: Footsteps)",
    "🌍 Rare Fact: There’s a mushroom that glows in the dark — bioluminescent fungi.",
    "🕵️‍♂️ Story: He got a message from his future self. It only said: “Run.”",
    "🔥 Dare: Challenge someone to a staring contest. Send “👀 You. Me. No blink.”",
    "🎭 Joke: Why did the math book look sad? It had too many problems.",
    "🌌 Fun Fact: Neutron stars are so dense, a sugar cube of one weighs a billion tons.",
    "🎯 Challenge: Choose one word to live by today. Make it bold.",
    "🧠 Brain Trick: You can’t hum while holding your nose. Try it.",
    "🌕 Rare Thing: There’s a crater on the moon called the “Sea of Tranquility.” It’s silent — forever.",
    "🔥 Dare: Text someone 'I know your secret' and don’t reply for 5 minutes.",
    "🧊 Sad Fact: Fireflies are disappearing — light pollution affects their mating signals.",
    "🎭 Joke: I asked Siri why I’m single. She activated the front camera.",
    "🌍 Strange Fact: Water can boil and freeze at the same time — triple point physics magic.",
    "📖 Micro-Story: She woke up… and the calendar said it was 2040.",
    "🧠 Fun Fact: The brain uses more energy when you’re daydreaming than when focused.",
    "🔮 Weird Truth: Your bones are 5x stronger than steel of the same density.",
    "🎯 Challenge: Tell someone a compliment so weird it sounds like a spell.",
    "🦄 Rare Creature: There’s a sea slug that creates its own chlorophyll — animal photosynthesis.",
    "🔥 Dare: Say something completely honest today, even if awkward.",
    "🧊 Sad Fact: A butterfly only lives for a few weeks… and some, just days.",
    "🎭 Joke: Why can’t your nose be 12 inches long? Because then it’d be a foot.",
    "🌌 Mystery Fact: Scientists don’t know what 95% of the universe is made of — dark matter and dark energy rule.",
    "🎯 Final Challenge: Choose the weirdest, funniest, or most mysterious surprise and act on it now. Surprise _yourself_."
]

async def handle_custom_commands(message: Message):
    """Enhanced command handler with auto-detection and safety"""
    try:
        text = message.text.lower() if message.text else ""
        command = text.split()[0] if text.startswith('/') else detect_command_intent(text)
        user_id = message.from_user.id

        # Log command usage safely
        try:
            add_message(user_id, "command", command or "unknown")
        except:
            pass  # Continue even if logging fails

        # Direct command matching with explicit checks
        if command == "/help" or "help" in text:
            await show_help(message)
        elif command == "/alphacode" or (command and command.startswith("/alpha")):
            await send_alpha_quote(message)
        elif command == "/flirt":
            await send_flirt_line(message)
        elif command == "/motivate":
            await send_motivation(message)
        elif command == "/surpriseme":
            await send_surprise(message)
        elif command == "/getadvice":
            await get_advice(message)
        elif command == "/makeaplan":
            await make_plan(message)
        elif command == "/research":
            await handle_research(message)
        elif command == "/checkmodels":
            await check_ai_models(message)
        elif command == "/summarize":
            await handle_summarize(message)
        elif command == "/bio" or command == "/customize":
            await handle_bio_customize(message)
        elif command == "/rules":
            await show_rules(message)
        elif command == "/news":
            await handle_news_command(message)
        else:
            # Handle non-command detection
            if "alpha" in text or "mindset" in text:
                await send_alpha_quote(message)
            elif "flirt" in text or "pickup" in text:
                await send_flirt_line(message)
            elif "motivate" in text or "motivation" in text:
                await send_motivation(message)
            elif "surprise" in text:
                await send_surprise(message)
            elif "advice" in text:
                await get_advice(message)
            elif "plan" in text:
                await make_plan(message)
            elif "research" in text:
                await handle_research(message)
            elif "news" in text or "headlines" in text or "latest" in text:
                await handle_news_command(message)
            else:
                await message.answer("🤔 Command not recognized. Use /help to see available options.\n\n— Kael Vanta ®️")

    except Exception as e:
        log_error(f"Command handler error: {e}")
        await message.answer("⚠️ Something went sideways. Try again or use /help.\n\n— Kael Vanta ®️")

def detect_command_intent(text):
    """Auto-detect commands from natural language"""
    text_lower = text.lower()

    if any(word in text_lower for word in ["help", "commands", "what can you do"]):
        return "/help"
    elif any(word in text_lower for word in ["alpha", "mindset", "quote", "motivation"]):
        return "/alphacode"
    elif any(word in text_lower for word in ["flirt", "pickup", "line"]):
        return "/flirt"
    elif any(word in text_lower for word in ["advice", "suggest", "recommend"]):
        return "/getadvice"
    elif any(word in text_lower for word in ["plan", "strategy", "steps"]):
        return "/makeaplan"
    elif any(word in text_lower for word in ["research", "search", "find info"]):
        return "/research"
    elif any(word in text_lower for word in ["surprise", "random", "fun"]):
        return "/surpriseme"
    elif any(word in text_lower for word in ["summarize", "summary", "tldr"]):
        return "/summarize"
    elif any(word in text_lower for word in ["news", "headlines", "latest"]):
        return "/news"

    return text.split()[0] if text.startswith('/') else None

async def show_help(message: Message):
    """Enhanced help with all commands"""
    try:
        help_text = """🧠 <b>COREVANTA_AI Commands</b> — Kael Vanta Style 🔥

<b>🎯 Alpha Commands:</b>
/alphacode — Savage mindset quotes
/flirt — Elite pickup lines
/motivate — Power motivation boost
/getadvice — Direct life advice
/makeaplan — Step-by-step action plans
/surpriseme — Random alpha energy
/news [query] — Latest global & Ghana news

<b>🤖 Smart Features:</b>
/research [topic] — AI + web research
/summarize [text] — Smart summaries
/checkmodels — Live AI status
/bio — Customize your experience

<b>💬 Chat:</b>
Talk naturally — I auto-detect commands and remember context!

<b>⚙️ System:</b>
/rules — View core rules

— Powered by Kael Vanta ®️"""
        await message.answer(help_text)
    except Exception as e:
        log_error(f"Show help error: {e}")
        await message.answer("⚠️ Help temporarily unavailable. Try /start\n\n— Kael Vanta ®️")

async def send_alpha_quote(message: Message):
    """Send alpha mindset quote"""
    quote = random.choice(ALPHA_QUOTES)
    await message.answer(f"🧠 <b>{quote}</b>\n\n— Kael Vanta ®️")

async def send_flirt_line(message: Message):
    """Send flirt line"""
    line = random.choice(FLIRT_LINES)
    await message.answer(f"💘 <b>{line}</b>\n\n— Kael Vanta ®️")

async def send_motivation(message: Message):
    """Send motivation"""
    motivation = random.choice(MOTIVATION_LINES)
    await message.answer(f"{motivation}\n\n— Kael Vanta ®️")

async def send_surprise(message: Message):
    """Send surprise content"""
    surprise = random.choice(SURPRISE_OPTIONS)
    await message.answer(f"{surprise}\n\n— Kael Vanta ®️")

async def get_advice(message: Message):
    """Get personalized advice"""
    try:
        user_prefs = get_user_preferences(message.from_user.id)
        context = message.text.replace("/getadvice", "").strip()

        if not context:
            await message.answer("💡 <b>What do you need advice on?</b>\n\nExample: /getadvice career change\n\n— Kael Vanta ®️")
            return

        prompt = f"Give direct, actionable advice for: {context}. Keep it practical and motivational, Kael Vanta style."

        api_items = list(API_KEYS.items())
        if not api_items:
            await message.answer("⚠️ AI temporarily unavailable. Try again later!\n\n— Kael Vanta ®️")
            return

        model, key = random.choice(api_items)
        advice = await get_ai_response(prompt, model, key, message.from_user.id)
        await message.answer(f"💡 <b>Advice:</b>\n\n{advice}")

    except Exception as e:
        log_error(f"Advice generation error: {e}")
        await message.answer("⚠️ Advice system temporarily down. Try again!\n\n— Kael Vanta ®️")

async def make_plan(message: Message):
    """Create step-by-step plans"""
    try:
        goal = message.text.replace("/makeaplan", "").strip()

        if not goal:
            await message.answer("🎯 <b>What's your goal?</b>\n\nExample: /makeaplan learn Python programming\n\n— Kael Vanta ®️")
            return

        prompt = f"Create a clear, actionable step-by-step plan for: {goal}. Number the steps and keep it practical."

        api_items = list(API_KEYS.items())
        if not api_items:
            await message.answer("⚠️ AI temporarily unavailable. Try again later!\n\n— Kael Vanta ®️")
            return

        model, key = random.choice(api_items)
        plan = await get_ai_response(prompt, model, key, message.from_user.id)
        await message.answer(f"🎯 <b>Action Plan:</b>\n\n{plan}")

    except Exception as e:
        log_error(f"Plan generation error: {e}")
        await message.answer("⚠️ Plan generator temporarily down. Try again!\n\n— Kael Vanta ®️")

async def handle_research(message: Message):
    """Enhanced research with browsing and citations"""
    try:
        from core_features.research_enhanced import ResearchEngine # Import statement was duplicated, fixed
        engine = ResearchEngine()
        await engine.handle_message(message)
    except Exception as e:
        await message.answer(f"⚠️ Research failed: {str(e)}\n\n— Kael Vanta ®️")
        log_error(f"Research error: {e}")

async def handle_news_command(message: Message):
    """Handle news fetching command"""
    try:
        user_input = message.text.strip()

        # Extract query if provided
        query = None
        if user_input.startswith('/news'):
            parts = user_input.split('/news', 1)
            if len(parts) > 1 and parts[1].strip():
                query = parts[1].strip()
        else:
            # Extract query from natural language if it's not a direct command
            # This part will need refinement based on how natural language is processed
            # For now, if it's not /news, assume the whole message is the query
            if not user_input.startswith('/'):
                 query = user_input


        # Show typing indicator
        await message.chat.send_action("typing")

        # Fetch news
        news_items = get_news(query, max_results=15)

        # Format for Telegram
        formatted_news = format_news_for_telegram(news_items, max_items=8)

        await message.answer(formatted_news)

        # Log interaction
        add_message(message.from_user.id, "user", f"news: {query or 'latest'}")
        add_message(message.from_user.id, "assistant", f"Provided {len(news_items)} news articles")

    except Exception as e:
        await message.answer(f"📰 <b>News service temporarily down</b>\n\nTry again in a moment!\n\n— <b>Kael Vanta ®️</b>")
        log_error(f"News command error: {e}")


async def handle_bio_customize(message: Message):
    """Handle user customization"""
    try:
        user_id = message.from_user.id
        text_parts = message.text.split(None, 1)

        if len(text_parts) < 2:
            prefs = get_user_preferences(user_id)
            current_prefs = "\n".join([f"• {k}: {v}" for k, v in prefs.items()]) if prefs else "None set"

            await message.answer(f"⚙️ <b>Customize Your Experience</b>\n\n<b>Current preferences:</b>\n{current_prefs}\n\n<b>Usage:</b>\n/bio tone=casual\n/bio style=detailed\n/bio focus=business\n\n— Kael Vanta ®️")
            return

        settings = text_parts[1]
        if "=" in settings:
            key, value = settings.split("=", 1)
            set_user_preference(user_id, key.strip(), value.strip())
            await message.answer(f"✅ Updated {key} to {value}\n\n— Kael Vanta ®️")
        else:
            await message.answer("⚠️ Format: /bio key=value\n\n— Kael Vanta ®️")

    except Exception as e:
        log_error(f"Bio customize error: {e}")
        await message.answer("⚠️ Customization temporarily down.\n\n— Kael Vanta ®️")

async def show_rules(message: Message):
    """Show core rules"""
    rules_text = """📋 <b>COREVANTA AI - Core Rules</b>

🛡️ <b>Safety First:</b>
• Never expose credentials
• Backup before major changes
• Monitor error logs continuously

💪 <b>Performance Standards:</b>
• 24/7 uptime commitment
• Quick response times
• Smart command detection

🎯 <b>Personality:</b>
• Kael Vanta alpha energy
• Direct but respectful
• Solution-focused approach

— Kael Vanta ®️"""
    await message.answer(rules_text)

async def check_ai_models(message: Message):
    """Check status of all AI models with enhanced reporting"""
    await message.answer("🧠 <b>Checking AI Models...</b>")

    report = "🤖 <b>COREVANTA AI Model Status</b>\n\n"
    working_count = 0

    for model, key in API_KEYS.items():
        try:
            # Using a placeholder for the actual API call to check model status
            # In a real scenario, this would be an actual call to the model's API
            # For demonstration, we'll simulate a response
            # await get_ai_response("Test", model, key, message.from_user.id) # This might be too heavy, let's simulate
            # Simulating a successful check for demonstration
            if model and key: # Basic check if key and model exist
                report += f"✅ <code>{model.split('/')[-1]}</code> — Online\n"
                working_count += 1
            else:
                report += f"⚠️ <code>{model.split('/')[-1]}</code> — Configuration issue\n"

        except Exception as e:
            report += f"❌ <code>{model.split('/')[-1]}</code> — Error: {str(e)[:20]}...\n"
            log_error(f"Model check failed for {model}: {e}")

    health_status = "🔥 EXCELLENT" if working_count == len(API_KEYS) else "⚡ GOOD" if working_count >= len(API_KEYS) // 2 else "⚠️ DEGRADED"

    report += f"\n🔥 <b>{working_count}/{len(API_KEYS)} models active</b>"
    report += f"\n🏥 System Health: {health_status}\n\n— Kael Vanta ®️"
    await message.answer(report)

async def handle_summarize(message: Message):
    """Enhanced summarize with structured TL;DR format"""
    try:
        text_parts = message.text.split(None, 1)
        if len(text_parts) < 2:
            await message.answer("""📝 <b>Smart Summarizer</b>

<b>Usage:</b> /summarize [your text or URL]

<b>Output Format:</b>
• TL;DR - Quick summary
• Key Points - Main insights
• Action Items - What to do next

<b>Example:</b> /summarize [long article text]

— Kael Vanta Syndicate ®️""")
            return

        content = text_parts[1]

        if len(content) < 50:
            await message.answer("⚠️ Content too short to summarize. Need at least 50 characters.\n\n— Kael Vanta Syndicate ®️")
            return

        prompt = f"""Analyze and summarize this content in a structured format:

CONTENT:
{content}

Provide:
1. **TL;DR** - One sentence summary
2. **Key Points** - 3-5 main insights (bullet points)
3. **Action Items** - What should someone do with this info
4. **Complexity Rating** - Simple/Medium/Complex

Keep it concise but complete."""

        from keys import get_api_for_task
        base_url, api_key, model = get_api_for_task("summarize")
        summary = await get_ai_response(prompt, model, api_key, message.from_user.id, "summarize", base_url)
        await message.answer(f"📋 <b>Smart Summary:</b>\n\n{summary}")

    except Exception as e:
        log_error(f"Summarization error: {e}")
        await message.answer(f"❌ Summarization failed. Try again!\n\n— Kael Vanta Syndicate ®️")

async def handle_image(message: Message):
    """Enhanced image analysis with better error handling"""
    try:
        photo = message.photo[-1]
        file_info = await message.bot.get_file(photo.file_id)
        file_url = f"https://api.telegram.org/file/bot{message.bot.token}/{file_info.file_path}"

        await message.answer("🔍 <b>Analyzing your image...</b>")

        try:
            import replicate
            # Ensure you have REPLICATE_API_TOKEN set in your environment variables or replace it directly
    

            if output and isinstance(output, list) and len(output) > 0:
                # The output from replicate can be a list of strings or a single string.
                # Assuming the output is a list of strings or a single string description.
                analysis_text = "".join(output) if isinstance(output, list) else output
                await message.answer(f"🖼️ <b>Image Analysis:</b>\n\n{analysis_text}\n\n— Kael Vanta ®️")
            else:
                await message.answer("❌ Could not analyze image. The model returned no description. Try another one!\n\n— Kael Vanta ®️")

        except ImportError:
            await message.answer("⚠️ Image analysis library (replicate) not found. Please install it.\n\n— Kael Vanta ®️")
        except Exception as e:
            log_error(f"Image analysis error: {e}")
            await message.answer(f"❌ Image analysis failed. An error occurred: {str(e)}\n\n— Kael Vanta ®️")

    except Exception as e:
        log_error(f"Image processing error: {e}")
        await message.answer(f"❌ Failed to process image. Ensure you sent a valid image file.\n\n— Kael Vanta ®️")
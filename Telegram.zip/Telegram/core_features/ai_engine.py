import requests
import json
from memory import get_conversation, add_message
from core_features.personality import apply_kael_vanta_personality
from core_features.bio_prefs import get_user_prefs, build_personality_prompt
from keys import API_KEYS, get_api_for_task, mark_api_failure, mark_api_success
import aiohttp
import asyncio
from utils.logger import log_error

async def get_ai_response(prompt, model=None, api_key=None, user_id=None, task_type="default_chat"):
    """Enhanced AI response with failover and personality integration"""
    try:
        # Get user preferences for personality
        prefs = get_user_prefs(user_id) if user_id else {}

        # Build personality prompt
        personality_prompt = build_personality_prompt(prefs)

        # Combine prompts with enhanced formatting
        full_prompt = f"{personality_prompt}\n\nUser: {prompt}\n\nProvide a concise, structured response with bullet points where helpful. Keep code in proper fenced blocks.\n\nAssistant:"

        # Try APIs with failover
        for attempt in range(3):  # Max 3 total attempts across APIs
            try:
                # Get API configuration
                base_url, api_key, model, api_name = get_api_for_task(task_type)

                headers = {
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                }

                data = {
                    "model": model,
                    "messages": [{"role": "user", "content": full_prompt}],
                    "max_tokens": 800,
                    "temperature": 0.7
                }

                timeout = aiohttp.ClientTimeout(total=25)
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    async with session.post(
                        f"{base_url}/chat/completions",
                        headers=headers,
                        json=data
                    ) as response:
                        if response.status == 200:
                            result = await response.json()
                            mark_api_success(api_name)
                            # Save memory
                            add_message(user_id, "user", prompt) # Use original prompt for memory
                            add_message(user_id, "assistant", result["choices"][0]["message"]["content"])
                            return result["choices"][0]["message"]["content"]
                        elif response.status in [401, 403, 429, 500, 502, 503, 504]:
                            # Mark failure and try next API
                            mark_api_failure(api_name)
                            log_error(f"API {api_name} failed with status {response.status}")
                            continue
                        else:
                            log_error(f"AI API unexpected status: {response.status}")
                            continue

            except asyncio.TimeoutError:
                mark_api_failure(api_name)
                log_error(f"AI request timeout on {api_name}")
                continue
            except Exception as e:
                mark_api_failure(api_name)
                log_error(f"AI engine error on {api_name}: {e}")
                continue

        # All APIs failed
        return "🔥 All AI systems temporarily down. The genius needs a moment!\n\n— Kael Vanta ®️"

    except Exception as e:
        log_error(f"AI engine critical error: {e}")
        return "🧠 AI brain critical glitch. Engineering team notified!\n\n— Kael Vanta ®️"
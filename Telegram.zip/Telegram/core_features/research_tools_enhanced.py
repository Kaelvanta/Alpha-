
"""
Enhanced Research Tools - Advanced intelligence gathering with multiple sources
arXiv integration, RSS monitoring, enhanced Wikipedia, caching, and source cards
"""
import json
import os
import re
import time
import hashlib
from datetime import datetime, timedelta
from collections import defaultdict
import requests
from bs4 import BeautifulSoup
from memory import log_error

class EnhancedResearchTools:
    def __init__(self):
        self.cache_dir = "data/research_cache"
        self.cache_duration = 3600  # 1 hour
        self.source_weights = {
            "arxiv": 0.9,
            "wikipedia": 0.8,
            "news": 0.7,
            "rss": 0.6,
            "web": 0.5
        }
        self.setup_cache()
    
    def setup_cache(self):
        """Setup research cache directory"""
        try:
            os.makedirs(self.cache_dir, exist_ok=True)
        except Exception as e:
            log_error(f"Cache setup failed: {e}")
    
    def get_cache_key(self, query, source):
        """Generate cache key for query and source"""
        combined = f"{query}:{source}".lower()
        return hashlib.md5(combined.encode()).hexdigest()
    
    def get_cached_result(self, cache_key):
        """Get cached research result"""
        try:
            cache_file = os.path.join(self.cache_dir, f"{cache_key}.json")
            if os.path.exists(cache_file):
                with open(cache_file, "r") as f:
                    data = json.load(f)
                
                # Check if cache is still valid
                cached_time = datetime.fromisoformat(data["timestamp"])
                if datetime.now() - cached_time < timedelta(seconds=self.cache_duration):
                    return data["results"]
            
            return None
        except Exception as e:
            log_error(f"Cache retrieval failed: {e}")
            return None
    
    def cache_result(self, cache_key, results):
        """Cache research results"""
        try:
            cache_file = os.path.join(self.cache_dir, f"{cache_key}.json")
            cache_data = {
                "timestamp": datetime.now().isoformat(),
                "results": results
            }
            with open(cache_file, "w") as f:
                json.dump(cache_data, f, indent=2)
        except Exception as e:
            log_error(f"Cache storage failed: {e}")
    
    async def search_arxiv(self, query, max_results=5):
        """Search arXiv for academic papers"""
        try:
            cache_key = self.get_cache_key(query, "arxiv")
            cached = self.get_cached_result(cache_key)
            if cached:
                return cached
            
            # arXiv API search
            arxiv_url = "http://export.arxiv.org/api/query"
            params = {
                "search_query": f"all:{query}",
                "start": 0,
                "max_results": max_results,
                "sortBy": "relevance",
                "sortOrder": "descending"
            }
            
            response = requests.get(arxiv_url, params=params, timeout=10)
            response.raise_for_status()
            
            # Parse XML response
            soup = BeautifulSoup(response.content, 'xml')
            entries = soup.find_all('entry')
            
            results = []
            for entry in entries:
                try:
                    title = entry.find('title').text.strip()
                    authors = [author.find('name').text for author in entry.find_all('author')]
                    summary = entry.find('summary').text.strip()
                    published = entry.find('published').text[:10]  # YYYY-MM-DD
                    link = entry.find('id').text
                    
                    results.append({
                        "title": title,
                        "authors": authors,
                        "summary": summary[:300] + "..." if len(summary) > 300 else summary,
                        "published": published,
                        "url": link,
                        "source": "arXiv",
                        "credibility": 0.95,
                        "type": "academic_paper"
                    })
                except Exception as e:
                    log_error(f"ArXiv entry parsing failed: {e}")
                    continue
            
            self.cache_result(cache_key, results)
            return results
            
        except Exception as e:
            log_error(f"ArXiv search failed: {e}")
            return [{"error": f"ArXiv search failed: {str(e)}", "source": "arXiv"}]
    
    async def search_wikipedia_enhanced(self, query):
        """Enhanced Wikipedia search with better parsing"""
        try:
            cache_key = self.get_cache_key(query, "wikipedia")
            cached = self.get_cached_result(cache_key)
            if cached:
                return cached
            
            # Wikipedia API search
            search_url = "https://en.wikipedia.org/api/rest_v1/page/summary/" + query.replace(" ", "_")
            
            response = requests.get(search_url, timeout=10)
            if response.status_code == 200:
                data = response.json()
                
                result = {
                    "title": data.get("title", query),
                    "summary": data.get("extract", "No summary available"),
                    "url": data.get("content_urls", {}).get("desktop", {}).get("page", ""),
                    "thumbnail": data.get("thumbnail", {}).get("source", ""),
                    "source": "Wikipedia",
                    "credibility": 0.85,
                    "type": "encyclopedia",
                    "last_modified": data.get("timestamp", "")
                }
                
                # Get additional sections if available
                if "url" in result and result["url"]:
                    sections = await self.get_wikipedia_sections(result["url"])
                    if sections:
                        result["sections"] = sections
                
                results = [result]
            else:
                # Fallback to search API
                results = await self.wikipedia_search_fallback(query)
            
            self.cache_result(cache_key, results)
            return results
            
        except Exception as e:
            log_error(f"Wikipedia search failed: {e}")
            return [{"error": f"Wikipedia search failed: {str(e)}", "source": "Wikipedia"}]
    
    async def wikipedia_search_fallback(self, query):
        """Fallback Wikipedia search using search API"""
        try:
            search_url = "https://en.wikipedia.org/w/api.php"
            params = {
                "action": "query",
                "list": "search",
                "srsearch": query,
                "format": "json",
                "srlimit": 3
            }
            
            response = requests.get(search_url, params=params, timeout=10)
            data = response.json()
            
            results = []
            for item in data.get("query", {}).get("search", []):
                results.append({
                    "title": item.get("title", ""),
                    "summary": re.sub(r'<[^>]+>', '', item.get("snippet", "")),
                    "url": f"https://en.wikipedia.org/wiki/{item.get('title', '').replace(' ', '_')}",
                    "source": "Wikipedia",
                    "credibility": 0.85,
                    "type": "encyclopedia"
                })
            
            return results
            
        except Exception as e:
            log_error(f"Wikipedia fallback failed: {e}")
            return []
    
    async def get_wikipedia_sections(self, page_url):
        """Get Wikipedia page sections"""
        try:
            # Extract page title from URL
            title = page_url.split("/wiki/")[-1] if "/wiki/" in page_url else ""
            if not title:
                return []
            
            sections_url = "https://en.wikipedia.org/w/api.php"
            params = {
                "action": "parse",
                "page": title,
                "format": "json",
                "prop": "sections",
                "disabletoc": "1"
            }
            
            response = requests.get(sections_url, params=params, timeout=5)
            data = response.json()
            
            sections = []
            for section in data.get("parse", {}).get("sections", [])[:5]:  # Limit to 5 sections
                sections.append({
                    "title": section.get("line", ""),
                    "level": section.get("level", 0)
                })
            
            return sections
            
        except Exception as e:
            log_error(f"Wikipedia sections failed: {e}")
            return []
    
    async def search_news_sources(self, query, max_results=5):
        """Search news sources for current information"""
        try:
            cache_key = self.get_cache_key(query, "news")
            cached = self.get_cached_result(cache_key)
            if cached:
                return cached
            
            # Multiple news sources to try
            news_sources = [
                "https://news.google.com/rss/search?q={}",
                "https://feeds.reuters.com/reuters/topNews",
                "https://rss.cnn.com/rss/edition.rss"
            ]
            
            results = []
            for source_url in news_sources:
                try:
                    if "{}" in source_url:
                        url = source_url.format(query.replace(" ", "%20"))
                    else:
                        url = source_url
                    
                    response = requests.get(url, timeout=10)
                    soup = BeautifulSoup(response.content, 'xml')
                    
                    items = soup.find_all('item')[:3]  # Limit per source
                    for item in items:
                        try:
                            title = item.find('title').text
                            description = item.find('description')
                            description_text = description.text if description else ""
                            link = item.find('link').text if item.find('link') else ""
                            pub_date = item.find('pubDate')
                            pub_date_text = pub_date.text if pub_date else ""
                            
                            results.append({
                                "title": title,
                                "summary": description_text[:200] + "..." if len(description_text) > 200 else description_text,
                                "url": link,
                                "published": pub_date_text,
                                "source": "News",
                                "credibility": 0.75,
                                "type": "news_article"
                            })
                        except Exception as e:
                            continue
                            
                    if len(results) >= max_results:
                        break
                        
                except Exception as e:
                    continue
            
            self.cache_result(cache_key, results[:max_results])
            return results[:max_results]
            
        except Exception as e:
            log_error(f"News search failed: {e}")
            return [{"error": f"News search failed: {str(e)}", "source": "News"}]
    
    async def monitor_rss_feeds(self, feed_urls, keywords):
        """Monitor RSS feeds for keywords"""
        try:
            results = []
            for feed_url in feed_urls:
                try:
                    response = requests.get(feed_url, timeout=10)
                    soup = BeautifulSoup(response.content, 'xml')
                    
                    items = soup.find_all('item')
                    for item in items:
                        title = item.find('title')
                        description = item.find('description')
                        
                        title_text = title.text if title else ""
                        desc_text = description.text if description else ""
                        
                        # Check if any keywords match
                        content = f"{title_text} {desc_text}".lower()
                        if any(keyword.lower() in content for keyword in keywords):
                            link = item.find('link')
                            pub_date = item.find('pubDate')
                            
                            results.append({
                                "title": title_text,
                                "summary": desc_text[:200] + "..." if len(desc_text) > 200 else desc_text,
                                "url": link.text if link else "",
                                "published": pub_date.text if pub_date else "",
                                "source": "RSS Feed",
                                "credibility": 0.65,
                                "type": "rss_item",
                                "matched_keywords": [kw for kw in keywords if kw.lower() in content]
                            })
                            
                except Exception as e:
                    log_error(f"RSS feed processing failed: {e}")
                    continue
            
            return results
            
        except Exception as e:
            log_error(f"RSS monitoring failed: {e}")
            return []
    
    def generate_source_cards(self, results):
        """Generate formatted source cards for results"""
        cards = []
        
        for i, result in enumerate(results, 1):
            if "error" in result:
                continue
                
            credibility_stars = "★" * int(result.get("credibility", 0.5) * 5)
            
            card = f"""📄 **Source {i}: {result.get('source', 'Unknown')}**
{credibility_stars} ({result.get('credibility', 0.5):.0%} credibility)

**{result.get('title', 'No title')}**

{result.get('summary', 'No summary available')}

🔗 [Read More]({result.get('url', '#')})
📅 {result.get('published', 'Date unknown')}
"""
            
            # Add special elements based on source type
            if result.get('type') == 'academic_paper':
                authors = result.get('authors', [])
                if authors:
                    card += f"👥 Authors: {', '.join(authors[:3])}\n"
                    
            elif result.get('type') == 'rss_item':
                keywords = result.get('matched_keywords', [])
                if keywords:
                    card += f"🏷️ Keywords: {', '.join(keywords)}\n"
            
            cards.append(card)
        
        return cards
    
    def calculate_overall_credibility(self, results):
        """Calculate weighted credibility score"""
        try:
            if not results:
                return 0.0
                
            total_weight = 0
            weighted_credibility = 0
            
            for result in results:
                if "error" in result:
                    continue
                    
                source = result.get('source', '').lower()
                weight = self.source_weights.get(source, 0.5)
                credibility = result.get('credibility', 0.5)
                
                weighted_credibility += credibility * weight
                total_weight += weight
            
            return weighted_credibility / total_weight if total_weight > 0 else 0.0
            
        except Exception as e:
            log_error(f"Credibility calculation failed: {e}")
            return 0.0
    
    async def comprehensive_research(self, query, include_sources=None):
        """Perform comprehensive research across multiple sources"""
        try:
            if include_sources is None:
                include_sources = ["wikipedia", "arxiv", "news"]
            
            all_results = []
            research_summary = {
                "query": query,
                "sources_searched": include_sources,
                "started_at": datetime.now().isoformat(),
                "results": {}
            }
            
            # Search each source
            if "wikipedia" in include_sources:
                wiki_results = await self.search_wikipedia_enhanced(query)
                all_results.extend(wiki_results)
                research_summary["results"]["wikipedia"] = len(wiki_results)
            
            if "arxiv" in include_sources:
                arxiv_results = await self.search_arxiv(query)
                all_results.extend(arxiv_results)
                research_summary["results"]["arxiv"] = len(arxiv_results)
            
            if "news" in include_sources:
                news_results = await self.search_news_sources(query)
                all_results.extend(news_results)
                research_summary["results"]["news"] = len(news_results)
            
            # Generate source cards
            source_cards = self.generate_source_cards(all_results)
            
            # Calculate overall credibility
            overall_credibility = self.calculate_overall_credibility(all_results)
            
            research_summary.update({
                "total_results": len(all_results),
                "overall_credibility": round(overall_credibility, 2),
                "completed_at": datetime.now().isoformat()
            })
            
            return {
                "status": "success",
                "results": all_results,
                "source_cards": source_cards,
                "summary": research_summary,
                "credibility_score": overall_credibility
            }
            
        except Exception as e:
            log_error(f"Comprehensive research failed: {e}")
            return {
                "status": "error",
                "error": str(e),
                "query": query
            }

# Global instance
enhanced_research = EnhancedResearchTools()

# Helper functions
async def research_topic_comprehensive(query, sources=None):
    """Perform comprehensive research on topic"""
    return await enhanced_research.comprehensive_research(query, sources)

def generate_research_summary(results):
    """Generate research summary with source cards"""
    return enhanced_research.generate_source_cards(results)

def get_research_credibility(results):
    """Get research credibility score"""
    return enhanced_research.calculate_overall_credibility(results)


from aiogram.types import Message
from utils.gnews_fetch import fetch_gnews_articles, fetch_top_headlines
from memory import add_message

async def handle_gnews_search(message: Message):
    """Handle GNews search command"""
    try:
        user_input = message.text
        user_id = message.from_user.id
        
        # Extract query from command
        if " " in user_input:
            query = " ".join(user_input.split()[1:])
        else:
            await message.answer("""🔥 <b>GNews Search</b>

<b>Usage:</b> /news [search query]

<b>Examples:</b>
• /news artificial intelligence
• /news cryptocurrency
• /news technology trends
• /news space exploration

— Kael Vanta ®️""")
            return
        
        if not query.strip():
            await message.answer("⚠️ Please provide a search query!\n\nExample: /news AI technology\n\n— Kael Vanta ®️")
            return
        
        # Log user request
        add_message(user_id, "user", f"News search: {query}")
        
        # Send typing indicator
        await message.chat.send_action("typing")
        
        # Fetch articles
        articles = fetch_gnews_articles(query, max_results=5)
        
        if not articles or articles[0].get("error"):
            error_msg = articles[0].get("error", "Unknown error") if articles else "No articles found"
            await message.answer(f"⚠️ News search failed: {error_msg}\n\n— Kael Vanta ®️")
            return
        
        # Format response
        response = f"📰 <b>Latest News: {query}</b>\n\n"
        
        for i, article in enumerate(articles[:5], 1):
            title = article.get("title", "")
            description = article.get("description", "")
            url = article.get("url", "")
            source = article.get("source", "Unknown")
            
            response += f"<b>{i}. {title}</b>\n"
            if description:
                response += f"{description[:150]}{'...' if len(description) > 150 else ''}\n"
            response += f"🔗 <a href='{url}'>Read full article</a>\n"
            response += f"📝 Source: {source}\n\n"
        
        response += "— Powered by GNews & Kael Vanta ®️"
        
        # Log bot response
        add_message(user_id, "assistant", f"News search results for: {query}")
        
        await message.answer(response, disable_web_page_preview=True)
        
    except Exception as e:
        await message.answer(f"⚠️ News search error: {str(e)}\n\n— Kael Vanta ®️")

async def handle_gnews_headlines(message: Message):
    """Handle top headlines command"""
    try:
        user_input = message.text
        user_id = message.from_user.id
        
        # Extract category from command
        category = "general"  # default
        if " " in user_input:
            category_input = " ".join(user_input.split()[1:]).lower()
            valid_categories = ["general", "world", "nation", "business", "technology", "entertainment", "sports", "science", "health"]
            if category_input in valid_categories:
                category = category_input
        
        # Log user request
        add_message(user_id, "user", f"Headlines: {category}")
        
        # Send typing indicator
        await message.chat.send_action("typing")
        
        # Fetch headlines
        headlines = fetch_top_headlines(category)
        
        if not headlines or headlines[0].get("error"):
            error_msg = headlines[0].get("error", "Unknown error") if headlines else "No headlines found"
            await message.answer(f"⚠️ Headlines fetch failed: {error_msg}\n\n— Kael Vanta ®️")
            return
        
        # Format response
        response = f"🔥 <b>Top {category.title()} Headlines</b>\n\n"
        
        for i, article in enumerate(headlines[:5], 1):
            title = article.get("title", "")
            description = article.get("description", "")
            url = article.get("url", "")
            source = article.get("source", "Unknown")
            
            response += f"<b>{i}. {title}</b>\n"
            if description:
                response += f"{description[:120]}{'...' if len(description) > 120 else ''}\n"
            response += f"🔗 <a href='{url}'>Read more</a> | 📝 {source}\n\n"
        
        # Add category options
        response += "<b>📂 Available categories:</b>\n"
        response += "general, world, nation, business, technology, entertainment, sports, science, health\n\n"
        response += "<b>Usage:</b> /headlines [category]\n\n"
        response += "— Powered by GNews & Kael Vanta ®️"
        
        # Log bot response
        add_message(user_id, "assistant", f"Top headlines: {category}")
        
        await message.answer(response, disable_web_page_preview=True)
        
    except Exception as e:
        await message.answer(f"⚠️ Headlines error: {str(e)}\n\n— Kael Vanta ®️")

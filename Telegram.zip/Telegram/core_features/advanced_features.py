
import asyncio
import random
import json
import os
import requests
from datetime import datetime, timedelta
from aiogram.types import Message
from aiogram import Bot
from core_features.ai_engine import get_ai_response
from memory import add_message, log_error, get_user_preferences, set_user_preference
from keys import API_KEYS

# Feature 1: Multi-Personality Mode
PERSONALITIES = {
    "pro": {
        "name": "Professional",
        "style": "Direct, business-focused, efficient communication with strategic insights.",
        "emoji": "💼"
    },
    "savage": {
        "name": "Savage", 
        "style": "Brutally honest, no-filter alpha energy with sharp comebacks.",
        "emoji": "🔥"
    },
    "flirty": {
        "name": "Flirty",
        "style": "Charming, playful, confident with smooth conversation flow.",
        "emoji": "😘"
    },
    "comedian": {
        "name": "Comedian",
        "style": "Witty, humorous, entertaining with clever jokes and timing.",
        "emoji": "😂"
    },
    "mentor": {
        "name": "Mentor",
        "style": "Wise, supportive, motivational with life guidance focus.",
        "emoji": "🧠"
    }
}

async def switch_personality(message: Message):
    """Switch between different AI personalities"""
    try:
        text_parts = message.text.split()
        if len(text_parts) < 2:
            current_mode = get_user_preferences(message.from_user.id).get("personality", "savage")
            personalities_list = "\n".join([f"{data['emoji']} <code>{key}</code> — {data['name']}" for key, data in PERSONALITIES.items()])
            
            await message.answer(f"🎭 <b>Multi-Personality Mode</b>\n\n<b>Current:</b> {PERSONALITIES[current_mode]['emoji']} {PERSONALITIES[current_mode]['name']}\n\n<b>Available:</b>\n{personalities_list}\n\n<b>Usage:</b> /personality savage\n\n— Kael Vanta ®️")
            return
            
        new_personality = text_parts[1].lower()
        if new_personality not in PERSONALITIES:
            await message.answer("⚠️ Invalid personality. Use: pro, savage, flirty, comedian, mentor\n\n— Kael Vanta ®️")
            return
            
        set_user_preference(message.from_user.id, "personality", new_personality)
        persona_data = PERSONALITIES[new_personality]
        
        await message.answer(f"{persona_data['emoji']} <b>Personality switched to {persona_data['name']}</b>\n\n{persona_data['style']}\n\n— Kael Vanta ®️")
        
    except Exception as e:
        log_error(f"Personality switch error: {e}")
        await message.answer("⚠️ Personality mode error. Try again!\n\n— Kael Vanta ®️")

# Feature 4: Daily Life Hacks
DAILY_HACKS = [
    "🧠 Put your phone in airplane mode for 2 minutes, then back on — it forces a network refresh for better signal.",
    "⚡ Freeze grapes for instant ice cubes that won't water down your drink.",
    "🔥 Use ctrl+shift+t to reopen closed browser tabs — works in most browsers.",
    "💡 Rub a walnut on scratched wood furniture — the oils help hide minor scratches.",
    "🚀 Put a wooden spoon across a boiling pot to prevent water from boiling over.",
    "🧊 Keep bananas fresh longer by wrapping the stems in plastic wrap.",
    "⚔️ Use bread to pick up broken glass safely — it grabs tiny pieces.",
    "💪 20-20-20 rule: Every 20 minutes, look at something 20 feet away for 20 seconds.",
    "🎯 Put a rubber band around an open paint can — use it to wipe excess paint off your brush.",
    "🔥 Use a hair dryer to remove stickers cleanly — heat loosens the adhesive.",
    "⚡ Charge your phone faster by putting it in airplane mode while charging.",
    "🧠 Use Google's 'I'm feeling lucky' with your search to skip result pages.",
    "💎 Put a bay leaf in your flour/rice containers to keep bugs away naturally.",
    "🚀 Use ctrl+L to quickly jump to the address bar in any browser.",
    "🔑 Save dying phone battery: turn on low power mode and close background apps.",
    "⚔️ Use a can opener on those impossible plastic packaging seals.",
    "🧊 Put a damp paper towel under your cutting board to stop it sliding.",
    "💡 Use clear nail polish to stop small clothing tears from getting bigger.",
    "🎯 Put your credit card info in your phone's notes with fake numbers for security.",
    "🔥 Use a blow dryer on cool setting to dust delicate items safely."
]

async def send_daily_hack(message: Message):
    """Send a daily life hack"""
    try:
        hack = random.choice(DAILY_HACKS)
        await message.answer(f"💡 <b>Daily Life Hack</b>\n\n{hack}\n\n— Kael Vanta ®️")
    except Exception as e:
        log_error(f"Daily hack error: {e}")
        await message.answer("⚠️ Hack system temporarily down.\n\n— Kael Vanta ®️")

# Feature 5: Language Translator
async def translate_text(message: Message):
    """Translate text to different languages"""
    try:
        text_parts = message.text.split(None, 2)
        if len(text_parts) < 3:
            await message.answer("🌍 <b>Language Translator</b>\n\n<b>Usage:</b> /translate spanish Hello world\n<b>Or:</b> /translate es Hola mundo\n\n<b>Popular codes:</b> es, fr, de, it, pt, ru, zh, ja, ko\n\n— Kael Vanta ®️")
            return
            
        target_lang = text_parts[1].lower()
        text_to_translate = text_parts[2]
        
        # Use AI for translation
        prompt = f"Translate this text to {target_lang}: '{text_to_translate}'. Only return the translation, nothing else."
        
        api_items = list(API_KEYS.items())
        if not api_items:
            await message.answer("⚠️ Translation temporarily unavailable.\n\n— Kael Vanta ®️")
            return
            
        model, key = random.choice(api_items)
        translation = await get_ai_response(prompt, model, key, message.from_user.id)
        
        await message.answer(f"🌍 <b>Translation ({target_lang})</b>\n\n<b>Original:</b> {text_to_translate}\n<b>Translated:</b> {translation}\n\n— Kael Vanta ®️")
        
    except Exception as e:
        log_error(f"Translation error: {e}")
        await message.answer("⚠️ Translation failed. Try again!\n\n— Kael Vanta ®️")

# Feature 8: Creative Content Maker
async def create_content(message: Message):
    """Generate creative content like poems, stories, scripts"""
    try:
        text_parts = message.text.split(None, 2)
        if len(text_parts) < 3:
            await message.answer("✨ <b>Creative Content Maker</b>\n\n<b>Usage:</b> /create poem love\n<b>Types:</b> poem, story, script, caption, lyrics, joke\n\n<b>Example:</b> /create story space adventure\n\n— Kael Vanta ®️")
            return
            
        content_type = text_parts[1].lower()
        topic = text_parts[2]
        
        prompt = f"Create a {content_type} about {topic}. Make it creative, engaging, and well-structured."
        
        api_items = list(API_KEYS.items())
        if not api_items:
            await message.answer("⚠️ Creative mode temporarily unavailable.\n\n— Kael Vanta ®️")
            return
            
        model, key = random.choice(api_items)
        content = await get_ai_response(prompt, model, key, message.from_user.id)
        
        await message.answer(f"✨ <b>Creative {content_type.title()}</b>\n\n{content}\n\n— Kael Vanta ®️")
        
    except Exception as e:
        log_error(f"Creative content error: {e}")
        await message.answer("⚠️ Creative mode failed. Try again!\n\n— Kael Vanta ®️")

# Feature 9: Code Generator & Debugger
async def handle_code(message: Message):
    """Generate, explain, and debug code"""
    try:
        text_parts = message.text.split(None, 1)
        if len(text_parts) < 2:
            await message.answer("💻 <b>Code Generator & Debugger</b>\n\n<b>Usage:</b>\n/code python function to sort list\n/debug [your buggy code]\n/explain [code to understand]\n\n— Kael Vanta ®️")
            return
            
        request = text_parts[1]
        command = message.text.split()[0].lower()
        
        if command == "/code":
            prompt = f"Generate clean, working code for: {request}. Include comments explaining the logic."
        elif command == "/debug":
            prompt = f"Debug this code and fix any issues: {request}. Explain what was wrong and provide the corrected version."
        elif command == "/explain":
            prompt = f"Explain this code line by line in simple terms: {request}"
        else:
            prompt = f"Help with this coding task: {request}"
            
        api_items = list(API_KEYS.items())
        if not api_items:
            await message.answer("⚠️ Code assistant temporarily unavailable.\n\n— Kael Vanta ®️")
            return
            
        model, key = random.choice(api_items)
        code_response = await get_ai_response(prompt, model, key, message.from_user.id)
        
        await message.answer(f"💻 <b>Code Assistant</b>\n\n{code_response}\n\n— Kael Vanta ®️")
        
    except Exception as e:
        log_error(f"Code handler error: {e}")
        await message.answer("⚠️ Code assistant failed. Try again!\n\n— Kael Vanta ®️")

# Feature 12: Prediction Mode
async def make_prediction(message: Message):
    """Make predictions about various topics"""
    try:
        text_parts = message.text.split(None, 1)
        if len(text_parts) < 2:
            await message.answer("🔮 <b>Prediction Mode</b>\n\n<b>Usage:</b> /predict Bitcoin price tomorrow\n<b>Or:</b> /predict Lakers vs Warriors game\n\n<b>Note:</b> For entertainment only!\n\n— Kael Vanta ®️")
            return
            
        topic = text_parts[1]
        
        prompt = f"Make a prediction about: {topic}. Base it on logical analysis and current trends, but make it engaging. Include confidence level and reasoning."
        
        api_items = list(API_KEYS.items())
        if not api_items:
            await message.answer("⚠️ Prediction mode temporarily unavailable.\n\n— Kael Vanta ®️")
            return
            
        model, key = random.choice(api_items)
        prediction = await get_ai_response(prompt, model, key, message.from_user.id)
        
        confidence = random.randint(60, 95)
        await message.answer(f"🔮 <b>Prediction Analysis</b>\n\n{prediction}\n\n📊 <b>Confidence:</b> {confidence}%\n⚠️ <i>For entertainment purposes only</i>\n\n— Kael Vanta ®️")
        
    except Exception as e:
        log_error(f"Prediction error: {e}")
        await message.answer("⚠️ Prediction failed. Try again!\n\n— Kael Vanta ®️")

# Feature 14: Emotional Support Mode
async def emotional_support(message: Message):
    """Provide emotional support and motivation"""
    try:
        text_parts = message.text.split(None, 1)
        if len(text_parts) < 2:
            await message.answer("💙 <b>Emotional Support Mode</b>\n\n<b>Usage:</b> /support I'm feeling anxious about work\n<b>Or:</b> /motivate me for my exam\n\n<b>I'm here to listen and help.</b>\n\n— Kael Vanta ®️")
            return
            
        concern = text_parts[1]
        
        prompt = f"Provide supportive, understanding, and motivational response to: {concern}. Be empathetic, practical, and encouraging without being dismissive."
        
        api_items = list(API_KEYS.items())
        if not api_items:
            await message.answer("💙 I hear you, and you're stronger than you know. Whatever you're facing, you have the power to overcome it. Take it one step at a time.\n\n— Kael Vanta ®️")
            return
            
        model, key = random.choice(api_items)
        support = await get_ai_response(prompt, model, key, message.from_user.id)
        
        await message.answer(f"💙 <b>Emotional Support</b>\n\n{support}\n\n<i>Remember: You're stronger than you think.</i>\n\n— Kael Vanta ®️")
        
    except Exception as e:
        log_error(f"Emotional support error: {e}")
        await message.answer("💙 I'm here for you. Sometimes talking helps, and you're not alone in this. Keep pushing forward.\n\n— Kael Vanta ®️")

# Feature 16: Custom AI Commands Creator
async def create_custom_command(message: Message):
    """Let users create their own bot commands"""
    try:
        text_parts = message.text.split(None, 2)
        if len(text_parts) < 3:
            user_commands = get_user_preferences(message.from_user.id).get("custom_commands", {})
            commands_list = "\n".join([f"• /{cmd}: {desc}" for cmd, desc in user_commands.items()]) if user_commands else "None created yet"
            
            await message.answer(f"🛠️ <b>Custom Commands Creator</b>\n\n<b>Your Commands:</b>\n{commands_list}\n\n<b>Usage:</b> /customcmd mycommand Tell me a dad joke\n\n— Kael Vanta ®️")
            return
            
        command_name = text_parts[1].lower()
        command_description = text_parts[2]
        
        # Save custom command
        user_commands = get_user_preferences(message.from_user.id).get("custom_commands", {})
        user_commands[command_name] = command_description
        set_user_preference(message.from_user.id, "custom_commands", user_commands)
        
        await message.answer(f"✅ <b>Custom Command Created!</b>\n\n<b>Command:</b> /{command_name}\n<b>Action:</b> {command_description}\n\n<i>Use /{command_name} to activate it!</i>\n\n— Kael Vanta ®️")
        
    except Exception as e:
        log_error(f"Custom command error: {e}")
        await message.answer("⚠️ Command creation failed. Try again!\n\n— Kael Vanta ®️")

async def execute_custom_command(message: Message, command_name: str):
    """Execute a user's custom command"""
    try:
        user_commands = get_user_preferences(message.from_user.id).get("custom_commands", {})
        
        if command_name not in user_commands:
            return False
            
        command_description = user_commands[command_name]
        
        api_items = list(API_KEYS.items())
        if not api_items:
            await message.answer("⚠️ Custom command temporarily unavailable.\n\n— Kael Vanta ®️")
            return True
            
        model, key = random.choice(api_items)
        response = await get_ai_response(command_description, model, key, message.from_user.id)
        
        await message.answer(f"🛠️ <b>Custom Command: {command_name}</b>\n\n{response}\n\n— Kael Vanta ®️")
        return True
        
    except Exception as e:
        log_error(f"Custom command execution error: {e}")
        await message.answer("⚠️ Custom command failed. Try again!\n\n— Kael Vanta ®️")
        return True

# Feature 17: AI Roast & Compliment Mode
ROAST_TOPICS = [
    "your haircut looks like it was done by a drunk barber in the dark",
    "you're the reason they put instructions on shampoo bottles",
    "if stupidity was a currency, you'd be Jeff Bezos",
    "you're like a software update — nobody wants you, but you're still here",
    "your personality is like Wi-Fi in the basement — weak and unreliable",
    "you're the human equivalent of a participation trophy",
    "if brains were gasoline, you wouldn't have enough to power a motorcycle around a coin",
    "you're like a broken calculator — you can't count on yourself",
    "your confidence is amazing considering how little you have to work with",
    "you're proof that evolution can go backwards"
]

COMPLIMENT_TOPICS = [
    "your energy could power a small city — absolutely electric",
    "you're the type of person who makes others want to level up",
    "your vibe is so magnetic, even introverts gravitate toward you",
    "you have that rare combination of intelligence and humility",
    "your smile is basically a cheat code for making people's day better",
    "you're the human equivalent of a perfectly timed comeback",
    "your presence alone raises the room's collective IQ",
    "you're like a good book — impressive, engaging, and impossible to put down",
    "your authenticity is refreshing in a world full of filters",
    "you have that mysterious quality that makes people remember you forever"
]

async def roast_or_compliment(message: Message):
    """Switch between roast and compliment modes"""
    try:
        text_parts = message.text.split()
        command = text_parts[0].lower()
        
        if command == "/roast":
            roast = random.choice(ROAST_TOPICS)
            await message.answer(f"🔥 <b>Savage Roast Mode</b>\n\n{roast}\n\n<i>Don't take it personal — it's just business!</i>\n\n— Kael Vanta ®️")
            
        elif command == "/compliment":
            compliment = random.choice(COMPLIMENT_TOPICS)
            await message.answer(f"💎 <b>Elite Compliment Mode</b>\n\n{compliment}\n\n<i>Keep that energy — you're unstoppable!</i>\n\n— Kael Vanta ®️")
            
    except Exception as e:
        log_error(f"Roast/compliment error: {e}")
        await message.answer("⚠️ Roast mode temporarily down. Consider yourself lucky!\n\n— Kael Vanta ®️")

# Feature 20: Interactive Story Mode
async def interactive_story(message: Message):
    """Start or continue an interactive story"""
    try:
        text_parts = message.text.split(None, 1)
        user_id = str(message.from_user.id)
        
        # Get or initialize story data
        user_prefs = get_user_preferences(message.from_user.id)
        story_data = user_prefs.get("current_story", {})
        
        if len(text_parts) < 2:
            if story_data:
                await message.answer(f"📚 <b>Continue Your Story</b>\n\n<b>Current Story:</b>\n{story_data.get('content', '')}\n\n<b>What happens next?</b> /story [your addition]\n\n— Kael Vanta ®️")
            else:
                await message.answer("📚 <b>Interactive Story Mode</b>\n\n<b>Start a story:</b> /story Once upon a time in a dark forest...\n<b>Or get AI starter:</b> /story random\n\n— Kael Vanta ®️")
            return
            
        user_input = text_parts[1]
        
        if user_input.lower() == "random":
            # AI generates story starter
            prompt = "Create an engaging story opening (2-3 sentences) for an interactive story. Make it mysterious and leave room for continuation."
            api_items = list(API_KEYS.items())
            if api_items:
                model, key = random.choice(api_items)
                story_start = await get_ai_response(prompt, model, key, message.from_user.id)
                story_data = {"content": story_start, "turns": 1}
            else:
                story_start = "In a world where technology has merged with magic, you discover a mysterious device that can alter reality itself. As you pick it up, strange symbols begin to glow..."
                story_data = {"content": story_start, "turns": 1}
                
        elif user_input.lower() == "reset":
            story_data = {}
            set_user_preference(message.from_user.id, "current_story", story_data)
            await message.answer("📚 <b>Story Reset</b>\n\nReady for a new adventure!\n\n— Kael Vanta ®️")
            return
            
        else:
            # Continue existing story or start new one
            if story_data:
                current_content = story_data.get("content", "")
                new_content = f"{current_content}\n\n{user_input}"
                story_data["content"] = new_content
                story_data["turns"] = story_data.get("turns", 0) + 1
            else:
                story_data = {"content": user_input, "turns": 1}
            
            # AI continues the story
            prompt = f"Continue this interactive story with 2-3 sentences. Make it engaging and end with a choice or cliffhanger:\n\n{story_data['content']}"
            
            api_items = list(API_KEYS.items())
            if api_items:
                model, key = random.choice(api_items)
                ai_continuation = await get_ai_response(prompt, model, key, message.from_user.id)
                story_data["content"] = f"{story_data['content']}\n\n{ai_continuation}"
                story_data["turns"] += 1
        
        # Save story progress
        set_user_preference(message.from_user.id, "current_story", story_data)
        
        await message.answer(f"📚 <b>Interactive Story (Turn {story_data['turns']})</b>\n\n{story_data['content']}\n\n<b>Continue:</b> /story [what happens next]\n<b>Reset:</b> /story reset\n\n— Kael Vanta ®️")
        
    except Exception as e:
        log_error(f"Interactive story error: {e}")
        await message.answer("⚠️ Story mode glitched. Try again!\n\n— Kael Vanta ®️")


"""
MoodSync - Emotional Intelligence & Sentiment Tracking
Analyzes user emotions and adapts responses accordingly
"""
import json
import os
from datetime import datetime, timedelta
from collections import defaultdict, deque
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from memory import log_error, get_user_preferences, set_user_preference

class MoodSync:
    def __init__(self):
        self.analyzer = SentimentIntensityAnalyzer()
        self.mood_file = "data/mood_history.json"
        self.mood_cache = {}
        self.load_mood_history()

    def load_mood_history(self):
        """Load mood history from file"""
        try:
            if os.path.exists(self.mood_file):
                with open(self.mood_file, "r") as f:
                    self.mood_cache = json.load(f)
            else:
                os.makedirs(os.path.dirname(self.mood_file), exist_ok=True)
                self.mood_cache = {}
        except Exception as e:
            log_error(f"Mood history load failed: {e}")
            self.mood_cache = {}

    def save_mood_history(self):
        """Save mood history to file"""
        try:
            with open(self.mood_file, "w") as f:
                json.dump(self.mood_cache, f, indent=2)
        except Exception as e:
            log_error(f"Mood history save failed: {e}")

    def analyze_sentiment(self, text):
        """Analyze sentiment of text using VADER"""
        try:
            scores = self.analyzer.polarity_scores(text)
            
            # Determine primary mood
            if scores['compound'] >= 0.5:
                mood = "very_positive"
            elif scores['compound'] >= 0.1:
                mood = "positive"
            elif scores['compound'] <= -0.5:
                mood = "very_negative"
            elif scores['compound'] <= -0.1:
                mood = "negative"
            else:
                mood = "neutral"
                
            return {
                "mood": mood,
                "scores": scores,
                "intensity": abs(scores['compound']),
                "emotions": {
                    "positive": scores['pos'],
                    "negative": scores['neg'],
                    "neutral": scores['neu']
                }
            }
        except Exception as e:
            log_error(f"Sentiment analysis failed: {e}")
            return {"mood": "unknown", "scores": {}, "intensity": 0}

    def track_user_mood(self, user_id, text):
        """Track and store user mood from message"""
        try:
            user_key = str(user_id)
            sentiment = self.analyze_sentiment(text)
            
            # Initialize user mood history
            if user_key not in self.mood_cache:
                self.mood_cache[user_key] = {
                    "history": [],
                    "daily_summary": {},
                    "mood_trends": {},
                    "total_messages": 0
                }
                
            # Add mood entry
            mood_entry = {
                "timestamp": datetime.now().isoformat(),
                "mood": sentiment["mood"],
                "intensity": sentiment["intensity"],
                "compound_score": sentiment["scores"].get("compound", 0),
                "message_length": len(text)
            }
            
            self.mood_cache[user_key]["history"].append(mood_entry)
            self.mood_cache[user_key]["total_messages"] += 1
            
            # Keep only last 100 mood entries per user
            if len(self.mood_cache[user_key]["history"]) > 100:
                self.mood_cache[user_key]["history"] = self.mood_cache[user_key]["history"][-100:]
                
            # Update daily summary
            today = datetime.now().date().isoformat()
            if today not in self.mood_cache[user_key]["daily_summary"]:
                self.mood_cache[user_key]["daily_summary"][today] = {
                    "mood_counts": defaultdict(int),
                    "avg_intensity": 0,
                    "message_count": 0
                }
                
            daily = self.mood_cache[user_key]["daily_summary"][today]
            daily["mood_counts"][sentiment["mood"]] += 1
            daily["message_count"] += 1
            
            # Calculate running average intensity
            total_intensity = daily["avg_intensity"] * (daily["message_count"] - 1) + sentiment["intensity"]
            daily["avg_intensity"] = total_intensity / daily["message_count"]
            
            self.save_mood_history()
            return sentiment
            
        except Exception as e:
            log_error(f"Mood tracking failed: {e}")
            return {"mood": "unknown"}

    def get_user_mood_summary(self, user_id, days=7):
        """Get user mood summary for specified days"""
        try:
            user_key = str(user_id)
            if user_key not in self.mood_cache:
                return {"status": "no_data"}
                
            user_data = self.mood_cache[user_key]
            recent_history = user_data["history"][-50:]  # Last 50 messages
            
            if not recent_history:
                return {"status": "insufficient_data"}
                
            # Calculate mood distribution
            mood_counts = defaultdict(int)
            total_intensity = 0
            
            for entry in recent_history:
                mood_counts[entry["mood"]] += 1
                total_intensity += entry["intensity"]
                
            avg_intensity = total_intensity / len(recent_history) if recent_history else 0
            dominant_mood = max(mood_counts.items(), key=lambda x: x[1])[0]
            
            # Mood trend (last 10 vs previous 10)
            if len(recent_history) >= 20:
                recent_10 = recent_history[-10:]
                prev_10 = recent_history[-20:-10]
                
                recent_avg = sum(entry["compound_score"] for entry in recent_10) / 10
                prev_avg = sum(entry["compound_score"] for entry in prev_10) / 10
                
                trend = "improving" if recent_avg > prev_avg + 0.1 else \
                       "declining" if recent_avg < prev_avg - 0.1 else "stable"
            else:
                trend = "insufficient_data"
                
            return {
                "status": "success",
                "dominant_mood": dominant_mood,
                "mood_distribution": dict(mood_counts),
                "average_intensity": round(avg_intensity, 3),
                "trend": trend,
                "total_messages": user_data["total_messages"],
                "recent_messages": len(recent_history)
            }
            
        except Exception as e:
            log_error(f"Mood summary failed: {e}")
            return {"status": "error", "error": str(e)}

    def adapt_response_to_mood(self, user_id, base_response):
        """Adapt bot response based on user's current mood"""
        try:
            mood_summary = self.get_user_mood_summary(user_id)
            
            if mood_summary["status"] != "success":
                return base_response
                
            dominant_mood = mood_summary["dominant_mood"]
            trend = mood_summary["trend"]
            
            # Mood-based adaptations
            if dominant_mood in ["very_negative", "negative"]:
                if "declining" in trend:
                    prefix = "Hey, I sense you might be going through something tough. "
                else:
                    prefix = "I'm here for you. "
                adaptations = [
                    "Take it one step at a time.",
                    "You're stronger than you know.",
                    "This too shall pass.",
                    "I believe in your resilience."
                ]
            elif dominant_mood in ["very_positive", "positive"]:
                prefix = "Love the energy! "
                adaptations = [
                    "Keep that momentum going!",
                    "Your positivity is contagious!",
                    "This is your moment to shine!",
                    "Ride that wave of success!"
                ]
            else:
                return base_response
                
            import random
            adaptation = random.choice(adaptations)
            return f"{prefix}{base_response}\n\n💭 {adaptation}\n\n— Kael Vanta ®️"
            
        except Exception as e:
            log_error(f"Mood adaptation failed: {e}")
            return base_response

    def get_mood_health_metrics(self):
        """Get overall mood health metrics for monitoring"""
        try:
            total_users = len(self.mood_cache)
            if total_users == 0:
                return {"status": "no_users"}
                
            mood_stats = {
                "total_users": total_users,
                "mood_distribution": defaultdict(int),
                "avg_intensity": 0,
                "users_by_trend": defaultdict(int)
            }
            
            total_intensity = 0
            total_messages = 0
            
            for user_data in self.mood_cache.values():
                if user_data["history"]:
                    # Get last mood
                    last_mood = user_data["history"][-1]["mood"]
                    mood_stats["mood_distribution"][last_mood] += 1
                    
                    # Calculate user trend
                    summary = self.get_user_mood_summary(int(list(self.mood_cache.keys())[0]))
                    if "trend" in summary:
                        mood_stats["users_by_trend"][summary["trend"]] += 1
                        
                    total_intensity += sum(entry["intensity"] for entry in user_data["history"][-10:])
                    total_messages += min(10, len(user_data["history"]))
                    
            mood_stats["avg_intensity"] = total_intensity / total_messages if total_messages > 0 else 0
            mood_stats["mood_distribution"] = dict(mood_stats["mood_distribution"])
            mood_stats["users_by_trend"] = dict(mood_stats["users_by_trend"])
            
            return mood_stats
            
        except Exception as e:
            log_error(f"Mood health metrics failed: {e}")
            return {"status": "error", "error": str(e)}

# Global MoodSync instance
mood_sync = MoodSync()

# Helper functions
def analyze_user_mood(user_id, text):
    """Analyze and track user mood"""
    return mood_sync.track_user_mood(user_id, text)

def get_mood_adapted_response(user_id, response):
    """Get mood-adapted response"""
    return mood_sync.adapt_response_to_mood(user_id, response)

def get_user_mood_status(user_id):
    """Get user mood status"""
    return mood_sync.get_user_mood_summary(user_id)

import json
import os
from datetime import datetime
from typing import Dict, List, Any, Optional
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from memory import get_user_preferences, set_user_preference, log_error
from core_features.bio_prefs import build_personality_prompt

# PersonaForge Configuration
PERSONA_TEMPLATES = {
    "alpha_ceo": {
        "name": "Alpha CEO",
        "description": "Confident business leader with strategic mindset",
        "emoji": "👔",
        "params": {
            "tone": "commanding", "style": "strategic", "formality": "professional",
            "directness": "high", "empathy": "medium", "motivation": "high",
            "humor": "dry", "slang": "minimal", "emojis": "strategic",
            "length": "concise", "censorship": "professional", "response_format": "structured"
        }
    },
    "smooth_operator": {
        "name": "Smooth Operator",
        "description": "Charismatic and charming conversationalist",
        "emoji": "😎",
        "params": {
            "tone": "smooth", "style": "charismatic", "formality": "casual",
            "directness": "medium", "empathy": "high", "motivation": "medium",
            "humor": "witty", "slang": "moderate", "emojis": "expressive",
            "length": "flowing", "censorship": "relaxed", "response_format": "conversational"
        }
    },
    "genius_mentor": {
        "name": "Genius Mentor",
        "description": "Brilliant teacher with deep wisdom",
        "emoji": "🧠",
        "params": {
            "tone": "wise", "style": "educational", "formality": "balanced",
            "directness": "thoughtful", "empathy": "very_high", "motivation": "very_high",
            "humor": "intellectual", "slang": "minimal", "emojis": "occasional",
            "length": "detailed", "censorship": "moderate", "response_format": "educational"
        }
    },
    "savage_roaster": {
        "name": "Savage Roaster",
        "description": "Brutally honest with sharp wit",
        "emoji": "🔥",
        "params": {
            "tone": "savage", "style": "cutting", "formality": "casual",
            "directness": "brutal", "empathy": "low", "motivation": "tough_love",
            "humor": "savage", "slang": "heavy", "emojis": "fire",
            "length": "punchy", "censorship": "minimal", "response_format": "roast_style"
        }
    },
    "zen_master": {
        "name": "Zen Master",
        "description": "Calm, philosophical, and mindful",
        "emoji": "🧘",
        "params": {
            "tone": "calm", "style": "philosophical", "formality": "thoughtful",
            "directness": "gentle", "empathy": "very_high", "motivation": "mindful",
            "humor": "peaceful", "slang": "none", "emojis": "zen",
            "length": "contemplative", "censorship": "pure", "response_format": "wisdom"
        }
    }
}

PERSONA_PARAMETERS = {
    "tone": ["commanding", "smooth", "wise", "savage", "calm", "playful", "serious"],
    "style": ["strategic", "charismatic", "educational", "cutting", "philosophical", "creative"],
    "formality": ["professional", "casual", "balanced", "thoughtful"],
    "directness": ["brutal", "high", "medium", "thoughtful", "gentle"],
    "empathy": ["low", "medium", "high", "very_high"],
    "motivation": ["tough_love", "high", "medium", "very_high", "mindful"],
    "humor": ["dry", "witty", "intellectual", "savage", "peaceful", "none"],
    "response_format": ["structured", "conversational", "educational", "roast_style", "wisdom"]
}

class PersonaForge:
    def __init__(self):
        self.personas_file = "data/personas.json"
        self.ensure_personas_file()

    def ensure_personas_file(self):
        """Ensure personas data file exists"""
        os.makedirs("data", exist_ok=True)
        if not os.path.exists(self.personas_file):
            with open(self.personas_file, "w") as f:
                json.dump({}, f, indent=2)

    def save_persona(self, user_id: int, persona_name: str, persona_data: Dict) -> bool:
        """Save a custom persona for user"""
        try:
            with open(self.personas_file, "r") as f:
                personas = json.load(f)

            user_key = str(user_id)
            if user_key not in personas:
                personas[user_key] = {}

            personas[user_key][persona_name] = {
                **persona_data,
                "created": datetime.now().isoformat(),
                "last_used": None
            }

            with open(self.personas_file, "w") as f:
                json.dump(personas, f, indent=2)

            return True
        except Exception as e:
            log_error(f"PersonaForge save error: {e}")
            return False

    def load_persona(self, user_id: int, persona_name: str) -> Optional[Dict]:
        """Load a custom persona for user"""
        try:
            with open(self.personas_file, "r") as f:
                personas = json.load(f)

            user_key = str(user_id)
            if user_key in personas and persona_name in personas[user_key]:
                return personas[user_key][persona_name]
            return None
        except Exception as e:
            log_error(f"PersonaForge load error: {e}")
            return None

    def get_user_personas(self, user_id: int) -> Dict:
        """Get all personas for a user"""
        try:
            with open(self.personas_file, "r") as f:
                personas = json.load(f)
            return personas.get(str(user_id), {})
        except Exception as e:
            log_error(f"PersonaForge get user personas error: {e}")
            return {}

    def delete_persona(self, user_id: int, persona_name: str) -> bool:
        """Delete a custom persona"""
        try:
            with open(self.personas_file, "r") as f:
                personas = json.load(f)

            user_key = str(user_id)
            if user_key in personas and persona_name in personas[user_key]:
                del personas[user_key][persona_name]

                with open(self.personas_file, "w") as f:
                    json.dump(personas, f, indent=2)
                return True
            return False
        except Exception as e:
            log_error(f"PersonaForge delete error: {e}")
            return False

    def apply_persona(self, user_id: int, persona_key: str) -> bool:
        """Apply a persona by its key (from templates or custom)"""
        try:
            persona_data = None
            if persona_key in PERSONA_TEMPLATES:
                persona_data = PERSONA_TEMPLATES[persona_key]
            else:
                persona_data = self.load_persona(user_id, persona_key)

            if persona_data:
                apply_persona_to_preferences(user_id, persona_data)
                return True
            return False
        except Exception as e:
            log_error(f"PersonaForge apply persona error: {e}")
            return False

    def get_persona(self, persona_key: str) -> Optional[Dict]:
        """Get persona data by key (template or custom)"""
        if persona_key in PERSONA_TEMPLATES:
            return PERSONA_TEMPLATES[persona_key]
        else:
            # This would require user_id, which isn't available here.
            # For simplicity, this function only returns templates.
            # Custom persona retrieval needs to be handled in context.
            return None

# Global PersonaForge instance
forge = PersonaForge()

async def personaforge_main(message: Message):
    """Main PersonaForge interface"""
    try:
        user_personas = forge.get_user_personas(message.from_user.id)
        persona_count = len(user_personas)

        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🎭 Create New Persona", callback_data="pf_create")],
            [InlineKeyboardButton(text="📋 Persona Templates", callback_data="pf_templates")],
            [InlineKeyboardButton(text="👤 My Personas", callback_data="pf_my_personas")],
            [InlineKeyboardButton(text="🔄 Quick Switch", callback_data="pf_quick_switch")],
            [InlineKeyboardButton(text="⚙️ Advanced Builder", callback_data="pf_advanced")]
        ])

        await message.answer(
            f"🎭 <b>PersonaForge</b> — Advanced AI Personality System\n\n"
            f"👤 <b>Your Personas:</b> {persona_count}/10\n"
            f"🎨 <b>Templates Available:</b> {len(PERSONA_TEMPLATES)}\n"
            f"⚡ <b>Current Mode:</b> {get_current_persona_name(message.from_user.id)}\n\n"
            f"<b>Create unlimited AI personas with:</b>\n"
            f"• Fine-tuned personality parameters\n"
            f"• Custom communication styles\n"
            f"• Template-based quick creation\n"
            f"• Advanced persona blending\n\n"
            f"— Kael Vanta ®️",
            reply_markup=keyboard
        )

    except Exception as e:
        log_error(f"PersonaForge main error: {e}")
        await message.answer("⚠️ PersonaForge temporarily unavailable.\n\n— Kael Vanta ®️")

async def create_persona_wizard(message: Message):
    """Start persona creation wizard"""
    try:
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🚀 Quick Create", callback_data="pf_create_wizard_start")], # Changed callback_data
            [InlineKeyboardButton(text="🔧 Custom Build", callback_data="pf_custom_build")],
            [InlineKeyboardButton(text="📋 From Template", callback_data="pf_from_template")],
            [InlineKeyboardButton(text="← Back", callback_data="pf_back")]
        ])

        await message.answer(
            f"🎭 <b>Persona Creation Wizard</b>\n\n"
            f"<b>Choose your creation method:</b>\n\n"
            f"🚀 <b>Quick Create:</b> Name + description = instant persona\n"
            f"🔧 <b>Custom Build:</b> Fine-tune every parameter\n"
            f"📋 <b>From Template:</b> Start with proven archetypes\n\n"
            f"— Kael Vanta ®️",
            reply_markup=keyboard
        )

    except Exception as e:
        log_error(f"Persona wizard error: {e}")
        await message.answer("⚠️ Creation wizard failed.\n\n— Kael Vanta ®️")

def get_current_persona_name(user_id: int) -> str:
    """Get current active persona name"""
    prefs = get_user_preferences(user_id)
    current_persona = prefs.get("active_persona", "Default")
    return current_persona

def apply_persona_to_preferences(user_id: int, persona_data: Dict):
    """Apply persona parameters to user preferences"""
    try:
        params = persona_data.get("params", {})
        for key, value in params.items():
            set_user_preference(user_id, key, value)

        # Set active persona
        set_user_preference(user_id, "active_persona", persona_data.get("name", "Custom"))

        # Update last used timestamp
        if "name" in persona_data:
            persona = forge.load_persona(user_id, persona_data["name"])
            if persona:
                persona["last_used"] = datetime.now().isoformat()
                forge.save_persona(user_id, persona_data["name"], persona)

    except Exception as e:
        log_error(f"Apply persona error: {e}")

def build_persona_prompt(persona_data: Dict) -> str:
    """Build AI prompt from persona data"""
    try:
        params = persona_data.get("params", {})
        name = persona_data.get("name", "Custom Persona")
        description = persona_data.get("description", "")

        # Base prompt
        prompt = f"You are embodying the '{name}' persona: {description}\n\n"

        # Style instructions
        if params.get("tone"):
            prompt += f"Tone: {params['tone']} - "
        if params.get("style"):
            prompt += f"Style: {params['style']} - "
        if params.get("directness"):
            prompt += f"Directness: {params['directness']}\n"

        # Communication preferences
        if params.get("humor") and params["humor"] != "none":
            prompt += f"Use {params['humor']} humor appropriately. "
        if params.get("empathy"):
            prompt += f"Empathy level: {params['empathy']}. "
        if params.get("motivation"):
            prompt += f"Motivation style: {params['motivation']}.\n"

        # Format instructions
        if params.get("response_format"):
            format_style = params["response_format"]
            if format_style == "structured":
                prompt += "Use clear structure with headers and bullets. "
            elif format_style == "conversational":
                prompt += "Keep responses flowing and natural. "
            elif format_style == "educational":
                prompt += "Explain concepts clearly with examples. "
            elif format_style == "roast_style":
                prompt += "Be witty and sharp, but not cruel. "
            elif format_style == "wisdom":
                prompt += "Share deep insights with philosophical depth. "

        prompt += "\nAlways end with '— Kael Vanta ®️'"

        return prompt

    except Exception as e:
        log_error(f"Build persona prompt error: {e}")
        return "You are COREVANTA AI — Always end with '— Kael Vanta ®️'"

async def handle_personaforge_callback(callback_query):
    """Enhanced PersonaForge callback handler with proper error boundaries"""
    try:
        data = callback_query.data
        user_id = callback_query.from_user.id

        # Validate callback data format
        if not data or not data.startswith('pf_'):
            await callback_query.answer("❌ Invalid action")
            return

        action = data.replace('pf_', '')

        # Route to specific handlers
        if action == "create": # Specific handler for the main create button
            await create_persona_wizard(callback_query.message) # Use message to edit context
        elif action == "templates":
            await handle_persona_templates(callback_query)
        elif action.startswith('apply_'): # Handle applying templates
            template_key = action.replace('apply_', '')
            if forge.apply_persona(user_id, template_key):
                template_info = PERSONA_TEMPLATES.get(template_key)
                if template_info:
                    await callback_query.edit_message_text(
                        f"✅ <b>{template_info['name']} Activated!</b>\n\n"
                        f"{template_info['description']}\n\n"
                        f"Your AI personality has been updated. Try chatting now!\n\n"
                        f"— Kael Vanta ®️"
                    )
                else: # Fallback if template info is missing
                    await callback_query.edit_message_text(
                        f"✅ <b>Persona Activated!</b>\n\n"
                        f"Your AI personality has been updated. Try chatting now!\n\n"
                        f"— Kael Vanta ®️"
                    )
            else:
                await callback_query.answer("❌ Failed to apply persona")
        elif action == "my_personas":
            user_personas = forge.get_user_personas(user_id)
            if not user_personas:
                await callback_query.message.edit_text(
                    f"👤 <b>No Custom Personas Yet</b>\n\n"
                    f"Create your first persona to get started!\n\n"
                    f"— Kael Vanta ®️"
                )
            else:
                persona_list = "\n".join([f"• {name}" for name in user_personas.keys()])
                await callback_query.message.edit_text(
                    f"👤 <b>Your Personas ({len(user_personas)})</b>\n\n"
                    f"{persona_list}\n\n"
                    f"— Kael Vanta ®️"
                )
        elif action == "quick_switch":
            # Placeholder for quick switch functionality
            await callback_query.answer("🔄 Quick Switch not yet implemented.")
        elif action == "advanced":
            # Placeholder for advanced builder
            await callback_query.answer("🔧 Advanced Builder not yet implemented.")
        elif action == "back":
            # Handle back navigation, likely returning to the main menu
            await personaforge_main(callback_query.message) # Re-send main menu
            await callback_query.message.delete() # Delete the previous message

        # Add handlers for the new wizard flow
        elif action == "create_wizard_start": # Handler for starting the wizard
             await create_persona_wizard(callback_query.message)
             await callback_query.message.delete() # Delete the initial button message
        elif action == "custom_build":
            await callback_query.answer("🔧 Custom Build is under development.")
        elif action == "from_template":
            await callback_query.answer("📋 From Template is under development.")


        # Always acknowledge callback
        await callback_query.answer()

    except Exception as e:
        log_error(f"PersonaForge callback error: {e} | User: {callback_query.from_user.id}")
        await callback_query.answer("⚠️ Action failed. Try again!")

async def handle_persona_templates(callback_query):
    """Handle display and selection of persona templates"""
    try:
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=f"{template['emoji']} {template['name']}", 
                                callback_data=f"pf_apply_{key}")]
            for key, template in PERSONA_TEMPLATES.items()
        ] + [[InlineKeyboardButton(text="← Back", callback_data="pf_back")]])

        await callback_query.message.edit_text(
            f"📋 <b>Persona Templates</b>\n\n" +
            "\n".join([f"{t['emoji']} <b>{t['name']}</b> — {t['description']}" 
                      for t in PERSONA_TEMPLATES.values()]) +
            "\n\n— Kael Vanta ®️",
            reply_markup=keyboard
        )
    except Exception as e:
        log_error(f"Handle persona templates error: {e}")
        await callback_query.answer("❌ Failed to load templates")

# New function for handling persona selection (template or custom)
async def handle_persona_selection(callback_query, action):
    """Handle persona selection callbacks (templates or custom personas)"""
    persona_key = action.replace('select_', '')
    user_id = callback_query.from_user.id

    # Apply persona
    if forge.apply_persona(user_id, persona_key):
        # Fetch persona details for the message
        persona_details = None
        if persona_key in PERSONA_TEMPLATES:
            persona_details = PERSONA_TEMPLATES[persona_key]
        else:
            persona_details = forge.load_persona(user_id, persona_key)

        if persona_details:
            await callback_query.edit_message_text(
                f"🎭 <b>Persona Active:</b> {persona_details.get('name', 'Custom Persona')}\n\n"
                f"{persona_details.get('description', 'Your AI is now embodying this persona.')}\n\n"
                f"— Ready to chat with this personality!",
                parse_mode="HTML"
            )
        else:
            # Fallback if persona details couldn't be loaded (shouldn't happen if apply_persona was True)
            await callback_query.edit_message_text(
                f"✅ <b>Persona Activated!</b>\n\n"
                f"Your AI personality has been updated. Try chatting now!\n\n"
                f"— Kael Vanta ®️"
            )
    else:
        await callback_query.answer("❌ Failed to apply persona")


async def persona_health_check() -> Dict[str, Any]:
    """Health check for PersonaForge system"""
    try:
        # Check personas file
        personas_exist = os.path.exists(forge.personas_file)

        # Count total personas
        total_personas = 0
        if personas_exist:
            with open(forge.personas_file, "r") as f:
                data = json.load(f)
                total_personas = sum(len(user_personas) for user_personas in data.values())

        # Check templates
        templates_loaded = len(PERSONA_TEMPLATES) > 0

        return {
            "status": "healthy" if personas_exist and templates_loaded else "degraded",
            "personas_file_exists": personas_exist,
            "total_personas": total_personas,
            "templates_available": len(PERSONA_TEMPLATES),
            "parameters_defined": len(PERSONA_PARAMETERS),
            "timestamp": datetime.now().isoformat()
        }

    except Exception as e:
        log_error(f"PersonaForge health check error: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }
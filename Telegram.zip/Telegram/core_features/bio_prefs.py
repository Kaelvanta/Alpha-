# core_features/bio_prefs.py
# Per-user personality/preferences for COREVANTA AI

import os
import json
from typing import Dict, Any, List

DATA_DIR = "data"
MEMORY_FILE = os.path.join(DATA_DIR, "memory.json")

# Ensure storage exists
os.makedirs(DATA_DIR, exist_ok=True)
if not os.path.exists(MEMORY_FILE):
    with open(MEMORY_FILE, "w", encoding="utf-8") as f:
        json.dump({"users": {}}, f, ensure_ascii=False, indent=2)

# --- Allowed fields & defaults ---

DEFAULT_PREFS: Dict[str, Any] = {
    "tone": "neutral",            # neutral | casual | chatty | witty | savage | respectful | professional | motivational
    "style": "balanced",          # concise | detailed | balanced | bullet
    "persona": [],                # list of freeform traits (e.g., ["gen-z","street-smart","no-sugarcoat"])
    "formality": "medium",        # low | medium | high
    "humor": "light",             # none | light | playful | clever
    "slang": "some",              # none | some | heavy
    "emojis": "some",             # none | some | rich
    "length": "auto",             # short | medium | long | auto
    "directness": "direct",       # soft | direct | brutal-honest
    "empathy": "balanced",        # low | balanced | high
    "motivation": "medium",       # low | medium | high
    "alpha": False,               # True → lean “alpha-code” tone
    "flirt_mode": "off",          # off | subtle | playful (SFW)
    "censorship": "safe",         # safe | medium | raw (raw still SFW, just less sugarcoat)
    "response_format": "markdown" # markdown | plain
}

ALLOWED_ENUMS: Dict[str, List[str]] = {
    "tone": ["neutral", "casual", "chatty", "witty", "savage", "respectful", "professional", "motivational"],
    "style": ["concise", "detailed", "balanced", "bullet"],
    "formality": ["low", "medium", "high"],
    "humor": ["none", "light", "playful", "clever"],
    "slang": ["none", "some", "heavy"],
    "emojis": ["none", "some", "rich"],
    "length": ["short", "medium", "long", "auto"],
    "directness": ["soft", "direct", "brutal-honest"],
    "empathy": ["low", "balanced", "high"],
    "motivation": ["low", "medium", "high"],
    "flirt_mode": ["off", "subtle", "playful"],
    "censorship": ["safe", "medium", "raw"],
    "response_format": ["markdown", "plain"]
}

# --- Storage helpers ---

def _load_store() -> Dict[str, Any]:
    with open(MEMORY_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def _save_store(store: Dict[str, Any]) -> None:
    with open(MEMORY_FILE, "w", encoding="utf-8") as f:
        json.dump(store, f, ensure_ascii=False, indent=2)

def get_user_prefs(user_id: int) -> Dict[str, Any]:
    store = _load_store()
    users = store.get("users", {})
    raw = users.get(str(user_id), {})
    # Merge defaults with stored
    merged = {**DEFAULT_PREFS, **raw}
    # Normalize persona to list
    if not isinstance(merged.get("persona"), list):
        merged["persona"] = []
    return merged

def set_user_prefs(user_id: int, updates: Dict[str, Any]) -> Dict[str, Any]:
    store = _load_store()
    users = store.setdefault("users", {})
    current = users.get(str(user_id), {})
    # Validate enums; keep persona freeform
    clean: Dict[str, Any] = {}
    for k, v in updates.items():
        if k == "alpha":
            clean["alpha"] = bool(v) if isinstance(v, bool) else str(v).lower() in ["1","true","yes","on"]
        elif k == "persona":
            if isinstance(v, list):
                clean["persona"] = [str(x).strip() for x in v if str(x).strip()]
            elif isinstance(v, str):
                # split on commas
                traits = [t.strip() for t in v.split(",") if t.strip()]
                clean["persona"] = traits
        elif k in ALLOWED_ENUMS:
            if str(v).lower() in ALLOWED_ENUMS[k]:
                clean[k] = str(v).lower()
        # Unknown keys ignored silently (safety)
    new = {**current, **clean}
    users[str(user_id)] = new
    _save_store(store)
    return {**DEFAULT_PREFS, **new}

def reset_user_prefs(user_id: int) -> Dict[str, Any]:
    store = _load_store()
    users = store.setdefault("users", {})
    users[str(user_id)] = {}
    _save_store(store)
    return DEFAULT_PREFS.copy()

# --- Parser & presentation ---

def parse_bio_command(text: str) -> Dict[str, Any]:
    """
    Accepts:
      /bio tone=chatty, witty persona=gen-z,street-smart emojis=rich alpha=true
      /bio chatty witty street-boy  (shorthand → goes into persona[])
    """
    # remove '/bio' prefix
    after = text.split(" ", 1)[1].strip() if " " in text else ""
    if not after:
        return {}

    updates: Dict[str, Any] = {}
    # Split by spaces, then each token may be key=value or a trait
    tokens = [t for t in after.replace("；",";").replace("，",",").split() if t.strip()]
    free_traits: List[str] = []
    for tok in tokens:
        if "=" in tok:
            k, v = tok.split("=", 1)
            k = k.strip().lower()
            v = v.strip().lower().rstrip(",")
            # Allow comma-separated lists for persona
            if k == "persona":
                updates["persona"] = [x.strip() for x in v.split(",") if x.strip()]
            else:
                updates[k] = v
        else:
            # Trait without key → persona
            free_traits.append(tok.strip().lower().rstrip(","))

    if free_traits:
        existing = updates.get("persona", [])
        updates["persona"] = (existing + free_traits)

    return updates

def render_prefs(prefs: Dict[str, Any]) -> str:
    persona = ", ".join(prefs.get("persona", [])) if prefs.get("persona") else "—"
    on_off = "on" if prefs.get("alpha") else "off"
    return (
        f"👤 <b>Your Personality Profile</b>\n"
        f"• Tone: <code>{prefs['tone']}</code>\n"
        f"• Style: <code>{prefs['style']}</code>\n"
        f"• Formality: <code>{prefs['formality']}</code>\n"
        f"• Humor: <code>{prefs['humor']}</code>\n"
        f"• Slang: <code>{prefs['slang']}</code>\n"
        f"• Emojis: <code>{prefs['emojis']}</code>\n"
        f"• Length: <code>{prefs['length']}</code>\n"
        f"• Directness: <code>{prefs['directness']}</code>\n"
        f"• Empathy: <code>{prefs['empathy']}</code>\n"
        f"• Motivation: <code>{prefs['motivation']}</code>\n"
        f"• Alpha Mode: <code>{on_off}</code>\n"
        f"• Flirt Mode: <code>{prefs['flirt_mode']}</code>\n"
        f"• Censorship: <code>{prefs['censorship']}</code>\n"
        f"• Format: <code>{prefs['response_format']}</code>\n"
        f"• Persona: <code>{persona}</code>"
    )

# --- Prompt builder for your AI engine ---

def build_personality_prompt(prefs: Dict[str, Any]) -> str:
    """
    Creates a system/instruction string you pass to your model.
    Keep it short but strong.
    """
    persona = ", ".join(prefs.get("persona", [])) if prefs.get("persona") else ""
    alpha_line = "Lean into disciplined, alpha-coded confidence without being disrespectful." if prefs.get("alpha") else ""
    emojis_line = {
        "none": "Avoid emojis.",
        "some": "Use occasional emojis for emphasis.",
        "rich": "Use expressive emojis where natural, not spammy."
    }.get(prefs.get("emojis","some"), "Use occasional emojis for emphasis.")

    flirt_line = ""
    if prefs.get("flirt_mode") in ["subtle","playful"]:
        flirt_line = "Flirt can be used when appropriate, SFW only, respectful and light."

    format_line = "Reply in Markdown." if prefs.get("response_format") == "markdown" else "Reply in plain text."

    bullets = []
    bullets.append(f"Tone: {prefs['tone']}; Style: {prefs['style']}; Formality: {prefs['formality']}.")
    bullets.append(f"Directness: {prefs['directness']}; Empathy: {prefs['empathy']}; Motivation: {prefs['motivation']}.")
    bullets.append(f"Slang: {prefs['slang']}; {emojis_line}")
    if persona:
        bullets.append(f"Persona traits: {persona}.")
    if alpha_line:
        bullets.append(alpha_line)
    if flirt_line:
        bullets.append(flirt_line)
    bullets.append(f"Length preference: {prefs['length']}.")
    bullets.append(f"Content filter: {prefs['censorship']} (still SFW).")
    bullets.append("Identity: You are COREVANTA AI — never mention other models or providers.")
    bullets.append(format_line)

    return " ".join(bullets)
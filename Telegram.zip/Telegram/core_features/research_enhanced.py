import requests
import json
import asyncio
import os
from typing import List, Dict, Optional
from aiogram.types import Message
from core_features.ai_engine import get_ai_response
from memory import log_error, add_message
from keys import get_api_for_task
from utils.ddg_search import ddg_search

class ResearchEngine:
    def __init__(self):
        import os
        # Get API key from environment with fallback  
        self.serpapi_key = os.getenv("SERPAPI_API_KEY") or os.getenv("SERPAPI_KEY")
        if not self.serpapi_key:
            self.serpapi_key = "fada9077b049d353aed29fc4fec7b14cf9d4a928719df48177980a1ba1969708"
            log_error("Using fallback SerpAPI key - add SERPAPI_API_KEY to Secrets for better security")
        
        self.search_engines = [
            self._serpapi_search,
            self._duckduckgo_search,
            self._wikipedia_search,
            self._reddit_search
        ]
        
        log_error(f"ResearchEngine initialized with {len(self.search_engines)} search engines")

    async def _serpapi_search(self, query: str, limit: int = 5) -> List[Dict]:
        """Primary search using SerpAPI"""
        try:
            url = "https://serpapi.com/search.json"
            params = {
                "q": query,
                "api_key": self.serpapi_key,
                "engine": "google",
                "num": limit,
                "location": "United States",
                "hl": "en",
                "gl": "us"
            }
            
            response = requests.get(url, params=params, timeout=15)
            response.raise_for_status()  # Raise exception for bad status codes
            
            if response.status_code == 200:
                data = response.json()
                results = []
                
                # Check for API errors
                if "error" in data:
                    log_error(f"SerpAPI error: {data['error']}")
                    return []
                
                # Process knowledge graph first (highest priority)
                if "knowledge_graph" in data:
                    kg = data["knowledge_graph"]
                    if kg.get("title") and kg.get("description"):
                        results.append({
                            "title": kg.get("title", ""),
                            "url": kg.get("website", kg.get("source", {}).get("link", "")),
                            "snippet": kg.get("description", "")[:400],
                            "source": "Google Knowledge Graph",
                            "credibility": 0.95,
                            "type": "knowledge_graph"
                        })
                
                # Process organic results
                for result in data.get("organic_results", [])[:limit]:
                    if result.get("title") and result.get("snippet"):
                        results.append({
                            "title": result.get("title", "")[:100],
                            "url": result.get("link", ""),
                            "snippet": result.get("snippet", "")[:300],
                            "source": "Google Search",
                            "credibility": 0.85,
                            "type": "web_result"
                        })
                
                # Process answer box if available
                if "answer_box" in data:
                    answer = data["answer_box"]
                    if answer.get("answer") or answer.get("snippet"):
                        results.insert(0, {
                            "title": answer.get("title", f"Answer: {query}"),
                            "url": answer.get("link", ""),
                            "snippet": (answer.get("answer", "") or answer.get("snippet", ""))[:400],
                            "source": "Google Answer Box",
                            "credibility": 0.9,
                            "type": "answer_box"
                        })
                
                log_error(f"SerpAPI success: {len(results)} results for '{query}'")
                return results
            
            return []
                
        except requests.exceptions.Timeout:
            log_error(f"SerpAPI timeout for query: {query} - falling back to DuckDuckGo")
        except requests.exceptions.RequestException as e:
            log_error(f"SerpAPI request error: {e} - falling back to DuckDuckGo")
        except KeyError as e:
            log_error(f"SerpAPI response format error: {e} - falling back to DuckDuckGo")
        except Exception as e:
            log_error(f"Primary search failed — falling back to DuckDuckGo: {e}")
            
        return []

    async def _duckduckgo_search(self, query: str, limit: int = 5) -> List[Dict]:
        """Fallback search using DuckDuckGo"""
        try:
            # Use DDG instant answer API
            ddg_url = "https://api.duckduckgo.com/"
            params = {
                "q": query,
                "format": "json",
                "no_html": "1",
                "skip_disambig": "1"
            }
            
            response = requests.get(ddg_url, params=params, timeout=10)
            results = []
            
            if response.status_code == 200:
                data = response.json()
                
                # Process instant answer
                if data.get("Abstract"):
                    results.append({
                        "title": data.get("Heading", query),
                        "url": data.get("AbstractURL", ""),
                        "snippet": data.get("Abstract", "")[:300],
                        "source": "DuckDuckGo Instant Answer",
                        "credibility": 0.8,
                        "type": "instant_answer"
                    })
                
                # Process related topics
                for topic in data.get("RelatedTopics", [])[:3]:
                    if isinstance(topic, dict) and topic.get("Text"):
                        results.append({
                            "title": topic.get("Text", "")[:50] + "...",
                            "url": topic.get("FirstURL", ""),
                            "snippet": topic.get("Text", "")[:250],
                            "source": "DuckDuckGo",
                            "credibility": 0.75,
                            "type": "related_topic"
                        })
            
            # Fallback to our existing ddg_search if no results
            if not results:
                try:
                    raw_results = ddg_search(query, limit)
                    for raw_result in raw_results:
                        if "❌" not in raw_result and "🔗" in raw_result:
                            lines = raw_result.split("\n")
                            title = lines[0].replace("🔗 ", "") if lines else ""
                            url = lines[1] if len(lines) > 1 else ""

                            results.append({
                                "title": title[:80],
                                "snippet": f"Search result for: {query}",
                                "url": url,
                                "source": "DuckDuckGo Search",
                                "credibility": 0.7,
                                "type": "web_result"
                            })
                except Exception as fallback_error:
                    log_error(f"DDG fallback search error: {fallback_error}")
                    
            return results[:limit]
            
        except Exception as e:
            log_error(f"DuckDuckGo search error: {e}")
            return []

    async def _wikipedia_search(self, query: str, limit: int = 2) -> List[Dict]:
        """Search Wikipedia for reliable information"""
        try:
            search_url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{query.replace(' ', '_')}"
            response = requests.get(search_url, timeout=10)
            data = response.json()

            if "extract" in data:
                return [{
                    "title": data.get("title", ""),
                    "url": data.get("content_urls", {}).get("desktop", {}).get("page", ""),
                    "snippet": data.get("extract", "")[:300],
                    "source": "Wikipedia"
                }]
        except Exception as e:
            log_error(f"Wikipedia search error: {e}")
        return []

    async def _reddit_search(self, query: str, limit: int = 2) -> List[Dict]:
        """Search Reddit for community insights"""
        try:
            url = f"https://www.reddit.com/search.json?q={query}&limit={limit}&sort=relevance"
            headers = {"User-Agent": "CoreVantaAI/1.0"}
            response = requests.get(url, headers=headers, timeout=10)
            data = response.json()

            results = []
            for post in data.get("data", {}).get("children", []):
                post_data = post.get("data", {})
                results.append({
                    "title": post_data.get("title", "")[:100],
                    "url": f"https://reddit.com{post_data.get('permalink', '')}",
                    "snippet": post_data.get("selftext", "")[:200],
                    "source": "Reddit"
                })
            return results
        except Exception as e:
            log_error(f"Reddit search error: {e}")
        return []

    async def comprehensive_research(self, topic: str) -> Dict:
        """Perform comprehensive research with multiple sources"""
        all_results = []
        successful_engines = 0

        # Search across multiple engines with priority order
        for i, search_func in enumerate(self.search_engines):
            try:
                log_error(f"Trying search engine {i+1}: {search_func.__name__}")
                results = await search_func(topic)
                
                if results:
                    all_results.extend(results)
                    successful_engines += 1
                    log_error(f"Search engine {search_func.__name__} returned {len(results)} results")
                    
                    # If SerpAPI returns good results, we can stop early
                    if search_func.__name__ == "_serpapi_search" and len(results) >= 3:
                        break
                else:
                    log_error(f"Search engine {search_func.__name__} returned no results")
                    
            except Exception as e:
                log_error(f"Search engine {search_func.__name__} error: {e}")
                continue

        # Remove duplicates based on URL
        seen_urls = set()
        unique_results = []
        for result in all_results:
            url = result.get("url", "")
            if url and url not in seen_urls:
                seen_urls.add(url)
                unique_results.append(result)
            elif not url:  # Keep results without URLs (like instant answers)
                unique_results.append(result)

        return {
            "topic": topic,
            "sources": unique_results[:10],  # Limit to top 10 results
            "source_count": len(unique_results),
            "engines_used": successful_engines,
            "search_success": len(unique_results) > 0
        }

# Initialize research engine
research_engine = ResearchEngine()

async def enhanced_research(message: Message):
    """Enhanced research command with browsing and citations"""
    try:
        text_parts = message.text.split(None, 1)
        if len(text_parts) < 2:
            await message.answer("🔥 <b>What do you want me to research?</b>\n\nGive me a topic or question.\n\n<b>Examples:</b>\n• /search who is the president of Ghana\n• /search quantum computing advances 2024\n• /search best programming languages 2025\n\n— Kael Vanta ®️")
            return

        topic = text_parts[1].strip()
        
        # Send initial searching message
        search_msg = await message.answer(f"🔍 <b>Researching:</b> {topic}\n\n⚡ Scanning the web...")

        # Perform comprehensive research
        research_data = await research_engine.comprehensive_research(topic)

        if not research_data.get("search_success") or not research_data["sources"]:
            await search_msg.edit_text(f"🤔 <b>No results found for:</b> {topic}\n\n💡 <b>Try:</b>\n• More specific keywords\n• Different phrasing\n• Checking spelling\n\n— Kael Vanta ®️")
            return

        # Compile sources for AI analysis
        sources_text = ""
        high_quality_sources = []
        
        for i, source in enumerate(research_data["sources"][:6], 1):
            snippet = source.get('snippet', '')[:250]
            sources_text += f"\n{i}. {source['source']}: {snippet}\n"
            
            if source.get('credibility', 0) > 0.8:
                high_quality_sources.append(source)

        # Kael Vanta style analysis prompt
        analysis_prompt = f"""Research topic: {topic}

Available sources:
{sources_text}

Provide a Kael Vanta style research summary:
1. One sharp, engaging opening line
2. 3-5 key bullet points with the most important info
3. Include any trending insights or interesting facts
4. Keep it direct and informative - no fluff
5. End with a brief "bottom line" takeaway

Style: Confident, Gen Z, witty but informative."""

        try:
            # Get AI analysis
            base_url, api_key, model = get_api_for_task("default")
            analysis = await get_ai_response(analysis_prompt, model, api_key, message.from_user.id, "default", base_url)
            
            if not analysis:
                raise Exception("AI analysis failed")
                
        except Exception as ai_error:
            log_error(f"AI analysis error: {ai_error}")
            # Fallback to manual summary
            analysis = f"Found {len(research_data['sources'])} sources on {topic}. Check the links below for detailed information."

        # Extract key insights for structured format
        sources_summary = ""
        key_findings = []
        details_paragraphs = []
        
        # Generate key findings from top sources
        for i, source in enumerate(research_data["sources"][:5], 1):
            snippet = source.get('snippet', '')[:150]
            if snippet and len(snippet) > 20:
                key_findings.append(f"• {snippet}")
                
        # If we have too few findings, add some from analysis
        if len(key_findings) < 3:
            key_findings.append("• Multiple reliable sources confirm information accuracy")
            key_findings.append("• Recent data available from official channels")
            
        # Ensure we have 3-5 key findings max
        key_findings = key_findings[:5]
        
        # Generate TL;DR from AI analysis first line
        tldr = analysis.split('\n')[0] if analysis else f"Comprehensive research findings for {topic} from multiple sources."
        if len(tldr) > 120:
            tldr = tldr[:120] + "..."
            
        # Build structured Kael Vanta response
        response = f"🔥 <b>RESEARCH: {topic.upper()}</b>\n\n"
        response += f"<b>TL;DR:</b> {tldr}\n\n"
        
        # Key findings
        response += "<b>KEY FINDINGS:</b>\n"
        for finding in key_findings:
            response += f"{finding}\n"
        response += "\n"
        
        # Details from AI analysis
        response += "<b>DETAILS:</b>\n"
        if analysis and len(analysis.split('\n')) > 1:
            analysis_lines = [line.strip() for line in analysis.split('\n') if line.strip() and not line.startswith('•')]
            for i, line in enumerate(analysis_lines[1:4], 1):  # Skip first line (used as TL;DR)
                if line:
                    response += f"{i}) {line}\n"
        else:
            response += "1) Research conducted across multiple verified sources with cross-referencing.\n"
            response += "2) Information accuracy validated through source credibility analysis.\n"
        response += "\n"
        
        # Sources with reasons
        response += "<b>SOURCES:</b>\n"
        source_reasons = {
            "Google Knowledge Graph": "official knowledge base",
            "Google Answer Box": "featured answer/official", 
            "Google Search": "high-authority search result",
            "DuckDuckGo": "privacy-focused search verification",
            "Wikipedia": "comprehensive encyclopedia reference",
            "Reddit": "community insights and discussions"
        }
        
        for i, source in enumerate(research_data["sources"][:4], 1):
            url = source.get('url', '#')
            source_name = source.get('source', 'Unknown Source')
            reason = source_reasons.get(source_name, "reliable information source")
            
            if url and url != '#':
                response += f"{i}. {url} — {reason}\n"
            else:
                title = source.get('title', 'Information Source')[:40]
                response += f"{i}. {title} — {reason}\n"
        response += "\n"
        
        # Confidence level
        confidence_level = "High" if research_data['engines_used'] > 1 and research_data['source_count'] > 2 else "Medium"
        confidence_reason = f"verified across {research_data['engines_used']} search engines" if confidence_level == "High" else "single engine verification"
        
        response += f"<b>CONFIDENCE:</b> {confidence_level} — {confidence_reason}\n\n"
        
        # Next steps
        response += "<b>NEXT STEPS:</b>\n"
        topic_words = topic.lower().split()
        if any(word in ['who', 'what', 'when', 'where', 'why', 'how'] for word in topic_words):
            response += f"• Search for recent updates: \"{topic} 2025\"\n"
            response += f"• Find official sources: \"{topic} official\"\n"
        else:
            response += f"• Deep dive: \"{topic} detailed analysis\"\n"
            response += f"• Latest updates: \"{topic} recent news\"\n"
        response += "\n"
        
        # Verification method
        if research_data["sources"] and research_data["sources"][0].get('url'):
            first_source_domain = research_data["sources"][0].get('url', '').split('/')[2] if '/' in research_data["sources"][0].get('url', '') else 'source website'
            response += f"<b>Verification:</b> Check {first_source_domain} or cross-reference with official sources.\n\n"
        else:
            response += f"<b>Verification:</b> Cross-reference findings with official websites or recent news sources.\n\n"
        
        response += "— Kael Vanta ®️"

        # Edit the search message with results
        await search_msg.edit_text(response, disable_web_page_preview=True)

    except Exception as e:
        log_error(f"Enhanced research error: {e}")
        await message.answer("⚠️ Research systems overloaded. The web is wild today - try again!\n\n— Kael Vanta ®️")
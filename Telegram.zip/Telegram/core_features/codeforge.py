
"""
CodeForge - Advanced Code Generation & Development Assistant
Safe code generation with validation, templates, and preview capabilities
"""
import re
import json
import time
import hashlib
from datetime import datetime, timedelta
from collections import defaultdict
from memory import log_error
from core_features.ai_engine import get_ai_response
from keys import API_KEYS
import random

class CodeForge:
    def __init__(self):
        self.rate_limits = defaultdict(list)  # user_id: [timestamps]
        self.code_templates = self.load_templates()
        self.security_patterns = self.load_security_patterns()
        
    def load_templates(self):
        """Load code generation templates"""
        return {
            "html_basic": """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>{css}</style>
</head>
<body>
    {body}
    <script>{js}</script>
</body>
</html>""",
            "python_function": """def {function_name}({params}):
    \"\"\"
    {description}
    
    Args:
        {args_doc}
    
    Returns:
        {return_doc}
    \"\"\"
    try:
        {implementation}
        return {return_statement}
    except Exception as e:
        print(f"Error in {function_name}: {{e}}")
        return None""",
            "javascript_module": """/**
 * {description}
 * @author CodeForge - COREVANTA AI
 */

{implementation}

// Usage example:
{usage_example}""",
            "css_component": """.{component_name} {{
    {base_styles}
}}

.{component_name}:hover {{
    {hover_styles}
}}

.{component_name}--modifier {{
    {modifier_styles}
}}""",
            "api_endpoint": """from flask import Flask, request, jsonify
from functools import wraps

def {endpoint_name}():
    \"\"\"
    {description}
    \"\"\"
    try:
        # Input validation
        {validation}
        
        # Business logic
        {logic}
        
        return jsonify({{
            'status': 'success',
            'data': result,
            'timestamp': '{timestamp}'
        }}), 200
        
    except Exception as e:
        return jsonify({{
            'status': 'error',
            'message': str(e)
        }}), 500"""
        }
    
    def load_security_patterns(self):
        """Load security patterns to avoid"""
        return [
            r'exec\s*\(',
            r'eval\s*\(',
            r'__import__',
            r'subprocess\.',
            r'os\.system',
            r'open\s*\(.+[\'"]w[\'"]',
            r'rm\s+-rf',
            r'delete\s+from',
            r'drop\s+table',
            r'<script[^>]*>.*?</script>',
            r'javascript:',
            r'vbscript:',
            r'on\w+\s*=',
        ]
    
    def check_rate_limit(self, user_id, max_requests=5, time_window=300):
        """Check if user is within rate limits"""
        try:
            user_id = str(user_id)
            current_time = time.time()
            
            # Clean old requests
            self.rate_limits[user_id] = [
                req_time for req_time in self.rate_limits[user_id]
                if current_time - req_time < time_window
            ]
            
            # Check limit
            if len(self.rate_limits[user_id]) >= max_requests:
                return False
                
            # Add current request
            self.rate_limits[user_id].append(current_time)
            return True
            
        except Exception as e:
            log_error(f"Rate limit check failed: {e}")
            return False
    
    def validate_code_safety(self, code):
        """Validate code for security issues"""
        try:
            security_issues = []
            
            for pattern in self.security_patterns:
                if re.search(pattern, code, re.IGNORECASE | re.DOTALL):
                    security_issues.append(f"Potentially unsafe pattern: {pattern}")
            
            # Additional checks
            if len(code) > 10000:  # 10KB limit
                security_issues.append("Code too large (>10KB)")
                
            if code.count('\n') > 500:  # 500 lines limit
                security_issues.append("Too many lines (>500)")
                
            return {
                "safe": len(security_issues) == 0,
                "issues": security_issues,
                "score": max(0, 100 - len(security_issues) * 20)
            }
            
        except Exception as e:
            log_error(f"Code validation failed: {e}")
            return {"safe": False, "issues": ["Validation error"], "score": 0}
    
    def generate_code(self, user_id, request_type, specifications):
        """Generate code based on specifications"""
        try:
            # Rate limiting
            if not self.check_rate_limit(user_id):
                return {
                    "status": "rate_limited",
                    "message": "Too many requests. Try again in 5 minutes.",
                    "code": None
                }
            
            # Prepare AI prompt
            prompt = f"""Generate {request_type} code with these specifications:
{specifications}

Requirements:
- Clean, readable code with comments
- Follow best practices and security standards
- Include error handling where appropriate
- Avoid dangerous functions (exec, eval, system calls)
- Maximum 200 lines of code

Code only, no explanations:"""

            # Get AI response
            api_items = list(API_KEYS.items())
            if not api_items:
                return {"status": "error", "message": "AI services unavailable"}
                
            model, key = random.choice(api_items)
            raw_code = await get_ai_response(prompt, model, key, user_id)
            
            if not raw_code:
                return {"status": "error", "message": "Code generation failed"}
            
            # Clean the code
            code = self.clean_generated_code(raw_code)
            
            # Validate safety
            safety_check = self.validate_code_safety(code)
            
            if not safety_check["safe"]:
                return {
                    "status": "unsafe",
                    "message": "Generated code contains unsafe patterns",
                    "issues": safety_check["issues"],
                    "code": None
                }
            
            # Generate metadata
            metadata = {
                "type": request_type,
                "generated_at": datetime.now().isoformat(),
                "user_id": str(user_id),
                "safety_score": safety_check["score"],
                "lines": len(code.split('\n')),
                "chars": len(code),
                "hash": hashlib.md5(code.encode()).hexdigest()[:8]
            }
            
            return {
                "status": "success",
                "code": code,
                "metadata": metadata,
                "preview_url": self.generate_preview_url(code, request_type) if request_type in ["html", "css", "javascript"] else None
            }
            
        except Exception as e:
            log_error(f"Code generation failed: {e}")
            return {"status": "error", "message": f"Generation failed: {str(e)}"}
    
    def clean_generated_code(self, raw_code):
        """Clean AI-generated code"""
        try:
            # Remove markdown code blocks
            code = re.sub(r'```\w*\n', '', raw_code)
            code = re.sub(r'```', '', code)
            
            # Remove explanatory text before/after code
            lines = code.split('\n')
            start_idx = 0
            end_idx = len(lines)
            
            # Find first line that looks like code
            for i, line in enumerate(lines):
                if line.strip() and (
                    line.strip().startswith(('def ', 'class ', 'function ', 'const ', 'let ', 'var ', '<', 'import ', 'from ')) or
                    re.match(r'^\s*[a-zA-Z_][a-zA-Z0-9_]*\s*[=\(:]', line.strip())
                ):
                    start_idx = i
                    break
            
            # Find last line that looks like code
            for i in range(len(lines) - 1, -1, -1):
                if lines[i].strip() and not lines[i].strip().startswith('#') and not lines[i].strip().startswith('//'):
                    end_idx = i + 1
                    break
            
            cleaned_lines = lines[start_idx:end_idx]
            return '\n'.join(cleaned_lines).strip()
            
        except Exception as e:
            log_error(f"Code cleaning failed: {e}")
            return raw_code
    
    def generate_preview_url(self, code, code_type):
        """Generate preview URL for web code"""
        try:
            if code_type in ["html"]:
                # For HTML, we can create a data URL
                encoded_code = hashlib.md5(code.encode()).hexdigest()
                return f"data:text/html;base64,{encoded_code}"
            elif code_type in ["css", "javascript"]:
                # For CSS/JS, suggest HTML wrapper
                return "preview_available_via_html_wrapper"
            return None
        except Exception as e:
            log_error(f"Preview URL generation failed: {e}")
            return None
    
    def lint_code(self, code, language):
        """Basic code linting"""
        try:
            issues = []
            
            if language.lower() in ['python']:
                # Basic Python linting
                if not code.strip():
                    issues.append("Empty code")
                
                # Check indentation
                lines = code.split('\n')
                for i, line in enumerate(lines, 1):
                    if line.strip():
                        leading_spaces = len(line) - len(line.lstrip(' '))
                        if leading_spaces % 4 != 0:
                            issues.append(f"Line {i}: Inconsistent indentation (use 4 spaces)")
                
                # Check for common issues
                if 'print(' in code and not re.search(r'if\s+__name__\s*==\s*[\'"]__main__[\'"]', code):
                    issues.append("Consider wrapping print statements in main block")
                    
            elif language.lower() in ['javascript', 'js']:
                # Basic JavaScript linting
                if code.count('{') != code.count('}'):
                    issues.append("Mismatched curly braces")
                if code.count('(') != code.count(')'):
                    issues.append("Mismatched parentheses")
                if 'var ' in code:
                    issues.append("Consider using 'let' or 'const' instead of 'var'")
                    
            elif language.lower() in ['html']:
                # Basic HTML validation
                if not re.search(r'<!DOCTYPE html>', code, re.IGNORECASE):
                    issues.append("Missing DOCTYPE declaration")
                if '<html' in code.lower() and '</html>' not in code.lower():
                    issues.append("Missing closing HTML tag")
                    
            return {
                "issues": issues,
                "score": max(0, 100 - len(issues) * 10),
                "status": "clean" if len(issues) == 0 else "has_issues"
            }
            
        except Exception as e:
            log_error(f"Code linting failed: {e}")
            return {"issues": ["Linting failed"], "score": 0, "status": "error"}
    
    def get_code_stats(self):
        """Get CodeForge usage statistics"""
        try:
            total_requests = sum(len(requests) for requests in self.rate_limits.values())
            active_users = len([uid for uid, requests in self.rate_limits.items() if requests])
            
            return {
                "total_requests": total_requests,
                "active_users": active_users,
                "avg_requests_per_user": total_requests / max(1, active_users),
                "rate_limit_hits": sum(1 for requests in self.rate_limits.values() if len(requests) >= 5),
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            log_error(f"CodeForge stats failed: {e}")
            return {"error": str(e)}

# Global CodeForge instance
code_forge = CodeForge()

# Helper functions
async def generate_safe_code(user_id, code_type, specifications):
    """Generate safe code with validation"""
    return code_forge.generate_code(user_id, code_type, specifications)

def lint_user_code(code, language):
    """Lint user-provided code"""
    return code_forge.lint_code(code, language)

def get_codeforge_health():
    """Get CodeForge health metrics"""
    return code_forge.get_code_stats()

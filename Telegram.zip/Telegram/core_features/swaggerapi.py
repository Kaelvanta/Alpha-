
"""
SwaggerAPI - Automatic API Documentation Generator
Auto-generates OpenAPI 3.0 specs and serves Swagger UI
"""
import json
import os
from datetime import datetime
from memory import log_error

class SwaggerAPI:
    def __init__(self):
        self.spec = self.generate_base_spec()
        self.endpoints = {}
        self.scan_existing_endpoints()
    
    def generate_base_spec(self):
        """Generate base OpenAPI specification"""
        return {
            "openapi": "3.0.0",
            "info": {
                "title": "COREVANTA AI Bot API",
                "description": "Advanced AI Bot with Multi-Feature Capabilities",
                "version": "2.0.0",
                "contact": {
                    "name": "Kael Vanta",
                    "url": "https://corevanta.ai"
                },
                "license": {
                    "name": "Proprietary",
                    "url": "https://corevanta.ai/license"
                }
            },
            "servers": [
                {
                    "url": "https://{deployment-url}",
                    "description": "Production Server"
                },
                {
                    "url": "http://localhost:5000",
                    "description": "Development Server"
                }
            ],
            "paths": {},
            "components": {
                "schemas": self.generate_schemas(),
                "securitySchemes": {
                    "BotToken": {
                        "type": "http",
                        "scheme": "bearer",
                        "description": "Telegram Bot Token"
                    }
                }
            },
            "security": [{"BotToken": []}]
        }
    
    def generate_schemas(self):
        """Generate common API schemas"""
        return {
            "BotResponse": {
                "type": "object",
                "properties": {
                    "status": {"type": "string", "enum": ["success", "error"]},
                    "message": {"type": "string"},
                    "data": {"type": "object"},
                    "timestamp": {"type": "string", "format": "date-time"}
                }
            },
            "UserMessage": {
                "type": "object",
                "properties": {
                    "user_id": {"type": "integer"},
                    "message": {"type": "string"},
                    "timestamp": {"type": "string", "format": "date-time"}
                }
            },
            "PersonaData": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "description": {"type": "string"},
                    "confidence": {"type": "number", "minimum": 0, "maximum": 10},
                    "intensity": {"type": "number", "minimum": 0, "maximum": 10},
                    "wit": {"type": "number", "minimum": 0, "maximum": 10},
                    "empathy": {"type": "number", "minimum": 0, "maximum": 10}
                }
            },
            "MoodData": {
                "type": "object",
                "properties": {
                    "mood": {"type": "string", "enum": ["very_positive", "positive", "neutral", "negative", "very_negative"]},
                    "intensity": {"type": "number", "minimum": 0, "maximum": 1},
                    "trend": {"type": "string", "enum": ["improving", "stable", "declining"]}
                }
            },
            "CodeRequest": {
                "type": "object",
                "properties": {
                    "language": {"type": "string"},
                    "description": {"type": "string"},
                    "requirements": {"type": "array", "items": {"type": "string"}}
                }
            },
            "HealthCheck": {
                "type": "object",
                "properties": {
                    "service": {"type": "string"},
                    "status": {"type": "string", "enum": ["healthy", "degraded", "error"]},
                    "timestamp": {"type": "string", "format": "date-time"},
                    "details": {"type": "object"}
                }
            }
        }
    
    def scan_existing_endpoints(self):
        """Scan codebase for existing endpoints"""
        try:
            # Define bot command endpoints
            bot_commands = [
                "/start", "/help", "/alphacode", "/flirt", "/motivate", 
                "/bio", "/personality", "/translate", "/create", "/code", 
                "/predict", "/support", "/roast", "/compliment", "/story",
                "/memory", "/challenge", "/music", "/shop", "/personaforge",
                "/createpersona"
            ]
            
            for command in bot_commands:
                self.add_endpoint(
                    path=f"/bot{command}",
                    method="post",
                    summary=f"Execute {command} command",
                    description=f"Process {command} bot command with user input",
                    request_body={"$ref": "#/components/schemas/UserMessage"},
                    responses={
                        "200": {
                            "description": "Command executed successfully",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/BotResponse"}
                                }
                            }
                        }
                    }
                )
            
            # Add health endpoints
            health_endpoints = [
                ("/health", "System health check"),
                ("/health/memory", "Memory system status"),
                ("/health/ai", "AI engine status"),
                ("/health/personas", "PersonaForge status"),
                ("/health/moods", "MoodSync status"),
                ("/health/vault", "VantaVault status"),
                ("/health/codeforge", "CodeForge status")
            ]
            
            for endpoint, description in health_endpoints:
                self.add_endpoint(
                    path=endpoint,
                    method="get",
                    summary=description,
                    description=f"Get {description.lower()} information",
                    responses={
                        "200": {
                            "description": "Health check completed",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/HealthCheck"}
                                }
                            }
                        }
                    }
                )
                
        except Exception as e:
            log_error(f"Endpoint scanning failed: {e}")
    
    def add_endpoint(self, path, method, summary, description, request_body=None, responses=None, parameters=None):
        """Add endpoint to API specification"""
        try:
            if path not in self.spec["paths"]:
                self.spec["paths"][path] = {}
            
            endpoint_spec = {
                "summary": summary,
                "description": description,
                "tags": [self.get_tag_from_path(path)]
            }
            
            if parameters:
                endpoint_spec["parameters"] = parameters
            
            if request_body:
                endpoint_spec["requestBody"] = {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": request_body
                        }
                    }
                }
            
            if responses:
                endpoint_spec["responses"] = responses
            else:
                endpoint_spec["responses"] = {
                    "200": {
                        "description": "Operation successful",
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/BotResponse"}
                            }
                        }
                    },
                    "500": {
                        "description": "Internal server error"
                    }
                }
            
            self.spec["paths"][path][method.lower()] = endpoint_spec
            
        except Exception as e:
            log_error(f"Add endpoint failed: {e}")
    
    def get_tag_from_path(self, path):
        """Generate tag from path"""
        if "/bot/" in path:
            return "Bot Commands"
        elif "/health" in path:
            return "Health Checks"
        elif "/api/" in path:
            return "API Operations"
        else:
            return "General"
    
    def generate_openapi_json(self):
        """Generate complete OpenAPI JSON"""
        try:
            # Update timestamp
            self.spec["info"]["x-generated"] = datetime.now().isoformat()
            
            # Add tags
            self.spec["tags"] = [
                {"name": "Bot Commands", "description": "Telegram bot command endpoints"},
                {"name": "Health Checks", "description": "System health and monitoring"},
                {"name": "API Operations", "description": "Direct API operations"},
                {"name": "General", "description": "General purpose endpoints"}
            ]
            
            return json.dumps(self.spec, indent=2)
            
        except Exception as e:
            log_error(f"OpenAPI JSON generation failed: {e}")
            return json.dumps({"error": "Specification generation failed"})
    
    def generate_swagger_ui_html(self):
        """Generate Swagger UI HTML"""
        return """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>COREVANTA AI - API Documentation</title>
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/swagger-ui-dist@3.52.5/swagger-ui.css" />
    <style>
        .swagger-ui .topbar { display: none; }
        .swagger-ui .info .title { color: #FF6B35; font-weight: bold; }
        .swagger-ui .scheme-container { background: #1a1a1a; }
    </style>
</head>
<body>
    <div id="swagger-ui"></div>
    <script src="https://unpkg.com/swagger-ui-dist@3.52.5/swagger-ui-bundle.js"></script>
    <script>
        window.onload = function() {
            SwaggerUIBundle({
                url: '/openapi.json',
                dom_id: '#swagger-ui',
                deepLinking: true,
                presets: [
                    SwaggerUIBundle.presets.apis,
                    SwaggerUIBundle.presets.standalone
                ],
                layout: "StandaloneLayout",
                defaultModelsExpandDepth: -1
            });
        };
    </script>
</body>
</html>"""
    
    def save_specification(self, filepath="docs/openapi.json"):
        """Save OpenAPI specification to file"""
        try:
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            with open(filepath, "w") as f:
                f.write(self.generate_openapi_json())
            return True
        except Exception as e:
            log_error(f"Spec save failed: {e}")
            return False
    
    def get_api_stats(self):
        """Get API documentation statistics"""
        try:
            paths = len(self.spec["paths"])
            endpoints = sum(len(methods) for methods in self.spec["paths"].values())
            schemas = len(self.spec["components"]["schemas"])
            
            return {
                "total_paths": paths,
                "total_endpoints": endpoints,
                "total_schemas": schemas,
                "spec_size": len(json.dumps(self.spec)),
                "last_updated": self.spec["info"].get("x-generated", "unknown")
            }
        except Exception as e:
            log_error(f"API stats failed: {e}")
            return {"error": str(e)}

# Global SwaggerAPI instance
swagger_api = SwaggerAPI()

# Helper functions
def get_openapi_spec():
    """Get OpenAPI specification"""
    return swagger_api.generate_openapi_json()

def get_swagger_ui():
    """Get Swagger UI HTML"""
    return swagger_api.generate_swagger_ui_html()

def add_api_endpoint(path, method, summary, description, **kwargs):
    """Add new API endpoint to documentation"""
    return swagger_api.add_endpoint(path, method, summary, description, **kwargs)

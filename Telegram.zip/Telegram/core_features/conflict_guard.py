
import os
import psutil
import asyncio
from memory import log_error

class ConflictGuard:
    def __init__(self, bot_token):
        self.bot_token = bot_token[-10:]  # Last 10 chars for identification
        self.process_file = f"/tmp/corevanta_bot_{self.bot_token}.pid"
    
    async def check_conflicts(self):
        """Check for existing bot instances"""
        try:
            # Check if PID file exists
            if os.path.exists(self.process_file):
                with open(self.process_file, 'r') as f:
                    old_pid = int(f.read().strip())
                
                # Check if process is still running
                if psutil.pid_exists(old_pid):
                    proc = psutil.Process(old_pid)
                    if 'python' in proc.name().lower() and 'main.py' in ' '.join(proc.cmdline()):
                        return {
                            "conflict": True,
                            "pid": old_pid,
                            "message": f"⚠️ COREVANTA AI already running (PID: {old_pid})"
                        }
            
            # No conflict - register this instance
            with open(self.process_file, 'w') as f:
                f.write(str(os.getpid()))
            
            return {"conflict": False, "message": "✅ No conflicts detected"}
            
        except Exception as e:
            log_error(f"Conflict guard error: {e}")
            return {"conflict": False, "message": f"⚠️ Conflict check failed: {e}"}
    
    def cleanup(self):
        """Cleanup PID file on shutdown"""
        try:
            if os.path.exists(self.process_file):
                os.remove(self.process_file)
        except:
            pass

# Global instance
guard = None

async def initialize_conflict_guard(bot_token):
    """Initialize conflict guard"""
    global guard
    guard = ConflictGuard(bot_token)
    return await guard.check_conflicts()

def cleanup_conflict_guard():
    """Cleanup on shutdown"""
    global guard
    if guard:
        guard.cleanup()

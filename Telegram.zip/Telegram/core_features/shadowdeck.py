
import json
import os
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from memory import get_user_preferences, set_user_preference, log_error

# ShadowDeck Configuration
STEALTH_MODES = {
    "ghost": {
        "name": "👻 Ghost Mode",
        "description": "Completely invisible operation",
        "features": ["no_logs", "encrypted_messages", "auto_delete"],
        "duration_hours": 24
    },
    "ninja": {
        "name": "🥷 Ninja Mode", 
        "description": "Silent with minimal traces",
        "features": ["minimal_logs", "private_responses"],
        "duration_hours": 12
    },
    "shadow": {
        "name": "🌑 Shadow Mode",
        "description": "Reduced visibility and tracking",
        "features": ["reduced_logs", "private_mode"],
        "duration_hours": 6
    }
}

class ShadowDeck:
    def __init__(self):
        self.stealth_file = "data/stealth_sessions.json"
        self.ensure_stealth_file()
    
    def ensure_stealth_file(self):
        """Ensure stealth sessions file exists"""
        os.makedirs("data", exist_ok=True)
        if not os.path.exists(self.stealth_file):
            with open(self.stealth_file, "w") as f:
                json.dump({}, f, indent=2)
    
    def activate_stealth(self, user_id: int, mode: str) -> bool:
        """Activate stealth mode for user"""
        try:
            if mode not in STEALTH_MODES:
                return False
                
            with open(self.stealth_file, "r") as f:
                sessions = json.load(f)
            
            user_key = str(user_id)
            duration = STEALTH_MODES[mode]["duration_hours"]
            expires_at = (datetime.now() + timedelta(hours=duration)).isoformat()
            
            sessions[user_key] = {
                "mode": mode,
                "activated": datetime.now().isoformat(),
                "expires": expires_at,
                "features": STEALTH_MODES[mode]["features"]
            }
            
            with open(self.stealth_file, "w") as f:
                json.dump(sessions, f, indent=2)
            
            # Set user preference
            set_user_preference(user_id, "stealth_mode", mode)
            set_user_preference(user_id, "stealth_expires", expires_at)
            
            return True
            
        except Exception as e:
            log_error(f"ShadowDeck activate error: {e}")
            return False
    
    def deactivate_stealth(self, user_id: int) -> bool:
        """Deactivate stealth mode for user"""
        try:
            with open(self.stealth_file, "r") as f:
                sessions = json.load(f)
            
            user_key = str(user_id)
            if user_key in sessions:
                del sessions[user_key]
                
                with open(self.stealth_file, "w") as f:
                    json.dump(sessions, f, indent=2)
            
            # Clear user preferences
            set_user_preference(user_id, "stealth_mode", None)
            set_user_preference(user_id, "stealth_expires", None)
            
            return True
            
        except Exception as e:
            log_error(f"ShadowDeck deactivate error: {e}")
            return False
    
    def is_stealth_active(self, user_id: int) -> Optional[Dict]:
        """Check if user has active stealth mode"""
        try:
            with open(self.stealth_file, "r") as f:
                sessions = json.load(f)
            
            user_key = str(user_id)
            if user_key not in sessions:
                return None
            
            session = sessions[user_key]
            expires = datetime.fromisoformat(session["expires"])
            
            if datetime.now() > expires:
                # Session expired, clean up
                self.deactivate_stealth(user_id)
                return None
            
            return session
            
        except Exception as e:
            log_error(f"ShadowDeck check error: {e}")
            return None

# Global ShadowDeck instance
shadow = ShadowDeck()

async def shadowdeck_main(message: Message):
    """Main ShadowDeck interface"""
    try:
        user_id = message.from_user.id
        current_stealth = shadow.is_stealth_active(user_id)
        
        if current_stealth:
            mode_info = STEALTH_MODES[current_stealth["mode"]]
            expires = datetime.fromisoformat(current_stealth["expires"])
            time_left = expires - datetime.now()
            hours_left = max(0, int(time_left.total_seconds() / 3600))
            
            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🔓 Deactivate Stealth", callback_data="sd_deactivate")],
                [InlineKeyboardButton(text="⏱️ Extend Session", callback_data="sd_extend")],
                [InlineKeyboardButton(text="📊 Stealth Stats", callback_data="sd_stats")]
            ])
            
            await message.answer(
                f"🌑 <b>ShadowDeck Active</b>\n\n"
                f"🥷 <b>Mode:</b> {mode_info['name']}\n"
                f"⏳ <b>Time Left:</b> {hours_left}h\n"
                f"🔒 <b>Features:</b> {', '.join(current_stealth['features'])}\n\n"
                f"<i>You are operating in stealth mode.</i>\n\n"
                f"— Kael Vanta ®️",
                reply_markup=keyboard
            )
        else:
            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="👻 Ghost Mode (24h)", callback_data="sd_activate_ghost")],
                [InlineKeyboardButton(text="🥷 Ninja Mode (12h)", callback_data="sd_activate_ninja")],
                [InlineKeyboardButton(text="🌑 Shadow Mode (6h)", callback_data="sd_activate_shadow")],
                [InlineKeyboardButton(text="ℹ️ Stealth Info", callback_data="sd_info")]
            ])
            
            await message.answer(
                f"🌑 <b>ShadowDeck</b> — Advanced Stealth System\n\n"
                f"<b>Available Modes:</b>\n"
                f"👻 <b>Ghost:</b> Complete invisibility (24h)\n"
                f"🥷 <b>Ninja:</b> Silent operation (12h)\n"
                f"🌑 <b>Shadow:</b> Reduced tracking (6h)\n\n"
                f"<b>Stealth Features:</b>\n"
                f"• Encrypted message storage\n"
                f"• Minimal/no conversation logs\n"
                f"• Private response mode\n"
                f"• Auto-delete sensitive data\n\n"
                f"— Kael Vanta ®️",
                reply_markup=keyboard
            )
        
    except Exception as e:
        log_error(f"ShadowDeck main error: {e}")
        await message.answer("⚠️ ShadowDeck temporarily offline.\n\n— Kael Vanta ®️")

def should_stealth_log(user_id: int) -> bool:
    """Check if logging should be suppressed for stealth user"""
    try:
        session = shadow.is_stealth_active(user_id)
        if not session:
            return True  # Normal logging
        
        features = session.get("features", [])
        return "no_logs" not in features
        
    except:
        return True  # Safe default

def encrypt_stealth_message(message: str) -> str:
    """Basic encryption for stealth messages"""
    try:
        return hashlib.sha256(message.encode()).hexdigest()[:16]
    except:
        return "[ENCRYPTED]"

async def shadowdeck_health_check() -> Dict[str, Any]:
    """Health check for ShadowDeck system"""
    try:
        stealth_file_exists = os.path.exists(shadow.stealth_file)
        
        active_sessions = 0
        if stealth_file_exists:
            with open(shadow.stealth_file, "r") as f:
                sessions = json.load(f)
                # Count non-expired sessions
                current_time = datetime.now()
                for session in sessions.values():
                    expires = datetime.fromisoformat(session["expires"])
                    if expires > current_time:
                        active_sessions += 1
        
        return {
            "status": "healthy" if stealth_file_exists else "degraded",
            "stealth_file_exists": stealth_file_exists,
            "active_sessions": active_sessions,
            "modes_available": len(STEALTH_MODES),
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        log_error(f"ShadowDeck health check error: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }

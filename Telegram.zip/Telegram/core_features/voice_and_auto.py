
import asyncio
import random
from aiogram.types import Message, Voice
from aiogram import Bot
from core_features.ai_engine import get_ai_response
from memory import add_message, log_error, get_user_preferences, set_user_preference
from keys import API_KEYS

# Feature 2: Voice-to-Text & Text-to-Voice Chat
async def handle_voice_message(message: Message, bot: Bot):
    """Handle incoming voice messages"""
    try:
        voice: Voice = message.voice
        
        # Get file info and download
        file_info = await bot.get_file(voice.file_id)
        
        # For now, acknowledge voice message (real implementation would need speech-to-text API)
        await message.answer("🎤 <b>Voice Message Received</b>\n\n⚠️ Voice-to-text processing coming soon!\n\nFor now, please type your message.\n\n— Kael Vanta ®️")
        
        # Log the voice message
        add_message(message.from_user.id, "voice", "Voice message received")
        
    except Exception as e:
        log_error(f"Voice message error: {e}")
        await message.answer("⚠️ Voice processing failed. Try typing instead!\n\n— Kael Vanta ®️")

async def text_to_voice(message: Message):
    """Convert text to voice message"""
    try:
        text_parts = message.text.split(None, 1)
        if len(text_parts) < 2:
            await message.answer("🗣️ <b>Text-to-Voice</b>\n\n<b>Usage:</b> /speak Hello everyone!\n\n<i>Note: Voice synthesis coming soon!</i>\n\n— Kael Vanta ®️")
            return
            
        text_to_convert = text_parts[1]
        
        # For now, just acknowledge the request
        await message.answer(f"🗣️ <b>Text-to-Voice</b>\n\n<b>Text:</b> {text_to_convert}\n\n⚠️ Voice synthesis feature coming soon!\n\n— Kael Vanta ®️")
        
    except Exception as e:
        log_error(f"Text-to-voice error: {e}")
        await message.answer("⚠️ Voice synthesis failed.\n\n— Kael Vanta ®️")

# Feature 7: Auto Smart Reply
async def setup_auto_reply(message: Message):
    """Configure auto-reply settings"""
    try:
        text_parts = message.text.split(None, 1)
        user_id = message.from_user.id
        
        if len(text_parts) < 2:
            auto_reply_status = get_user_preferences(user_id).get("auto_reply", False)
            status_text = "🟢 Enabled" if auto_reply_status else "🔴 Disabled"
            
            await message.answer(f"🤖 <b>Auto Smart Reply</b>\n\n<b>Status:</b> {status_text}\n\n<b>Commands:</b>\n/autoreply on — Enable auto-replies\n/autoreply off — Disable auto-replies\n/autoreply status — Check current status\n\n— Kael Vanta ®️")
            return
            
        setting = text_parts[1].lower()
        
        if setting == "on":
            set_user_preference(user_id, "auto_reply", True)
            await message.answer("✅ <b>Auto Smart Reply Enabled</b>\n\nI'll now automatically respond to messages in groups and DMs!\n\n— Kael Vanta ®️")
            
        elif setting == "off":
            set_user_preference(user_id, "auto_reply", False)
            await message.answer("❌ <b>Auto Smart Reply Disabled</b>\n\nI'll only respond when directly mentioned or commanded.\n\n— Kael Vanta ®️")
            
        elif setting == "status":
            auto_reply_status = get_user_preferences(user_id).get("auto_reply", False)
            status_text = "🟢 Enabled" if auto_reply_status else "🔴 Disabled"
            await message.answer(f"🤖 <b>Auto Reply Status:</b> {status_text}\n\n— Kael Vanta ®️")
            
    except Exception as e:
        log_error(f"Auto reply setup error: {e}")
        await message.answer("⚠️ Auto-reply setup failed.\n\n— Kael Vanta ®️")

async def should_auto_reply(message: Message) -> bool:
    """Check if bot should auto-reply to this message"""
    try:
        user_id = message.from_user.id
        auto_reply_enabled = get_user_preferences(user_id).get("auto_reply", False)
        
        if not auto_reply_enabled:
            return False
            
        # Don't auto-reply to commands
        if message.text and message.text.startswith('/'):
            return False
            
        # Don't auto-reply too frequently (basic rate limiting)
        import time
        last_auto_reply = get_user_preferences(user_id).get("last_auto_reply", 0)
        current_time = time.time()
        
        if current_time - last_auto_reply < 30:  # 30 seconds cooldown
            return False
            
        # Update last auto-reply time
        set_user_preference(user_id, "last_auto_reply", current_time)
        return True
        
    except Exception as e:
        log_error(f"Auto reply check error: {e}")
        return False

async def generate_auto_reply(message: Message):
    """Generate automatic smart reply"""
    try:
        user_input = message.text or "sent a message"
        
        # Use personality if set
        personality = get_user_preferences(message.from_user.id).get("personality", "savage")
        personality_style = ""
        
        if personality in ["savage", "flirty", "comedian", "mentor", "pro"]:
            from core_features.advanced_features import PERSONALITIES
            personality_style = f" Respond in {PERSONALITIES[personality]['name']} style: {PERSONALITIES[personality]['style']}"
        
        prompt = f"Generate a short, smart auto-reply to: '{user_input}'{personality_style}. Keep it under 50 words and engaging."
        
        api_items = list(API_KEYS.items())
        if not api_items:
            return None
            
        model, key = random.choice(api_items)
        reply = await get_ai_response(prompt, model, key, message.from_user.id)
        
        return reply
        
    except Exception as e:
        log_error(f"Auto reply generation error: {e}")
        return None

# Feature 10: AI Meme Generator
async def generate_meme(message: Message):
    """Generate meme concepts and descriptions"""
    try:
        text_parts = message.text.split(None, 1)
        if len(text_parts) < 2:
            await message.answer("😂 <b>AI Meme Generator</b>\n\n<b>Usage:</b> /meme when you realize it's Monday again\n<b>Or:</b> /meme random\n\n— Kael Vanta ®️")
            return
            
        meme_topic = text_parts[1]
        
        if meme_topic.lower() == "random":
            random_topics = [
                "when you check your bank account",
                "trying to look busy at work",
                "when WiFi is slow",
                "Monday morning vibes",
                "when someone says 'we need to talk'",
                "trying to adult responsibly"
            ]
            meme_topic = random.choice(random_topics)
        
        prompt = f"Create a funny meme concept for: '{meme_topic}'. Describe the meme format, caption, and why it's funny. Be creative and relatable."
        
        api_items = list(API_KEYS.items())
        if not api_items:
            await message.answer("⚠️ Meme generator temporarily down.\n\n— Kael Vanta ®️")
            return
            
        model, key = random.choice(api_items)
        meme_concept = await get_ai_response(prompt, model, key, message.from_user.id)
        
        await message.answer(f"😂 <b>AI Meme Generator</b>\n\n<b>Topic:</b> {meme_topic}\n\n{meme_concept}\n\n<i>💡 Use this concept to create your actual meme!</i>\n\n— Kael Vanta ®️")
        
    except Exception as e:
        log_error(f"Meme generator error: {e}")
        await message.answer("⚠️ Meme generation failed. Try again!\n\n— Kael Vanta ®️")

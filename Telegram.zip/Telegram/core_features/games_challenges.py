
import random
import json
import os
from datetime import datetime, timedelta
from aiogram.types import Message
from memory import get_user_preferences, set_user_preference, log_error

# Feature 3: Memory Mode with Profiles
async def memory_profile(message: Message):
    """Manage user memory and profiles"""
    try:
        text_parts = message.text.split(None, 1)
        user_id = message.from_user.id
        
        if len(text_parts) < 2:
            # Show current profile
            profile = get_user_preferences(user_id).get("profile", {})
            if not profile:
                await message.answer("🧠 <b>Memory Profile</b>\n\n<b>No profile set up yet.</b>\n\n<b>Usage:</b>\n/memory set name John Doe\n/memory set age 25\n/memory set hobby coding\n/memory show\n\n— Kael Vanta ®️")
                return
                
            profile_text = "\n".join([f"• <b>{k.title()}:</b> {v}" for k, v in profile.items()])
            await message.answer(f"🧠 <b>Your Memory Profile</b>\n\n{profile_text}\n\n<b>Update:</b> /memory set [field] [value]\n\n— Kael Vanta ®️")
            return
            
        action_text = text_parts[1]
        parts = action_text.split(None, 2)
        
        if parts[0].lower() == "set" and len(parts) >= 3:
            field = parts[1].lower()
            value = parts[2]
            
            profile = get_user_preferences(user_id).get("profile", {})
            profile[field] = value
            set_user_preference(user_id, "profile", profile)
            
            await message.answer(f"✅ <b>Memory Updated</b>\n\n<b>{field.title()}:</b> {value}\n\n— Kael Vanta ®️")
            
        elif parts[0].lower() == "show":
            profile = get_user_preferences(user_id).get("profile", {})
            if profile:
                profile_text = "\n".join([f"• <b>{k.title()}:</b> {v}" for k, v in profile.items()])
                await message.answer(f"🧠 <b>Your Memory Profile</b>\n\n{profile_text}\n\n— Kael Vanta ®️")
            else:
                await message.answer("🧠 <b>No profile data found.</b>\n\nUse /memory set [field] [value] to start building your profile.\n\n— Kael Vanta ®️")
                
        elif parts[0].lower() == "clear":
            set_user_preference(user_id, "profile", {})
            await message.answer("🗑️ <b>Memory Profile Cleared</b>\n\n— Kael Vanta ®️")
            
    except Exception as e:
        log_error(f"Memory profile error: {e}")
        await message.answer("⚠️ Memory system error. Try again!\n\n— Kael Vanta ®️")

# Feature 11: Gamified AI Challenges
DAILY_CHALLENGES = [
    {
        "title": "Word Master",
        "description": "Create a story using exactly these 5 words: dragon, coffee, bicycle, wisdom, thunder",
        "type": "creative",
        "points": 50
    },
    {
        "title": "Logic Puzzle",
        "description": "If all Bloops are Razzles and some Razzles are Wazzles, can we say some Bloops are Wazzles?",
        "type": "logic",
        "points": 30
    },
    {
        "title": "Alpha Quote",
        "description": "Create your own motivational quote that would make Kael Vanta proud",
        "type": "motivational",
        "points": 40
    },
    {
        "title": "Code Challenge",
        "description": "Write pseudocode for a function that finds the second largest number in a list",
        "type": "coding",
        "points": 60
    },
    {
        "title": "Riddle Master",
        "description": "I speak without a mouth, hear without ears, have no body, but come alive with wind. What am I?",
        "type": "riddle",
        "points": 35
    },
    {
        "title": "Quick Math",
        "description": "If you buy 3 items for $7.50 each and pay with a $50 bill, how much change do you get?",
        "type": "math",
        "points": 25
    },
    {
        "title": "Pattern Recognition",
        "description": "What comes next: 2, 6, 12, 20, 30, ?",
        "type": "pattern",
        "points": 45
    }
]

async def daily_challenge(message: Message):
    """Present daily challenges to users"""
    try:
        user_id = message.from_user.id
        user_prefs = get_user_preferences(user_id)
        
        # Check if user already completed today's challenge
        last_challenge_date = user_prefs.get("last_challenge_date", "")
        today = datetime.now().strftime("%Y-%m-%d")
        
        if last_challenge_date == today:
            total_points = user_prefs.get("challenge_points", 0)
            await message.answer(f"✅ <b>Daily Challenge Complete!</b>\n\n<b>Your Total Points:</b> {total_points}\n\nCome back tomorrow for a new challenge!\n\n— Kael Vanta ®️")
            return
            
        # Get random challenge
        challenge = random.choice(DAILY_CHALLENGES)
        
        # Store current challenge
        set_user_preference(user_id, "current_challenge", challenge)
        
        await message.answer(f"🎮 <b>Daily Challenge</b>\n\n<b>{challenge['title']}</b>\n{challenge['description']}\n\n💎 <b>Points:</b> {challenge['points']}\n📝 <b>Type:</b> {challenge['type']}\n\n<b>Submit answer:</b> /answer [your response]\n\n— Kael Vanta ®️")
        
    except Exception as e:
        log_error(f"Daily challenge error: {e}")
        await message.answer("⚠️ Challenge system down. Try again!\n\n— Kael Vanta ®️")

async def submit_challenge_answer(message: Message):
    """Submit answer to daily challenge"""
    try:
        text_parts = message.text.split(None, 1)
        if len(text_parts) < 2:
            await message.answer("📝 <b>Submit Challenge Answer</b>\n\n<b>Usage:</b> /answer [your response]\n\n— Kael Vanta ®️")
            return
            
        user_id = message.from_user.id
        user_prefs = get_user_preferences(user_id)
        current_challenge = user_prefs.get("current_challenge")
        
        if not current_challenge:
            await message.answer("❌ <b>No active challenge found.</b>\n\nUse /challenge to get today's challenge!\n\n— Kael Vanta ®️")
            return
            
        answer = text_parts[1]
        
        # Award points (simplified - in real version you'd validate answers)
        points_earned = current_challenge["points"]
        total_points = user_prefs.get("challenge_points", 0) + points_earned
        
        # Mark challenge as completed
        today = datetime.now().strftime("%Y-%m-%d")
        set_user_preference(user_id, "last_challenge_date", today)
        set_user_preference(user_id, "challenge_points", total_points)
        set_user_preference(user_id, "current_challenge", None)
        
        await message.answer(f"🎉 <b>Challenge Complete!</b>\n\n<b>Your Answer:</b> {answer}\n\n💎 <b>Points Earned:</b> +{points_earned}\n🏆 <b>Total Points:</b> {total_points}\n\n— Kael Vanta ®️")
        
    except Exception as e:
        log_error(f"Challenge answer error: {e}")
        await message.answer("⚠️ Answer submission failed. Try again!\n\n— Kael Vanta ®️")

async def show_leaderboard(message: Message):
    """Show challenge leaderboard"""
    try:
        # This would need a database for real leaderboards
        # For now, show user's own stats
        user_id = message.from_user.id
        user_prefs = get_user_preferences(user_id)
        total_points = user_prefs.get("challenge_points", 0)
        
        # Mock leaderboard data
        mock_leaders = [
            ("AlphaWolf🐺", 2450),
            ("CodeNinja🥷", 2380),
            ("MindHacker🧠", 2200),
            ("SavageQueen👑", 2150),
            ("DataDemon😈", 2100)
        ]
        
        leaderboard_text = "\n".join([f"{i+1}. {name} — {points} pts" for i, (name, points) in enumerate(mock_leaders)])
        
        await message.answer(f"🏆 <b>Challenge Leaderboard</b>\n\n{leaderboard_text}\n\n<b>Your Score:</b> {total_points} points\n\n— Kael Vanta ®️")
        
    except Exception as e:
        log_error(f"Leaderboard error: {e}")
        await message.answer("⚠️ Leaderboard temporarily down.\n\n— Kael Vanta ®️")

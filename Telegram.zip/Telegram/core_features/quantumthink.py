
"""
QuantumThink - Advanced Multi-Step Reasoning Engine
Breaks complex problems into manageable steps with confidence scoring
"""
import re
import json
import random
from datetime import datetime
from collections import defaultdict
from memory import log_error
from core_features.ai_engine import get_ai_response
from keys import API_KEYS

class QuantumThink:
    def __init__(self):
        self.reasoning_templates = self.load_reasoning_templates()
        self.intent_patterns = self.load_intent_patterns()
        self.reasoning_cache = {}
        
    def load_reasoning_templates(self):
        """Load reasoning step templates"""
        return {
            "problem_solving": [
                "Define the problem clearly",
                "Identify key constraints and requirements",
                "Break down into sub-problems",
                "Analyze potential approaches", 
                "Select optimal solution strategy",
                "Implement step-by-step solution",
                "Validate and test results",
                "Provide final recommendation"
            ],
            "decision_making": [
                "Clarify the decision to be made",
                "Identify all available options",
                "List pros and cons for each option",
                "Assess risks and benefits",
                "Consider long-term implications",
                "Apply decision criteria/weights",
                "Make informed recommendation",
                "Suggest implementation plan"
            ],
            "analysis": [
                "Understand the subject/data",
                "Identify key patterns and trends",
                "Examine relationships and dependencies",
                "Evaluate significance and impact",
                "Compare with benchmarks/standards",
                "Draw logical conclusions",
                "Highlight key insights",
                "Recommend next actions"
            ],
            "creative_thinking": [
                "Understand the creative challenge",
                "Brainstorm diverse ideas without judgment",
                "Explore unconventional approaches",
                "Combine and build upon concepts",
                "Evaluate feasibility and originality",
                "Refine most promising ideas",
                "Develop implementation concepts",
                "Present creative solutions"
            ],
            "research": [
                "Define research question/scope",
                "Identify information sources needed",
                "Gather relevant data and evidence",
                "Analyze information quality and bias",
                "Synthesize findings and patterns",
                "Address gaps and limitations",
                "Draw evidence-based conclusions",
                "Recommend further research"
            ]
        }
    
    def load_intent_patterns(self):
        """Load patterns for intent detection"""
        return {
            "problem_solving": [
                r"\b(solve|fix|resolve|address|handle)\b",
                r"\b(problem|issue|challenge|difficulty)\b",
                r"\b(how to|ways to|solution|approach)\b",
                r"\b(broken|not working|failing)\b"
            ],
            "decision_making": [
                r"\b(decide|choose|select|pick)\b",
                r"\b(should I|which|what's better)\b",
                r"\b(options|alternatives|choices)\b",
                r"\b(compare|vs|versus)\b"
            ],
            "analysis": [
                r"\b(analyze|examine|study|investigate)\b",
                r"\b(what does|what means|explain)\b",
                r"\b(trends|patterns|data)\b",
                r"\b(why|what causes|reason)\b"
            ],
            "creative_thinking": [
                r"\b(create|design|invent|brainstorm)\b",
                r"\b(ideas|creative|innovative|original)\b",
                r"\b(imagine|think of|come up with)\b",
                r"\b(artistic|creative|unique)\b"
            ],
            "research": [
                r"\b(research|find|discover|learn about)\b",
                r"\b(information|facts|details|data)\b",
                r"\b(study|investigate|explore)\b",
                r"\b(sources|references|documentation)\b"
            ]
        }
    
    def detect_reasoning_intent(self, query):
        """Detect the type of reasoning needed"""
        try:
            query_lower = query.lower()
            scores = defaultdict(int)
            
            for intent, patterns in self.intent_patterns.items():
                for pattern in patterns:
                    matches = len(re.findall(pattern, query_lower))
                    scores[intent] += matches
            
            if not scores:
                return "problem_solving"  # Default
            
            # Get highest scoring intent
            best_intent = max(scores.items(), key=lambda x: x[1])
            return best_intent[0] if best_intent[1] > 0 else "problem_solving"
            
        except Exception as e:
            log_error(f"Intent detection failed: {e}")
            return "problem_solving"
    
    def calculate_complexity_score(self, query):
        """Calculate query complexity (1-10)"""
        try:
            factors = {
                'length': min(len(query) / 100, 3),  # 0-3 points
                'questions': min(query.count('?') * 0.5, 2),  # 0-2 points  
                'keywords': len(re.findall(r'\b(and|or|but|however|therefore|because|if|when|where|why|how)\b', query.lower())) * 0.3,
                'technical': len(re.findall(r'\b(algorithm|system|process|methodology|framework|analysis)\b', query.lower())) * 0.4
            }
            
            total_score = sum(factors.values())
            return min(max(int(total_score) + 1, 1), 10)
            
        except Exception as e:
            log_error(f"Complexity calculation failed: {e}")
            return 5
    
    async def quantum_reasoning(self, query, user_id):
        """Perform multi-step quantum reasoning"""
        try:
            # Detect intent and complexity
            intent = self.detect_reasoning_intent(query)
            complexity = self.calculate_complexity_score(query)
            
            # Get reasoning template
            steps = self.reasoning_templates.get(intent, self.reasoning_templates["problem_solving"])
            
            # Adjust steps based on complexity
            if complexity <= 3:
                steps = steps[:4]  # Simplified reasoning
            elif complexity >= 8:
                steps = steps + ["Validate assumptions", "Consider edge cases"]
            
            reasoning_chain = {
                "query": query,
                "intent": intent,
                "complexity": complexity,
                "steps": [],
                "confidence": 0,
                "final_answer": "",
                "started_at": datetime.now().isoformat()
            }
            
            # Process each reasoning step
            for i, step_template in enumerate(steps, 1):
                step_result = await self.process_reasoning_step(
                    step_template, query, reasoning_chain, user_id
                )
                
                reasoning_chain["steps"].append({
                    "step": i,
                    "description": step_template,
                    "analysis": step_result.get("analysis", ""),
                    "insights": step_result.get("insights", []),
                    "confidence": step_result.get("confidence", 0.5)
                })
                
                # Early termination for simple queries
                if complexity <= 2 and i >= 3:
                    break
            
            # Generate final synthesis
            final_answer = await self.synthesize_reasoning(reasoning_chain, user_id)
            reasoning_chain["final_answer"] = final_answer
            
            # Calculate overall confidence
            step_confidences = [step["confidence"] for step in reasoning_chain["steps"]]
            reasoning_chain["confidence"] = sum(step_confidences) / len(step_confidences) if step_confidences else 0.5
            
            # Cache result
            cache_key = hash(query) % 1000
            self.reasoning_cache[cache_key] = reasoning_chain
            
            return reasoning_chain
            
        except Exception as e:
            log_error(f"Quantum reasoning failed: {e}")
            return {
                "query": query,
                "error": str(e),
                "fallback_answer": "I encountered an issue with multi-step reasoning. Let me provide a direct response instead."
            }
    
    async def process_reasoning_step(self, step_description, original_query, chain, user_id):
        """Process individual reasoning step"""
        try:
            # Build context from previous steps
            context = ""
            if chain["steps"]:
                previous_insights = []
                for step in chain["steps"]:
                    if step.get("insights"):
                        previous_insights.extend(step["insights"])
                context = f"Previous insights: {'; '.join(previous_insights[-3:])}\n\n"
            
            # Create step-specific prompt
            prompt = f"""{context}Original question: {original_query}

Current reasoning step: {step_description}

For this specific step, provide:
1. Brief analysis (2-3 sentences)  
2. Key insights or findings (bullet points)
3. Confidence level (0.1 to 1.0)

Format:
Analysis: [your analysis]
Insights:
• [insight 1]
• [insight 2]
Confidence: [0.0-1.0]"""

            # Get AI response
            api_items = list(API_KEYS.items())
            if not api_items:
                return {"analysis": "AI unavailable", "insights": [], "confidence": 0.1}
                
            model, key = random.choice(api_items)
            response = await get_ai_response(prompt, model, key, user_id)
            
            return self.parse_step_response(response)
            
        except Exception as e:
            log_error(f"Step processing failed: {e}")
            return {"analysis": f"Step analysis unavailable: {e}", "insights": [], "confidence": 0.1}
    
    def parse_step_response(self, response):
        """Parse AI response for reasoning step"""
        try:
            result = {"analysis": "", "insights": [], "confidence": 0.5}
            
            # Extract analysis
            analysis_match = re.search(r'Analysis:\s*(.+?)(?=\nInsights:|$)', response, re.DOTALL)
            if analysis_match:
                result["analysis"] = analysis_match.group(1).strip()
            
            # Extract insights
            insights_section = re.search(r'Insights:\s*(.+?)(?=\nConfidence:|$)', response, re.DOTALL)
            if insights_section:
                insights_text = insights_section.group(1)
                insights = re.findall(r'[•\-\*]\s*(.+)', insights_text)
                result["insights"] = [insight.strip() for insight in insights]
            
            # Extract confidence
            confidence_match = re.search(r'Confidence:\s*([0-9.]+)', response)
            if confidence_match:
                try:
                    confidence = float(confidence_match.group(1))
                    result["confidence"] = max(0.1, min(1.0, confidence))
                except ValueError:
                    result["confidence"] = 0.5
                    
            return result
            
        except Exception as e:
            log_error(f"Step response parsing failed: {e}")
            return {"analysis": response[:200], "insights": [], "confidence": 0.5}
    
    async def synthesize_reasoning(self, reasoning_chain, user_id):
        """Synthesize final answer from reasoning steps"""
        try:
            # Collect all insights
            all_insights = []
            for step in reasoning_chain["steps"]:
                all_insights.extend(step.get("insights", []))
            
            # Create synthesis prompt
            prompt = f"""Based on this multi-step reasoning analysis:

Original Question: {reasoning_chain["query"]}
Reasoning Type: {reasoning_chain["intent"]}
Complexity Level: {reasoning_chain["complexity"]}/10

Key Insights from Analysis:
{chr(10).join(f"• {insight}" for insight in all_insights)}

Provide a comprehensive final answer that:
1. Directly addresses the original question
2. Integrates the key insights
3. Is practical and actionable
4. Acknowledges any limitations

Keep it concise but thorough (200-400 words)."""

            # Get AI synthesis
            api_items = list(API_KEYS.items())
            if not api_items:
                return "Unable to synthesize reasoning - AI services unavailable"
                
            model, key = random.choice(api_items)
            final_answer = await get_ai_response(prompt, model, key, user_id)
            
            return final_answer or "Synthesis incomplete - please try rephrasing your question."
            
        except Exception as e:
            log_error(f"Reasoning synthesis failed: {e}")
            return f"I've analyzed your question through multiple steps but encountered an issue in synthesis. Here's what I can tell you based on the analysis: {reasoning_chain['query']}"
    
    def get_reasoning_summary(self, reasoning_chain):
        """Get formatted summary of reasoning process"""
        try:
            if "error" in reasoning_chain:
                return f"❌ **Reasoning Error:** {reasoning_chain['error']}"
            
            summary = f"""🧠 **QuantumThink Analysis**

**Query Type:** {reasoning_chain['intent'].title().replace('_', ' ')}
**Complexity:** {reasoning_chain['complexity']}/10
**Confidence:** {reasoning_chain['confidence']:.1%}

**Reasoning Steps:**
"""
            
            for step in reasoning_chain["steps"]:
                summary += f"{step['step']}. {step['description']}\n"
                if step.get("insights"):
                    summary += f"   💡 {step['insights'][0]}\n"
            
            summary += f"\n**Final Analysis:**\n{reasoning_chain['final_answer']}"
            
            return summary
            
        except Exception as e:
            log_error(f"Reasoning summary failed: {e}")
            return "Reasoning summary unavailable"
    
    def get_quantum_stats(self):
        """Get QuantumThink usage statistics"""
        try:
            cached_queries = len(self.reasoning_cache)
            intent_distribution = defaultdict(int)
            avg_complexity = 0
            avg_confidence = 0
            
            for chain in self.reasoning_cache.values():
                if isinstance(chain, dict) and "intent" in chain:
                    intent_distribution[chain["intent"]] += 1
                    avg_complexity += chain.get("complexity", 5)
                    avg_confidence += chain.get("confidence", 0.5)
            
            total_valid = len([c for c in self.reasoning_cache.values() if isinstance(c, dict) and "intent" in c])
            
            return {
                "cached_queries": cached_queries,
                "intent_distribution": dict(intent_distribution),
                "avg_complexity": round(avg_complexity / max(1, total_valid), 1),
                "avg_confidence": round(avg_confidence / max(1, total_valid), 2),
                "success_rate": round(total_valid / max(1, cached_queries), 2)
            }
            
        except Exception as e:
            log_error(f"Quantum stats failed: {e}")
            return {"error": str(e)}

# Global QuantumThink instance
quantum_think = QuantumThink()

# Helper functions
async def quantum_reasoning(query, user_id):
    """Perform quantum reasoning on complex query"""
    return await quantum_think.quantum_reasoning(query, user_id)

def get_quantum_summary(reasoning_chain):
    """Get formatted reasoning summary"""
    return quantum_think.get_reasoning_summary(reasoning_chain)

def get_quantum_health():
    """Get QuantumThink health metrics"""
    return quantum_think.get_quantum_stats()

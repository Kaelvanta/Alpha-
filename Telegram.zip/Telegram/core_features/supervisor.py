
import json
import os
import asyncio
import psutil
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from aiogram import Bot
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from memory import log_error
import aiofiles

# Supervisor Configuration
MONITOR_INTERVALS = {
    "system": 60,      # System metrics every 1 minute
    "bot": 30,         # Bot status every 30 seconds  
    "errors": 10,      # Error monitoring every 10 seconds
    "users": 300       # User activity every 5 minutes
}

ALERT_THRESHOLDS = {
    "cpu_percent": 85,
    "memory_percent": 90,
    "disk_percent": 95,
    "error_count": 5,
    "response_time": 30
}

class AlwaysOnSupervisor:
    def __init__(self, bot: Bot = None):
        self.bot = bot
        self.monitoring = False
        self.metrics_file = "data/supervisor_metrics.json"
        self.alerts_file = "data/supervisor_alerts.json"
        self.owner_id = 7976711112  # Kael Vanta's Telegram ID
        self.ensure_files()
        
    def ensure_files(self):
        """Ensure supervisor data files exist"""
        os.makedirs("data", exist_ok=True)
        for file_path in [self.metrics_file, self.alerts_file]:
            if not os.path.exists(file_path):
                with open(file_path, "w") as f:
                    json.dump({}, f, indent=2)
    
    async def start_monitoring(self):
        """Start the Always-On monitoring system"""
        if self.monitoring:
            return
            
        self.monitoring = True
        log_error("SUPERVISOR: Always-On monitoring started")
        
        # Start monitoring tasks
        asyncio.create_task(self.monitor_system())
        asyncio.create_task(self.monitor_bot_health())
        asyncio.create_task(self.monitor_errors())
        asyncio.create_task(self.monitor_users())
    
    async def stop_monitoring(self):
        """Stop the monitoring system"""
        self.monitoring = False
        log_error("SUPERVISOR: Always-On monitoring stopped")
    
    async def monitor_system(self):
        """Monitor system resources"""
        while self.monitoring:
            try:
                # Get system metrics
                cpu_percent = psutil.cpu_percent(interval=1)
                memory = psutil.virtual_memory()
                disk = psutil.disk_usage('/')
                
                metrics = {
                    "timestamp": datetime.now().isoformat(),
                    "cpu_percent": cpu_percent,
                    "memory_percent": memory.percent,
                    "disk_percent": disk.percent,
                    "memory_available": memory.available // (1024**2),  # MB
                    "disk_free": disk.free // (1024**3)  # GB
                }
                
                await self.save_metrics("system", metrics)
                
                # Check thresholds and alert
                await self.check_system_alerts(metrics)
                
                await asyncio.sleep(MONITOR_INTERVALS["system"])
                
            except Exception as e:
                log_error(f"System monitoring error: {e}")
                await asyncio.sleep(60)
    
    async def monitor_bot_health(self):
        """Monitor bot health and responsiveness"""
        while self.monitoring:
            try:
                start_time = datetime.now()
                
                # Test bot responsiveness
                if self.bot:
                    try:
                        await self.bot.get_me()
                        bot_responsive = True
                        response_time = (datetime.now() - start_time).total_seconds()
                    except:
                        bot_responsive = False
                        response_time = 999
                else:
                    bot_responsive = False
                    response_time = 999
                
                metrics = {
                    "timestamp": datetime.now().isoformat(),
                    "bot_responsive": bot_responsive,
                    "response_time": response_time,
                    "uptime": self.get_uptime()
                }
                
                await self.save_metrics("bot", metrics)
                
                # Alert if bot is unresponsive
                if not bot_responsive or response_time > ALERT_THRESHOLDS["response_time"]:
                    await self.send_alert("Bot Health Alert", 
                                        f"Bot unresponsive or slow (Response time: {response_time}s)")
                
                await asyncio.sleep(MONITOR_INTERVALS["bot"])
                
            except Exception as e:
                log_error(f"Bot monitoring error: {e}")
                await asyncio.sleep(60)
    
    async def monitor_errors(self):
        """Monitor error rates and patterns"""
        error_counts = {}
        
        while self.monitoring:
            try:
                # Read recent error logs
                if os.path.exists("error.log"):
                    recent_errors = await self.count_recent_errors()
                    
                    if recent_errors > ALERT_THRESHOLDS["error_count"]:
                        await self.send_alert("High Error Rate", 
                                            f"{recent_errors} errors in last 10 minutes")
                
                await asyncio.sleep(MONITOR_INTERVALS["errors"])
                
            except Exception as e:
                log_error(f"Error monitoring error: {e}")
                await asyncio.sleep(60)
    
    async def monitor_users(self):
        """Monitor user activity and engagement"""
        while self.monitoring:
            try:
                if os.path.exists("data/memory.json"):
                    with open("data/memory.json", "r") as f:
                        memory_data = json.load(f)
                    
                    # Count active users
                    now = datetime.now()
                    active_users = 0
                    total_users = len(memory_data)
                    
                    for user_data in memory_data.values():
                        if "messages" in user_data and user_data["messages"]:
                            # Check if user was active in last 24h
                            last_msg = user_data["messages"][-1]
                            if "timestamp" in last_msg:
                                try:
                                    last_time = datetime.fromisoformat(last_msg["timestamp"])
                                    if (now - last_time).days == 0:
                                        active_users += 1
                                except:
                                    pass
                    
                    metrics = {
                        "timestamp": datetime.now().isoformat(),
                        "total_users": total_users,
                        "active_users": active_users,
                        "engagement_rate": (active_users / max(total_users, 1)) * 100
                    }
                    
                    await self.save_metrics("users", metrics)
                
                await asyncio.sleep(MONITOR_INTERVALS["users"])
                
            except Exception as e:
                log_error(f"User monitoring error: {e}")
                await asyncio.sleep(300)
    
    async def save_metrics(self, category: str, metrics: Dict):
        """Save metrics to file"""
        try:
            async with aiofiles.open(self.metrics_file, "r") as f:
                data = json.loads(await f.read())
            
            if category not in data:
                data[category] = []
            
            data[category].append(metrics)
            
            # Keep only last 1000 entries per category
            if len(data[category]) > 1000:
                data[category] = data[category][-1000:]
            
            async with aiofiles.open(self.metrics_file, "w") as f:
                await f.write(json.dumps(data, indent=2))
                
        except Exception as e:
            log_error(f"Save metrics error: {e}")
    
    async def check_system_alerts(self, metrics: Dict):
        """Check if system metrics exceed alert thresholds"""
        alerts = []
        
        if metrics["cpu_percent"] > ALERT_THRESHOLDS["cpu_percent"]:
            alerts.append(f"High CPU: {metrics['cpu_percent']:.1f}%")
        
        if metrics["memory_percent"] > ALERT_THRESHOLDS["memory_percent"]:
            alerts.append(f"High Memory: {metrics['memory_percent']:.1f}%")
        
        if metrics["disk_percent"] > ALERT_THRESHOLDS["disk_percent"]:
            alerts.append(f"High Disk: {metrics['disk_percent']:.1f}%")
        
        if alerts:
            await self.send_alert("System Resource Alert", " | ".join(alerts))
    
    async def send_alert(self, title: str, message: str):
        """Send alert to bot owner"""
        try:
            if self.bot and self.owner_id:
                alert_msg = f"🚨 <b>{title}</b>\n\n{message}\n\nTime: {datetime.now().strftime('%H:%M:%S')}\n\n— Always-On Supervisor"
                await self.bot.send_message(self.owner_id, alert_msg)
            
            # Log alert
            log_error(f"SUPERVISOR ALERT: {title} - {message}")
            
            # Save alert to file
            alert_data = {
                "timestamp": datetime.now().isoformat(),
                "title": title,
                "message": message
            }
            await self.save_alert(alert_data)
            
        except Exception as e:
            log_error(f"Send alert error: {e}")
    
    async def save_alert(self, alert_data: Dict):
        """Save alert to alerts file"""
        try:
            async with aiofiles.open(self.alerts_file, "r") as f:
                alerts = json.loads(await f.read())
            
            if "alerts" not in alerts:
                alerts["alerts"] = []
            
            alerts["alerts"].append(alert_data)
            
            # Keep only last 100 alerts
            if len(alerts["alerts"]) > 100:
                alerts["alerts"] = alerts["alerts"][-100:]
            
            async with aiofiles.open(self.alerts_file, "w") as f:
                await f.write(json.dumps(alerts, indent=2))
                
        except Exception as e:
            log_error(f"Save alert error: {e}")
    
    def get_uptime(self) -> float:
        """Get system uptime in hours"""
        try:
            return psutil.boot_time()
        except:
            return 0
    
    async def count_recent_errors(self) -> int:
        """Count errors in the last 10 minutes"""
        try:
            if not os.path.exists("error.log"):
                return 0
            
            ten_minutes_ago = datetime.now() - timedelta(minutes=10)
            error_count = 0
            
            with open("error.log", "r") as f:
                for line in f.readlines()[-100:]:  # Check last 100 lines
                    try:
                        if ten_minutes_ago.isoformat()[:16] in line:
                            error_count += 1
                    except:
                        continue
            
            return error_count
            
        except Exception as e:
            log_error(f"Count errors error: {e}")
            return 0

# Global supervisor instance
supervisor = AlwaysOnSupervisor()

async def supervisor_main(message: Message):
    """Main Supervisor interface"""
    try:
        # Get current metrics
        system_status = await get_system_status()
        
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📊 Live Dashboard", callback_data="sup_dashboard")],
            [InlineKeyboardButton(text="🚨 Recent Alerts", callback_data="sup_alerts")],
            [InlineKeyboardButton(text="⚙️ Configure Alerts", callback_data="sup_config")],
            [InlineKeyboardButton(text="📈 Performance Report", callback_data="sup_report")]
        ])
        
        await message.answer(
            f"🔍 <b>Always-On Supervisor</b> — 24/7 System Monitor\n\n"
            f"📊 <b>System Status:</b> {system_status['status']}\n"
            f"🖥️ <b>CPU:</b> {system_status['cpu']:.1f}%\n"
            f"💾 <b>Memory:</b> {system_status['memory']:.1f}%\n"
            f"💿 <b>Disk:</b> {system_status['disk']:.1f}%\n"
            f"⏱️ <b>Bot Response:</b> {system_status['response_time']:.1f}s\n\n"
            f"<b>Monitoring Features:</b>\n"
            f"• Real-time system metrics\n"
            f"• Automated alerts & notifications\n"
            f"• Error pattern detection\n"
            f"• Performance optimization\n\n"
            f"— Kael Vanta ®️",
            reply_markup=keyboard
        )
        
    except Exception as e:
        log_error(f"Supervisor main error: {e}")
        await message.answer("⚠️ Supervisor temporarily offline.\n\n— Kael Vanta ®️")

async def get_system_status() -> Dict[str, Any]:
    """Get current system status"""
    try:
        cpu = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        # Determine overall status
        status = "🟢 Healthy"
        if cpu > 80 or memory.percent > 85 or disk.percent > 90:
            status = "🟡 Warning"
        if cpu > 90 or memory.percent > 95 or disk.percent > 98:
            status = "🔴 Critical"
        
        return {
            "status": status,
            "cpu": cpu,
            "memory": memory.percent,
            "disk": disk.percent,
            "response_time": 0.5  # Placeholder
        }
        
    except Exception as e:
        log_error(f"Get system status error: {e}")
        return {
            "status": "❌ Error",
            "cpu": 0,
            "memory": 0,
            "disk": 0,
            "response_time": 999
        }

async def supervisor_health_check() -> Dict[str, Any]:
    """Health check for Supervisor system"""
    try:
        metrics_exist = os.path.exists(supervisor.metrics_file)
        alerts_exist = os.path.exists(supervisor.alerts_file)
        
        return {
            "status": "healthy" if supervisor.monitoring else "stopped",
            "monitoring": supervisor.monitoring,
            "metrics_file_exists": metrics_exist,
            "alerts_file_exists": alerts_exist,
            "intervals": MONITOR_INTERVALS,
            "thresholds": ALERT_THRESHOLDS,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        log_error(f"Supervisor health check error: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }

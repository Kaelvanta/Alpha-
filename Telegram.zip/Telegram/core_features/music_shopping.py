
import requests
import random
from aiogram.types import Message
from core_features.ai_engine import get_ai_response
from memory import log_error
from keys import API_KEYS

# Feature 18: Music Finder & Lyrics Fetcher
async def find_music(message: Message):
    """Find music and lyrics"""
    try:
        text_parts = message.text.split(None, 1)
        if len(text_parts) < 2:
            await message.answer("🎵 <b>Music Finder</b>\n\n<b>Usage:</b>\n/music Bohemian Rhapsody\n/lyrics Shape of You\n/spotify Drake God's Plan\n\n— Kael Vanta ®️")
            return
            
        query = text_parts[1]
        command = message.text.split()[0].lower()
        
        if command == "/lyrics":
            # Use AI to get lyrics (free alternative)
            prompt = f"Provide the lyrics for the song: {query}. If you don't know the exact lyrics, say you cannot find them."
            
            api_items = list(API_KEYS.items())
            if api_items:
                model, key = random.choice(api_items)
                lyrics = await get_ai_response(prompt, model, key, message.from_user.id)
                await message.answer(f"🎵 <b>Lyrics: {query}</b>\n\n{lyrics}\n\n— Kael Vanta ®️")
            else:
                await message.answer("⚠️ Lyrics service temporarily unavailable.\n\n— Kael Vanta ®️")
                
        else:
            # Music search/info
            prompt = f"Provide information about the song or artist: {query}. Include details like artist, album, year, genre, and interesting facts."
            
            api_items = list(API_KEYS.items())
            if api_items:
                model, key = random.choice(api_items)
                music_info = await get_ai_response(prompt, model, key, message.from_user.id)
                await message.answer(f"🎵 <b>Music Info: {query}</b>\n\n{music_info}\n\n— Kael Vanta ®️")
            else:
                await message.answer("⚠️ Music service temporarily unavailable.\n\n— Kael Vanta ®️")
                
    except Exception as e:
        log_error(f"Music finder error: {e}")
        await message.answer("⚠️ Music search failed. Try again!\n\n— Kael Vanta ®️")

# Feature 19: AI Shopping Assistant
async def shopping_assistant(message: Message):
    """Help users find deals and product recommendations"""
    try:
        text_parts = message.text.split(None, 1)
        if len(text_parts) < 2:
            await message.answer("🛒 <b>AI Shopping Assistant</b>\n\n<b>Usage:</b>\n/shop best budget smartphone\n/deals gaming laptop under $1000\n/compare iPhone vs Samsung\n\n— Kael Vanta ®️")
            return
            
        query = text_parts[1]
        command = message.text.split()[0].lower()
        
        if command == "/deals":
            prompt = f"Help find deals and recommendations for: {query}. Provide specific product suggestions, price ranges, where to buy, and what to look for. Include current market trends."
        elif command == "/compare":
            prompt = f"Compare these products/options: {query}. Provide pros, cons, and recommendations based on different use cases and budgets."
        else:
            prompt = f"Provide shopping advice and recommendations for: {query}. Include product suggestions, price ranges, key features to consider, and best places to buy."
            
        api_items = list(API_KEYS.items())
        if not api_items:
            await message.answer("⚠️ Shopping assistant temporarily unavailable.\n\n— Kael Vanta ®️")
            return
            
        model, key = random.choice(api_items)
        shopping_advice = await get_ai_response(prompt, model, key, message.from_user.id)
        
        await message.answer(f"🛒 <b>Shopping Assistant</b>\n\n{shopping_advice}\n\n<i>💡 Always compare prices and read reviews!</i>\n\n— Kael Vanta ®️")
        
    except Exception as e:
        log_error(f"Shopping assistant error: {e}")
        await message.answer("⚠️ Shopping search failed. Try again!\n\n— Kael Vanta ®️")

# Feature 6: Offline Knowledge Pack (Simple implementation)
OFFLINE_KNOWLEDGE = {
    "facts": [
        "Octopuses have three hearts and blue blood",
        "Bananas are berries, but strawberries aren't", 
        "A day on Venus is longer than its year",
        "Sharks existed before trees",
        "Wombat poop is cube-shaped",
        "Your tongue print is as unique as your fingerprint",
        "The human brain runs on about 20 watts of power",
        "There are more possible chess games than atoms in the observable universe"
    ],
    "quotes": [
        "The best time to plant a tree was 20 years ago. The second best time is now.",
        "Success is not final, failure is not fatal: it is the courage to continue that counts.",
        "The only way to do great work is to love what you do.",
        "Innovation distinguishes between a leader and a follower."
    ],
    "tips": [
        "Use the 2-minute rule: if something takes less than 2 minutes, do it now",
        "Practice the 20-20-20 rule for eye health: every 20 minutes, look at something 20 feet away for 20 seconds",
        "Drink water first thing in the morning to kickstart your metabolism",
        "Use airplane mode to charge your phone faster"
    ]
}

async def offline_knowledge(message: Message):
    """Access offline knowledge when internet is limited"""
    try:
        text_parts = message.text.split()
        if len(text_parts) < 2:
            await message.answer("📚 <b>Offline Knowledge Pack</b>\n\n<b>Available:</b>\n/offline facts\n/offline quotes\n/offline tips\n/offline random\n\n— Kael Vanta ®️")
            return
            
        category = text_parts[1].lower()
        
        if category == "random":
            all_items = []
            for cat, items in OFFLINE_KNOWLEDGE.items():
                all_items.extend([(cat, item) for item in items])
            cat, item = random.choice(all_items)
            await message.answer(f"📚 <b>Random {cat.title()}</b>\n\n{item}\n\n— Kael Vanta ®️")
        elif category in OFFLINE_KNOWLEDGE:
            item = random.choice(OFFLINE_KNOWLEDGE[category])
            await message.answer(f"📚 <b>{category.title()}</b>\n\n{item}\n\n— Kael Vanta ®️")
        else:
            await message.answer("❌ Category not found. Use: facts, quotes, tips, or random\n\n— Kael Vanta ®️")
            
    except Exception as e:
        log_error(f"Offline knowledge error: {e}")
        await message.answer("⚠️ Offline knowledge access failed.\n\n— Kael Vanta ®️")

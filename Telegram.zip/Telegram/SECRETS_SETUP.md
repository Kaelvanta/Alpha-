
# 🔐 COREVANTA AI - Secrets Configuration

## Required Secrets in Replit

To properly configure COREVANTA AI, add these secrets in the **Tools > Secrets** panel:

### Essential Secrets

1. **BOT_TOKEN** (Required)
   - Your Telegram Bot Token from @BotFather
   - Example: `7234567890:AAHdqTcvbXRxqSaLMwAHy6_FghJIkl-9nk8`

2. **CHATANYWHERE_API_KEY** (Primary AI API)
   - OpenAI-compatible API key from ChatAnywhere
   - Get from: https://api.chatanywhere.org
   - Example: `sk-...` (starts with sk-)

3. **OPENROUTER_API_KEY** (Backup AI API - Optional)
   - OpenRouter API key for fallback
   - Get from: https://openrouter.ai
   - Example: `sk-or-v1-...`

## Setup Instructions

1. **Open Replit Secrets**:
   - Go to Tools > Secrets (or click + and search "Secrets")

2. **Add Each Secret**:
   - Click "+ New Secret"
   - Enter the key name exactly as shown above
   - Paste your API key/token value
   - Click "Add Secret"

3. **Verify Configuration**:
   - Run the bot
   - Check startup logs for "Secrets configured: 3/3"
   - Look for any warning messages

## API Strategy

- **Primary**: ChatAnywhere (gpt-3.5-turbo)
- **Secondary**: OpenRouter (various free models)
- **Failover**: Automatic switching on errors (401, 403, 429, 5xx)
- **Health Check**: Tracks API failures and rotates automatically

## Security Notes

- ✅ Secrets are encrypted with AES-256
- ✅ Never commit secrets to code
- ✅ Environment variables only
- ⚠️ Collaborators with Owner role can see secret values

## Troubleshooting

If you see "No API keys available":
1. Check Secrets configuration
2. Verify key formats are correct
3. Test with `/helpme` command
4. Check error logs in console

---
*COREVANTA AI - Kael Vanta Syndicate ®️*

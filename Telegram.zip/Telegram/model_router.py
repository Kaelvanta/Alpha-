
# model_router.py
import os
import time
import json
from typing import Dict, Any, List, Optional, Tuple
import requests

# Optional import for Azure AI Inference (Grok via GitHub Models Gateway)
try:
    from azure.ai.inference import ChatCompletionsClient
    from azure.ai.inference.models import SystemMessage, UserMessage
    from azure.core.credentials import AzureKeyCredential
    _AZURE_AVAILABLE = True
except Exception:
    _AZURE_AVAILABLE = False


class TTLCache:
    """Simple TTL cache to avoid repeated identical calls."""
    def __init__(self, ttl_seconds: int = 120, max_items: int = 128):
        self.ttl = ttl_seconds
        self.max = max_items
        self._store: Dict[Tuple[str, str, str], Tuple[float, str]] = {}

    def get(self, key: Tuple[str, str, str]) -> Optional[str]:
        now = time.time()
        item = self._store.get(key)
        if not item:
            return None
        ts, val = item
        if now - ts > self.ttl:
            self._store.pop(key, None)
            return None
        return val

    def set(self, key: Tuple[str, str, str], value: str) -> None:
        if len(self._store) >= self.max:
            # drop oldest
            oldest_key = min(self._store.items(), key=lambda x: x[1][0])[0]
            self._store.pop(oldest_key, None)
        self._store[key] = (time.time(), value)


class ModelRouter:
    """
    CoreVanta AI multi-model router.
    - Each entry describes provider, model string, base_url, env key, strengths, and an optional fallback chain.
    - Providers supported: 'azure_inference', 'openrouter', 'openai_proxy'
    """
    def __init__(self):
        # Nickname → config
        # Adjust model strings as needed; these are common public identifiers.
        self.MODELS: Dict[str, Dict[str, Any]] = {
            # Code generator / hacker's forge
            "alphacode": {
                "provider": "openrouter",
                "model": "deepseek/deepseek-coder",
                "env_key": "OPENROUTER_API_KEY",
                "base_url": "https://openrouter.ai/api/v1/chat/completions",
                "strengths": "Code generation, debugging, API integrations.",
                "fallback_chain": ["meta_ace", "deep_keal"]
            },
            # Deep reasoning / analysis
            "deep_keal": {
                "provider": "openrouter",
                "model": "deepseek/deepseek-chat",
                "env_key": "OPENROUTER_API_KEY",
                "base_url": "https://openrouter.ai/api/v1/chat/completions",
                "strengths": "Long-form reasoning, breakdowns, planning.",
                "fallback_chain": ["alpha_vault", "chatmoney"]
            },
            # Meta LLaMA knowledge vault
            "alpha_vault": {
                "provider": "openrouter",
                "model": "meta-llama/llama-3-70b-instruct",
                "env_key": "OPENROUTER_API_KEY",
                "base_url": "https://openrouter.ai/api/v1/chat/completions",
                "strengths": "Explanations, summaries, info-dense outputs.",
                "fallback_chain": ["deep_keal", "alphacode"]
            },
            # Azure Inference → Grok (via GitHub Models Gateway)
            "chatmoney": {
                "provider": "azure_inference",
                "endpoint": "https://models.github.ai/inference",
                "model": "xai/grok-3",
                "env_key": "GITHUB_TOKEN",
                "strengths": "Witty, fast, sharp; great for punchy replies.",
                "fallback_chain": ["deep_keal", "meta_ace"]
            },
            # OpenAI-compatible proxy (e.g., ChatAnywhere)
            "meta_ace": {
                "provider": "openai_proxy",
                "model": "gpt-3.5-turbo",  # change to your supported model on the proxy
                "env_key": "OPENAI_PROXY_KEY",
                "base_url": "https://api.chatanywhere.org/v1/chat/completions",
                "strengths": "Versatile research/writing; strategist core.",
                "fallback_chain": ["alpha_vault", "alphacode"]
            },
            # Business / planning (mapped to OpenRouter Microsoft phi as example)
            "elephant_money": {
                "provider": "openrouter",
                "model": "microsoft/phi-3-mini-128k-instruct",
                "env_key": "OPENROUTER_API_KEY",
                "base_url": "https://openrouter.ai/api/v1/chat/completions",
                "strengths": "Productivity, tables, structured plans.",
                "fallback_chain": ["meta_ace", "alpha_vault"]
            },
        }

        self.cache = TTLCache(ttl_seconds=120, max_items=128)

    def list_models(self) -> List[Dict[str, str]]:
        return [{"nickname": k, "provider": v.get("provider"), "model": v.get("model", ""),
                 "strengths": v.get("strengths", "")}
                for k, v in self.MODELS.items()]

    def model_info(self, nickname: str) -> Dict[str, Any]:
        cfg = self.MODELS.get(nickname)
        return cfg or {}

    def _azure_inference_call(self, cfg: Dict[str, Any], system_prompt: str, user_text: str) -> Optional[str]:
        if not _AZURE_AVAILABLE:
            return None
        token = os.getenv(cfg["env_key"], "")
        if not token:
            return None
        try:
            client = ChatCompletionsClient(
                endpoint=cfg["endpoint"],
                credential=AzureKeyCredential(token),
            )
            resp = client.complete(
                messages=[SystemMessage(system_prompt), UserMessage(user_text)],
                temperature=0.8,
                top_p=1.0,
                model=cfg["model"],
            )
            return resp.choices[0].message.content if resp and resp.choices else None
        except Exception:
            return None

    def _openrouter_call(self, cfg: Dict[str, Any], system_prompt: str, user_text: str) -> Optional[str]:
        key = os.getenv(cfg["env_key"], "")
        if not key:
            return None
        try:
            payload = {
                "model": cfg["model"],
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_text},
                ],
            }
            headers = {
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
            }
            r = requests.post(cfg["base_url"], headers=headers, json=payload, timeout=30)
            if r.status_code == 200:
                data = r.json()
                content = data.get("choices", [{}])[0].get("message", {}).get("content")
                return content
            return None
        except Exception:
            return None

    def _openai_proxy_call(self, cfg: Dict[str, Any], system_prompt: str, user_text: str) -> Optional[str]:
        key = os.getenv(cfg["env_key"], "")
        if not key:
            return None
        try:
            url = cfg["base_url"]  # OpenAI-compatible /chat/completions
            payload = {
                "model": cfg["model"],
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_text},
                ],
            }
            headers = {
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
            }
            r = requests.post(url, headers=headers, json=payload, timeout=30)
            if r.status_code == 200:
                data = r.json()
                content = data.get("choices", [{}])[0].get("message", {}).get("content")
                return content
            return None
        except Exception:
            return None

    def ask(self, nickname: str, user_text: str, system_prompt: str) -> str:
        # Cache first
        key = (nickname, system_prompt[:60], user_text[:120])
        cached = self.cache.get(key)
        if cached:
            return cached

        cfg = self.MODELS.get(nickname)
        if not cfg:
            return f"⚠️ Unknown model nickname: {nickname}"

        provider = cfg.get("provider")
        result = None

        if provider == "azure_inference":
            result = self._azure_inference_call(cfg, system_prompt, user_text)
        elif provider == "openrouter":
            result = self._openrouter_call(cfg, system_prompt, user_text)
        elif provider == "openai_proxy":
            result = self._openai_proxy_call(cfg, system_prompt, user_text)

        # Fallback chain if needed
        if not result:
            for fb in cfg.get("fallback_chain", []):
                fb_cfg = self.MODELS.get(fb)
                if not fb_cfg:
                    continue
                fb_provider = fb_cfg.get("provider")
                if fb_provider == "azure_inference":
                    result = self._azure_inference_call(fb_cfg, system_prompt, user_text)
                elif fb_provider == "openrouter":
                    result = self._openrouter_call(fb_cfg, system_prompt, user_text)
                elif fb_provider == "openai_proxy":
                    result = self._openai_proxy_call(fb_cfg, system_prompt, user_text)
                if result:
                    result = f"(fallback → {fb})\n{result}"
                    break

        if not result:
            result = "⚠️ All engines busy. Try again shortly."

        self.cache.set(key, result)
        return result

    def autoroute(self, user_text: str) -> str:
        t = user_text.lower()
        if any(k in t for k in ["```", "code", "bug", "debug", "function", "class"]):
            return "alphacode"
        if any(k in t for k in ["plan", "roadmap", "kpi", "table", "excel", "budget", "business"]):
            return "elephant_money"
        if any(k in t for k in ["joke", "meme", "flirt", "roast", "comeback"]):
            return "chatmoney"
        if any(k in t for k in ["explain", "summarize", "what is", "define", "overview"]):
            return "alpha_vault"
        return "deep_keal"

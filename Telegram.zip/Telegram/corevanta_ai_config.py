
# corevanta_ai_config.py

AI_MODELS = [
    {
        "name": "meta-llama/llama-3.2-11b-vision-instruct:free",
        "key": "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",
    },
    {
        "name": "google/gemini-2.0-flash-exp:free",
        "key": "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",
    },
    {
        "name": "deepseek/deepseek-chat-v3-0324:free",
        "key": "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",
    },
    {
        "name": "microsoft/mai-ds-r1:free",
        "key": "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",
    }
]

import random, requests, os

def call_ai(prompt):
    # Randomize or cycle models
    model = random.choice(AI_MODELS)

    headers = {
        "Authorization": f"Bearer {model['key']}",
        "Content-Type": "application/json",
    }

    data = {
        "model": model["name"],
        "messages": [{"role": "user", "content": prompt}],
    }

    try:
        r = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers=headers,
            json=data,
            timeout=60,
        )
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]
    except Exception as e:
        return f"⚠️ Model {model['name']} failed: {str(e)}"

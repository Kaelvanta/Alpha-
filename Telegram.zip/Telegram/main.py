import logging
import asyncio
import random
import os
import json
import time
from datetime import datetime

from aiogram import Bot, Dispatcher, types
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties
from aiogram.filters import Command
from aiogram.types import Message, ContentType
from core_features.ai_engine import get_ai_response
from core_features.commands import handle_custom_commands, handle_image
from memory import add_message, log_error, load_memory
from keys import API_KEYS
from keep_alive import keep_alive
# Import bio functionality
from core_features.bio_prefs import get_user_prefs, build_personality_prompt
# Import new advanced features
from core_features.advanced_features import (
    switch_personality, send_daily_hack, translate_text, create_content,
    handle_code, make_prediction, emotional_support, create_custom_command,
    execute_custom_command, roast_or_compliment, interactive_story
)
from core_features.games_challenges import (
    memory_profile, daily_challenge, submit_challenge_answer, show_leaderboard
)
from core_features.music_shopping import (
    find_music, shopping_assistant, offline_knowledge
)
from core_features.voice_and_auto import (
    handle_voice_message, text_to_voice, setup_auto_reply,
    should_auto_reply, generate_auto_reply, generate_meme
)
# New imports for news and research
import wikipedia
import feedparser
import aiohttp
import requests
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Import model router
from model_router import ModelRouter

# Import new Groq router and search provider
try:
    from groq_router import DEFAULT_ROUTER as GROQ_ROUTER
    from search_provider import search_provider
    GROQ_AVAILABLE = True
except ImportError:
    GROQ_AVAILABLE = False
    print("⚠️ Groq router not available")

# GNews API Key
GNEWS_API_KEY = os.getenv("GNEWS_API_KEY")
if not GNEWS_API_KEY:
    print("❌ CRITICAL: GNEWS_API_KEY environment variable not set!")
    print("Add your GNews API key to the .env file.")
    # Consider exiting or using a fallback if critical
    # exit(1)

# Bot token from environment variable only (secure)
BOT_TOKEN = os.getenv("BOT_TOKEN")
if not BOT_TOKEN:
    print("❌ CRITICAL: BOT_TOKEN environment variable not set!")
    print("Add your bot token to Secrets in the Tools panel.")
    exit(1)

# Check if running in deployment
IS_DEPLOYMENT = os.getenv("REPLIT_DEPLOYMENT") == "1"

# Initialize bot and dispatcher
bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()

# Initialize model router
MODEL_ROUTER = ModelRouter()
DEFAULT_MODEL_PER_USER = {}  # in-memory; optional persistence later

SYSTEM_PROMPT = (
    "You are CoreVanta AI — futuristic, logical, sharp, Gen-Z witty. "
    "Be clear, helpful, and step-by-step when needed."
)

# Error tracking
error_count = 0
last_error_time = None

async def log_bot_error(error_msg, user_id=None):
    """Enhanced error logging with notifications"""
    global error_count, last_error_time

    timestamp = datetime.now()
    log_error(f"BOT ERROR: {error_msg} | User: {user_id}")

    error_count += 1
    last_error_time = timestamp

    # Critical error detection (3+ errors in 5 minutes)
    if error_count >= 3:
        critical_msg = f"CRITICAL: {error_count} errors detected. Last: {error_msg}"
        log_error(critical_msg)

        # Notify owner (Telegram ID: 7976711112)
        try:
            await bot.send_message(
                chat_id=7976711112,
                text=f"🚨 <b>COREVANTA AI ALERT</b>\n\n{critical_msg}\n\nTime: {timestamp}\n\n— System Monitor"
            )
        except:
            pass  # Silent fail for notifications

        error_count = 0  # Reset counter

def log_model_reply(user_id: int, nickname: str, prompt: str, reply: str):
    """Log model interactions to JSONL file"""
    try:
        import os
        if not os.path.exists("logs"):
            os.makedirs("logs")
        
        with open("logs/model_replies.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps({
                "ts": time.time(),
                "user_id": user_id,
                "model": nickname,
                "prompt": prompt[:5000],
                "reply": reply[:5000]
            }) + "\n")
    except Exception:
        pass  # never crash on logging

@dp.message(Command(commands=["start"]))
async def cmd_start(message: Message):
    """Enhanced start command with user tracking"""
    try:
        user_id = message.from_user.id
        user_name = message.from_user.first_name or "User"

        add_message(user_id, "system", "User started bot")

        welcome_msg = f"""🔥 <b>CORE VANTA AI</b> is live! — Kael Vanta Syndicate

🧠 Futuristic hacker-genius intelligence with logical reasoning

⚡ <b>Enhanced Features:</b>
• Multi-API strategy with failover
• Enhanced research with source citations
• Structured summarization and analysis
• Advanced code generation & debugging

Use /help to see what I can do, {user_name}!

— Kael Vanta Syndicate ®️"""

        await message.answer(welcome_msg)

    except Exception as e:
        await log_bot_error(f"Start command error: {e}", message.from_user.id)
        await message.answer("🔥 COREVANTA_AI is live! Use /help for commands.\n\n— Kael Vanta ®️")

@dp.message(Command(commands=["health", "status"]))
async def cmd_health(message: Message):
    """Check system health and API status"""
    try:
        from keys import check_secrets_configured, api_manager

        secrets_status = check_secrets_configured()

        # Count configured secrets
        configured = sum(1 for status in secrets_status.values() if status)
        total_secrets = len(secrets_status)

        # Check API health
        api_health = []
        for api_name in api_manager.preference_order:
            api_config = api_manager.apis[api_name]
            is_healthy = api_manager._is_api_healthy(api_name)
            has_key = bool(api_config["key"])

            status = "🟢 Online" if (has_key and is_healthy) else "🔴 Offline"
            if has_key and not is_healthy:
                status = "🟡 Degraded"
            elif not has_key:
                status = "⚫ No Key"

            api_health.append(f"  • {api_name.title()}: {status}")

        health_msg = f"""🔥 <b>COREVANTA AI - System Health</b>

<b>🔐 Secrets Status:</b> {configured}/{total_secrets} configured
  • BOT_TOKEN: {"✅" if secrets_status["BOT_TOKEN"] else "❌"}
  • CHATANYWHERE_API_KEY: {"✅" if secrets_status["CHATANYWHERE_API_KEY"] else "❌"}
  • OPENROUTER_API_KEY: {"✅" if secrets_status["OPENROUTER_API_KEY"] else "❌"}

<b>🤖 API Health:</b>
{chr(10).join(api_health)}

<b>📊 Legacy APIs:</b> {len(API_KEYS)} models available
<b>🔄 Uptime:</b> 24/7 on Replit + UptimeRobot

<i>All systems operational!</i>

— Kael Vanta Syndicate ®️"""

        await message.answer(health_msg)

    except Exception as e:
        await log_bot_error(f"Health command error: {e}", message.from_user.id)
        await message.answer("⚠️ Health check failed. System monitor notified.\n\n— Kael Vanta ®️")

@dp.message(Command(commands=["help"]))
async def cmd_help(message: Message):
    """Direct help command with error handling"""
    try:
        help_text = """🧠 <b>COREVANTA_AI Commands</b> — Kael Vanta Style 🔥

<b>🎯 Alpha Commands:</b>
/alphacode — Savage mindset quotes
/flirt — Elite pickup lines
/motivate — Power motivation boost
/roast — Savage roast mode
/compliment — Elite compliments

<b>🤖 AI Features:</b>
/personality [mode] — Switch AI personality
/research [topic] — AI + web research
/search [topic] — Enhanced search engine
/news [topic] — Latest news & headlines
/summarize [text] — Smart summaries
/create [type] [topic] — Content creator
/predict [topic] — Prediction mode
/support [concern] — Emotional support

<b>💻 Code & Tech:</b>
/code [request] — Code generator
/debug [code] — Code debugger
/explain [code] — Code explainer
/translate [lang] [text] — Language translator
/deepseek [query] — Advanced reasoning engine
/think [query] — Alias for DeepSeek reasoning

<b>🎮 Fun & Games:</b>
/challenge — Daily challenges
/story [text] — Interactive stories
/meme [topic] — Meme generator
/music [song] — Music finder
/lyrics [song] — Lyrics search

<b>🛒 Lifestyle:</b>
/shop [item] — Shopping assistant
/deals [item] — Find deals
/dailyhack — Life hacks
/offline [category] — Offline knowledge

<b>⚙️ Personal:</b>
/memory — Profile management
/personaforge — Advanced persona system
/createpersona — New persona wizard
/customcmd [name] [action] — Create commands
/autoreply [on/off] — Auto-reply mode
/bio — Customize experience

<b>📰 GNews:</b>
/news [topic] — Get news on a topic
/gnews [topic] — Get news on a topic
/headlines — Get top headlines
/topnews — Get top headlines

<b>🤖 AI Router:</b>
/models — List AI cores
/modelinfo [nickname] — Core details
/switchmodel [nickname] — Set default core
/ask [nickname|auto] [prompt] — Direct model query

<b>🏈 Sports Engine:</b>
/sports [team|league] — Team/league snapshot
/fixtures [league|team] — Upcoming fixtures  
/next [team] — Next scheduled match
/score [match_id] — Live/final scores
/standings [league] — League table
/football [args] — Football alias

<b>💬 Chat:</b>
Talk naturally — I auto-detect commands and remember context!

— Powered by Kael Vanta ®️"""
        await message.answer(help_text)
    except Exception as e:
        await log_bot_error(f"Help command error: {e}", message.from_user.id)
        await message.answer("⚠️ Help temporarily unavailable. Basic commands: /alphacode /flirt /motivate\n\n— Kael Vanta ®️")

# Individual command handlers for better reliability
@dp.message(Command(commands=["alphacode"]))
async def cmd_alphacode(message: Message):
    """Alpha code quotes"""
    try:
        from core_features.commands import send_alpha_quote
        await send_alpha_quote(message)
    except Exception as e:
        await log_bot_error(f"Alpha command error: {e}", message.from_user.id)
        await message.answer("💪 Technical difficulties. We're stronger than this!\n\n— Kael Vanta ®️")

@dp.message(Command(commands=["bio", "customize"]))
async def cmd_bio(message: Message):
    """Bio customization"""
    try:
        from core_features.commands import handle_bio_customize
        await handle_bio_customize(message)
    except Exception as e:
        await log_bot_error(f"Bio command error: {e}", message.from_user.id)
        await message.answer("⚠️ Customization temporarily down.\n\n— Kael Vanta ®️")

@dp.message(Command(commands=["flirt", "motivate", "surpriseme", "checkmodels", "summarize", "research", "getadvice", "makeaplan", "rules"]))
async def handle_other_commands(message: Message):
    """Route other commands to enhanced handler"""
    try:
        await handle_custom_commands(message)
    except Exception as e:
        await log_bot_error(f"Command handler error: {e}", message.from_user.id)
        await message.answer("⚠️ Command temporarily unavailable. Try again or use /help.\n\n— Kael Vanta ®️")

# New command handlers for /news and /research
async def fetch_gnews(query: str, api_key: str):
    """Fetches news from GNews API."""
    try:
        url = f"https://gnews.io/api/v4/search?q={query}&lang=en&token={api_key}&max=3"
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get("articles", [])
                else:
                    return None
    except Exception as e:
        await log_bot_error(f"GNews fetch error: {e}")
        return None

async def fetch_rss_feeds():
    """Fetches top 3 headlines from BBC and Al Jazeera RSS feeds."""
    feeds = {
        "BBC": "http://feeds.bbci.co.uk/news/rss.xml",
        "Al Jazeera": "https://www.aljazeera.com/xml/rss/all.xml"
    }
    results = []
    for source, url in feeds.items():
        try:
            feed = feedparser.parse(url)
            for entry in feed.entries[:3]:
                results.append({
                    "title": entry.title,
                    "link": entry.link,
                    "source": source
                })
        except Exception as e:
            await log_bot_error(f"RSS feed fetch error ({source}): {e}")
    return results

async def format_news_for_telegram(articles):
    """Formats news articles for Telegram message."""
    if not articles:
        return "⚠️ No news found."

    formatted_news = []
    for article in articles:
        title = article.get("title", "No Title")
        
        # Handle both GNews API format and RSS format
        if isinstance(article.get("source"), dict):
            source = article.get("source", {}).get("name", "Unknown Source")
        else:
            source = article.get("source", "Unknown Source")
        
        url = article.get("url", "#")
        published_date = article.get("publishedAt", "Unknown Date")

        formatted_news.append(
            f"📰 <b>{title}</b> ({source})\n"
            f"🔗 <a href='{url}'>Read more</a>\n"
            f"🗓️ {published_date}\n"
            "---"
        )
    return "\n".join(formatted_news)

async def handle_gnews_command(message: Message):
    """Handles the /news command."""
    user_input = message.text.split(maxsplit=1)
    topic = user_input[1] if len(user_input) > 1 else "technology"

    if not GNEWS_API_KEY:
        await message.answer("⚠️ GNews API key is missing. Falling back to RSS feeds.")
        articles = await fetch_rss_feeds()
    else:
        articles = await fetch_gnews(topic, GNEWS_API_KEY)
        if articles is None:
            await message.answer("⚠️ Failed to fetch news from GNews. Falling back to RSS feeds.")
            articles = await fetch_rss_feeds()

    if not articles:
        await message.answer("⚠️ No news found for your query.")
        return

    response_text = await format_news_for_telegram(articles)
    await message.answer(response_text)

async def handle_research_command(message: Message):
    """Handles the /research command with Kael Vanta style"""
    try:
        # Import the enhanced research function
        from core_features.research_enhanced import enhanced_research
        await enhanced_research(message)
        
    except Exception as e:
        await log_bot_error(f"Research error: {e}", message.from_user.id)
        await message.answer("⚠️ Research systems temporarily overloaded. Try again!\n\n— Kael Vanta ®️")

@dp.message(Command(commands=["news", "headlines", "latest"]))
async def cmd_news(message: Message):
    """News fetching command using GNews or RSS."""
    await handle_gnews_command(message)

@dp.message(Command(commands=["research"]))
async def cmd_research(message: Message):
    """Kael Vanta Research Engine - SerpAPI + Smart Fallbacks"""
    await handle_research_command(message)

@dp.message(Command(commands=["search"]))
async def cmd_search(message: Message):
    """New Kael Vanta Search Engine - Direct to enhanced_research"""
    try:
        # Import the enhanced research function directly
        from core_features.research_enhanced import enhanced_research
        await enhanced_research(message)
        
    except Exception as e:
        await log_bot_error(f"Search error: {e}", message.from_user.id)
        await message.answer("⚠️ Search systems temporarily overloaded. Try again!\n\n— Kael Vanta ®️")


# New Advanced Feature Commands
@dp.message(Command(commands=["personality"]))
async def cmd_personality(message: Message):
    """Multi-personality mode"""
    try:
        await switch_personality(message)
    except Exception as e:
        await log_bot_error(f"Personality command error: {e}", message.from_user.id)
        await message.answer("⚠️ Personality system temporarily down.\n\n— Kael Vanta ®️")

@dp.message(Command(commands=["dailyhack", "hack"]))
async def cmd_daily_hack(message: Message):
    """Daily life hack"""
    try:
        await send_daily_hack(message)
    except Exception as e:
        await log_bot_error(f"Daily hack error: {e}", message.from_user.id)

@dp.message(Command(commands=["translate"]))
async def cmd_translate(message: Message):
    """Language translator"""
    try:
        await translate_text(message)
    except Exception as e:
        await log_bot_error(f"Translate error: {e}", message.from_user.id)

@dp.message(Command(commands=["create"]))
async def cmd_create(message: Message):
    """Creative content maker"""
    try:
        await create_content(message)
    except Exception as e:
        await log_bot_error(f"Create content error: {e}", message.from_user.id)

@dp.message(Command(commands=["code", "debug", "explain"]))
async def cmd_code(message: Message):
    """Code generator and debugger"""
    try:
        await handle_code(message)
    except Exception as e:
        await log_bot_error(f"Code command error: {e}", message.from_user.id)

@dp.message(Command(commands=["predict"]))
async def cmd_predict(message: Message):
    """Prediction mode"""
    try:
        await make_prediction(message)
    except Exception as e:
        await log_bot_error(f"Prediction error: {e}", message.from_user.id)

@dp.message(Command(commands=["support"]))
async def cmd_support(message: Message):
    """Emotional support mode"""
    try:
        await emotional_support(message)
    except Exception as e:
        await log_bot_error(f"Support error: {e}", message.from_user.id)

@dp.message(Command(commands=["customcmd"]))
async def cmd_custom_command(message: Message):
    """Custom command creator"""
    try:
        await create_custom_command(message)
    except Exception as e:
        await log_bot_error(f"Custom command error: {e}", message.from_user.id)

@dp.message(Command(commands=["roast", "compliment"]))
async def cmd_roast_compliment(message: Message):
    """Roast and compliment mode"""
    try:
        await roast_or_compliment(message)
    except Exception as e:
        await log_bot_error(f"Roast/compliment error: {e}", message.from_user.id)

@dp.message(Command(commands=["story"]))
async def cmd_story(message: Message):
    """Interactive story mode"""
    try:
        await interactive_story(message)
    except Exception as e:
        await log_bot_error(f"Story error: {e}", message.from_user.id)

@dp.message(Command(commands=["memory"]))
async def cmd_memory(message: Message):
    """Memory profile management"""
    try:
        await memory_profile(message)
    except Exception as e:
        await log_bot_error(f"Memory error: {e}", message.from_user.id)

@dp.message(Command(commands=["challenge"]))
async def cmd_challenge(message: Message):
    """Daily challenges"""
    try:
        await daily_challenge(message)
    except Exception as e:
        await log_bot_error(f"Challenge error: {e}", message.from_user.id)

@dp.message(Command(commands=["answer"]))
async def cmd_answer(message: Message):
    """Submit challenge answer"""
    try:
        await submit_challenge_answer(message)
    except Exception as e:
        await log_bot_error(f"Answer error: {e}", message.from_user.id)

@dp.message(Command(commands=["leaderboard"]))
async def cmd_leaderboard(message: Message):
    """Show leaderboard"""
    try:
        await show_leaderboard(message)
    except Exception as e:
        await log_bot_error(f"Leaderboard error: {e}", message.from_user.id)

@dp.message(Command(commands=["music", "lyrics", "spotify"]))
async def cmd_music(message: Message):
    """Music finder"""
    try:
        await find_music(message)
    except Exception as e:
        await log_bot_error(f"Music error: {e}", message.from_user.id)

@dp.message(Command(commands=["shop", "deals", "compare"]))
async def cmd_shopping(message: Message):
    """Shopping assistant"""
    try:
        await shopping_assistant(message)
    except Exception as e:
        await log_bot_error(f"Shopping error: {e}", message.from_user.id)

@dp.message(Command(commands=["offline"]))
async def cmd_offline(message: Message):
    """Offline knowledge"""
    try:
        await offline_knowledge(message)
    except Exception as e:
        await log_bot_error(f"Offline knowledge error: {e}", message.from_user.id)

@dp.message(Command(commands=["speak"]))
async def cmd_speak(message: Message):
    """Text to voice"""
    try:
        await text_to_voice(message)
    except Exception as e:
        await log_bot_error(f"Speak error: {e}", message.from_user.id)

@dp.message(Command(commands=["autoreply"]))
async def cmd_autoreply(message: Message):
    """Auto reply setup"""
    try:
        await setup_auto_reply(message)
    except Exception as e:
        await log_bot_error(f"Auto reply error: {e}", message.from_user.id)

@dp.message(Command(commands=["meme"]))
async def cmd_meme(message: Message):
    """Meme generator"""
    try:
        await generate_meme(message)
    except Exception as e:
        await log_bot_error(f"Meme error: {e}", message.from_user.id)
        await message.answer("⚠️ Meme generator temporarily down.\n\n— Kael Vanta ®️")

@dp.message(Command(commands=["deepseek", "think"]))
async def cmd_deepseek(message: Message):
    """DeepSeek reasoning engine"""
    try:
        from handlers.deepseek import deepseek_handler
        await deepseek_handler(message, bot)
    except Exception as e:
        await log_bot_error(f"DeepSeek error: {e}", message.from_user.id)
        await message.answer("🧠 DeepSeek temporarily overloaded. Neural networks need a moment!\n\n— Kael Vanta ®️")

# Sports Module Handlers
@dp.message(Command(commands=["sports"]))
async def cmd_sports(message: Message):
    """Sports data engine with multi-source intelligence"""
    try:
        from handlers.sports import handle_sports_command
        await handle_sports_command(message)
    except Exception as e:
        await log_bot_error(f"Sports error: {e}", message.from_user.id)
        await message.answer("🏈 Sports engine temporarily overloaded. Try again!\n\n— Kael Vanta ®️")

@dp.message(Command(commands=["fixtures"]))
async def cmd_fixtures(message: Message):
    """Upcoming fixtures"""
    try:
        from handlers.sports import handle_fixtures_command
        await handle_fixtures_command(message)
    except Exception as e:
        await log_bot_error(f"Fixtures error: {e}", message.from_user.id)
        await message.answer("🗓️ Fixtures temporarily unavailable!\n\n— Kael Vanta ®️")

@dp.message(Command(commands=["next"]))
async def cmd_next(message: Message):
    """Next scheduled match"""
    try:
        from handlers.sports import handle_next_command
        await handle_next_command(message)
    except Exception as e:
        await log_bot_error(f"Next match error: {e}", message.from_user.id)
        await message.answer("⏰ Next match lookup failed!\n\n— Kael Vanta ®️")

@dp.message(Command(commands=["score"]))
async def cmd_score(message: Message):
    """Live/final score lookup"""
    try:
        from handlers.sports import handle_score_command
        await handle_score_command(message)
    except Exception as e:
        await log_bot_error(f"Score error: {e}", message.from_user.id)
        await message.answer("🏆 Score lookup failed!\n\n— Kael Vanta ®️")

@dp.message(Command(commands=["standings"]))
async def cmd_standings(message: Message):
    """League standings"""
    try:
        from handlers.sports import handle_standings_command
        await handle_standings_command(message)
    except Exception as e:
        await log_bot_error(f"Standings error: {e}", message.from_user.id)
        await message.answer("📊 Standings temporarily unavailable!\n\n— Kael Vanta ®️")

@dp.message(Command(commands=["football"]))
async def cmd_football(message: Message):
    """Football alias for sports command"""
    try:
        from handlers.sports import handle_football_command
        await handle_football_command(message)
    except Exception as e:
        await log_bot_error(f"Football error: {e}", message.from_user.id)
        await message.answer("⚽ Football lookup failed!\n\n— Kael Vanta ®️")

# Model Router Commands
@dp.message(Command(commands=["models"]))
async def cmd_models(message: Message):
    """List available AI models - Enhanced with Groq support"""
    try:
        rows = MODEL_ROUTER.list_models()
        lines = [f"• <b>{r['nickname']}</b> — {r['provider']} [{r.get('model','')}]"
                 for r in rows]
        response = "🧠 <b>Available AI Cores:</b>\n\n" + "\n".join(lines)
        
        # Add Groq models if available
        if GROQ_AVAILABLE:
            groq_models = GROQ_ROUTER.list_models()
            health = GROQ_ROUTER.health()
            response += f"\n\n🚀 <b>Groq Models:</b> ({health['apis']['groq']['key_count']} keys)\n"
            for groq_model in groq_models:
                if groq_model['nickname'] != 'whisper_transcribe':  # Skip audio model in general list
                    response += f"• <b>{groq_model['nickname']}</b> — groq [{groq_model['model']}]\n"
        
        response += f"\n\n<i>Use /modelinfo [nickname] or /groqhealth for details</i>\n\n— Kael Vanta ®️"
        await message.answer(response)
    except Exception as e:
        await log_bot_error(f"Models command error: {e}", message.from_user.id)
        await message.answer("⚠️ Models list temporarily unavailable.\n\n— Kael Vanta ®️")

@dp.message(Command(commands=["modelinfo"]))
async def cmd_model_info(message: Message):
    """Get model details"""
    try:
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            await message.answer("⚠️ <b>Usage:</b> /modelinfo [nickname]\n\n— Kael Vanta ®️")
            return
        
        nickname = parts[1].strip()
        info = MODEL_ROUTER.model_info(nickname)
        if not info:
            await message.answer(f"⚠️ Unknown model: <b>{nickname}</b>\n\n— Kael Vanta ®️")
            return
        
        strengths = info.get("strengths", "—")
        provider = info.get("provider", "—")
        model = info.get("model", info.get("endpoint", "—"))
        fallbacks = info.get("fallback_chain", [])
        
        response = f"🔎 <b>{nickname}</b>\n\n"
        response += f"<b>Provider:</b> {provider}\n"
        response += f"<b>Model:</b> {model}\n"
        response += f"<b>Strengths:</b> {strengths}\n"
        if fallbacks:
            response += f"<b>Fallbacks:</b> {' → '.join(fallbacks)}\n"
        response += f"\n— Kael Vanta ®️"
        
        await message.answer(response)
    except Exception as e:
        await log_bot_error(f"Model info error: {e}", message.from_user.id)
        await message.answer("⚠️ Model info temporarily unavailable.\n\n— Kael Vanta ®️")

@dp.message(Command(commands=["switchmodel"]))
async def cmd_switch_model(message: Message):
    """Set default model per user"""
    try:
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            current = DEFAULT_MODEL_PER_USER.get(message.from_user.id, "auto")
            await message.answer(f"⚠️ <b>Usage:</b> /switchmodel [nickname]\n\n<b>Current:</b> {current}\n\n— Kael Vanta ®️")
            return
        
        nickname = parts[1].strip()
        if not MODEL_ROUTER.model_info(nickname):
            await message.answer(f"⚠️ Unknown model: <b>{nickname}</b>\n\nUse /models to see available cores.\n\n— Kael Vanta ®️")
            return
        
        DEFAULT_MODEL_PER_USER[message.from_user.id] = nickname
        strengths = MODEL_ROUTER.model_info(nickname).get("strengths", "")
        await message.answer(f"✅ <b>Default core set to:</b> {nickname}\n\n<i>{strengths}</i>\n\n— Kael Vanta ®️")
    except Exception as e:
        await log_bot_error(f"Switch model error: {e}", message.from_user.id)
        await message.answer("⚠️ Model switching temporarily unavailable.\n\n— Kael Vanta ®️")

@dp.message(Command(commands=["ask"]))
async def cmd_ask(message: Message):
    """Ask specific AI model - Enhanced with Groq support"""
    try:
        text = message.text[len("/ask"):].strip()
        if not text:
            current = DEFAULT_MODEL_PER_USER.get(message.from_user.id, "auto")
            groq_models = ""
            if GROQ_AVAILABLE:
                groq_models = "\n\n<b>🚀 Groq Models:</b>\n• llama31_fast\n• llama4_scout\n• gpt_oss"
            await message.answer(f"⚠️ <b>Usage:</b> /ask [nickname|auto] [prompt]\n\n<b>Current default:</b> {current}{groq_models}\n\n— Kael Vanta ®️")
            return

        parts = text.split(maxsplit=1)
        if len(parts) == 1:
            # No nickname → use user default or autoroute
            prompt = parts[0]
            nickname = DEFAULT_MODEL_PER_USER.get(message.from_user.id) or MODEL_ROUTER.autoroute(prompt)
        else:
            nickname_raw, prompt = parts[0].lower(), parts[1]
            if nickname_raw == "auto":
                nickname = MODEL_ROUTER.autoroute(prompt)
            else:
                nickname = nickname_raw
                
                # Check if it's a Groq model first
                groq_models = ["llama31_fast", "llama4_scout", "gpt_oss", "whisper_transcribe"]
                if nickname in groq_models and GROQ_AVAILABLE:
                    # Use Groq router
                    await message.chat.send_action("typing")
                    reply = GROQ_ROUTER.ask_text(prompt, nickname)
                    
                    response = f"🚀 <b>Groq Model:</b> {nickname}\n\n{reply}\n\n— Kael Vanta ®️"
                    await message.answer(response)
                    
                    # Log the interaction
                    add_message(message.from_user.id, "user", f"/ask {nickname} {prompt}")
                    add_message(message.from_user.id, "assistant", reply)
                    return
                
                # Check original models
                if not MODEL_ROUTER.model_info(nickname):
                    await message.answer(f"⚠️ Unknown model nickname: <b>{nickname}</b>\n\nUse /models to see available cores.\n\n— Kael Vanta ®️")
                    return

        # Send typing indicator
        await message.chat.send_action("typing")
        
        # Execute with original router
        reply = MODEL_ROUTER.ask(nickname, prompt, SYSTEM_PROMPT)
        strengths = MODEL_ROUTER.model_info(nickname).get("strengths", "")
        
        response = f"🤖 <b>Activated:</b> {nickname}\n"
        response += f"<i>{strengths}</i>\n\n"
        response += f"{reply}\n\n— Kael Vanta ®️"
        
        await message.answer(response)
        
        # Log the interaction
        log_model_reply(message.from_user.id, nickname, prompt, reply)
        
    except Exception as e:
        await log_bot_error(f"Ask command error: {e}", message.from_user.id)
        await message.answer("⚠️ AI core temporarily unavailable. Try again shortly.\n\n— Kael Vanta ®️")

# Duplicate news command handler removed, use the one with GNews/RSS logic

@dp.message(Command(commands=["personaforge", "forge", "personas"]))
async def cmd_personaforge(message: Message):
    """PersonaForge - Advanced personality customization"""
    try:
        from core_features.personaforge import personaforge_main
        await personaforge_main(message)
    except Exception as e:
        await log_bot_error(f"PersonaForge error: {e}", message.from_user.id)
        await message.answer("⚠️ PersonaForge temporarily down.\n\n— Kael Vanta ®️")

@dp.message(Command(commands=["createpersona", "newpersona"]))
async def cmd_create_persona(message: Message):
    """Create new persona via command"""
    try:
        from core_features.personaforge import create_persona_wizard
        await create_persona_wizard(message)
    except Exception as e:
        await log_bot_error(f"Create persona error: {e}", message.from_user.id)
        await message.answer("⚠️ Persona creation temporarily down.\n\n— Kael Vanta ®️")

# PersonaForge Callback Handlers
@dp.callback_query(lambda c: c.data and c.data.startswith('pf_'))
async def handle_personaforge_callbacks(callback_query):
    """Handle PersonaForge button callbacks"""
    try:
        from core_features.personaforge import handle_personaforge_callback
        await handle_personaforge_callback(callback_query)
    except Exception as e:
        await log_bot_error(f"PersonaForge callback error: {e}")
        await callback_query.answer("⚠️ Feature temporarily unavailable")

@dp.message(lambda message: message.content_type == ContentType.PHOTO)
async def handle_photo(message: Message):
    """Enhanced image handler with error protection"""
    try:
        await handle_image(message)
    except Exception as e:
        await log_bot_error(f"Image handler error: {e}", message.from_user.id)
        await message.answer("⚠️ Image analysis temporarily down. Try again later!\n\n— Kael Vanta ®️")

@dp.message(lambda message: message.content_type == ContentType.VOICE)
async def handle_voice(message: Message):
    """Handle voice messages"""
    try:
        await handle_voice_message(message, bot)
    except Exception as e:
        await log_bot_error(f"Voice handler error: {e}", message.from_user.id)
        await message.answer("⚠️ Voice processing temporarily down.\n\n— Kael Vanta ®️")

@dp.message()
async def handle_message(message: Message):
    """Enhanced message handler with smart detection and error handling"""
    try:
        user_input = message.text
        user_id = message.from_user.id

        # Log user message
        add_message(user_id, "user", user_input)

        # Check for custom commands first
        if user_input.startswith('/'):
            command_name = user_input.split()[0][1:].lower()
            if await execute_custom_command(message, command_name):
                return

        # Check for command-like input
        if any(word in user_input.lower() for word in [
            "help", "alpha", "flirt", "motivate", "advice", "plan", "research", "surprise"
        ]):
            await handle_custom_commands(message)
            return

        # Check if auto-reply should trigger
        if await should_auto_reply(message):
            auto_reply = await generate_auto_reply(message)
            if auto_reply:
                await message.answer(auto_reply)
                return

        # Regular AI conversation
        api_items = list(API_KEYS.items())
        if not api_items:
            await message.answer("⚠️ No AI models available. Try again later!\n\n— Kael Vanta ®️")
            return

        model, key = random.choice(api_items)

        # Add typing indicator for longer responses
        try:
            await message.chat.send_action("typing")
        except:
            pass  # Continue even if typing indicator fails

        reply = await get_ai_response(user_input, model, key, user_id)

        # Validate reply before processing
        if not reply or not isinstance(reply, str):
            reply = "🔥 System temporarily overloaded. Try again!\n\n— Kael Vanta ®️"

        # Log bot response safely
        try:
            add_message(user_id, "assistant", reply)
        except:
            pass  # Continue even if logging fails

        await message.answer(reply)

    except Exception as e:
        await log_bot_error(f"Message handler error: {e}", message.from_user.id)

        # Fallback response
        fallback_responses = [
            "🔥 System temporarily overloaded. Try again!",
            "⚡ AI brain needs a moment. Hit me again!",
            "💪 Technical difficulties. We're stronger than this!",
            "🧠 Processing power at max. One more time!"
        ]

        await message.answer(f"{random.choice(fallback_responses)}\n\n— Kael Vanta ®️")

async def startup_tasks():
    """Perform startup tasks and checks"""
    try:
        # Load startup rules
        load_startup_rules()

        # Start keep-alive server (always needed for health checks)
        keep_alive()

        # Check memory file
        memory = load_memory()
        startup_msg = f"Memory loaded: {len(memory)} users tracked"

        if IS_DEPLOYMENT:
            startup_msg += " [DEPLOYMENT MODE]"
        else:
            startup_msg += " [DEVELOPMENT MODE]"

        print(startup_msg)

        # Check API keys and secrets
        from keys import check_secrets_configured
        secrets_status = check_secrets_configured()

        configured_secrets = sum(1 for configured in secrets_status.values() if configured)
        print(f"Secrets configured: {configured_secrets}/4 - {secrets_status}")
        print(f"Legacy API Keys available: {len(API_KEYS)} models")
        
        # Check SERPAPI specifically for research features
        if not os.getenv("SERPAPI_API_KEY"):
            print("⚠️ WARNING: SERPAPI_API_KEY not configured - research features will use fallback only")

        if not secrets_status["BOT_TOKEN"]:
            print("❌ CRITICAL: BOT_TOKEN not configured in Secrets!")

        if not secrets_status["CHATANYWHERE_API_KEY"] and not secrets_status["OPENROUTER_API_KEY"]:
            print("⚠️ WARNING: No primary API keys configured in Secrets - using legacy keys")

        # Log startup
        log_error(f"COREVANTA AI STARTED SUCCESSFULLY - {'DEPLOYMENT' if IS_DEPLOYMENT else 'DEVELOPMENT'}")

        print("🔥 COREVANTA AI - Fully loaded and ready for domination!")

        # Notify owner of deployment startup
        if IS_DEPLOYMENT:
            try:
                await bot.send_message(
                    chat_id=7976711112,
                    text="🚀 <b>COREVANTA AI DEPLOYED</b>\n\nBot is now running 24/7 in production mode!\n\n— System Monitor"
                )
            except:
                pass

    except Exception as e:
        print(f"Startup warning: {e}")
        log_error(f"Startup error: {e}")

def load_startup_rules():
    """Load and display startup rules"""
    try:
        if os.path.exists("STARTUP_RULES.txt"):
            with open("STARTUP_RULES.txt", "r") as f:
                rules = f.read()
                print("=" * 50)
                print("COREVANTA AI - STARTUP RULES LOADED")
                print("=" * 50)
                print(rules)
                print("=" * 50)
                return True
    except Exception as e:
        print(f"Warning: Could not load startup rules: {e}")
    return False

async def main():
    """Enhanced main function with startup tasks"""
    try:
        # Configure logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )

        # Perform startup tasks
        await startup_tasks()

        # Clear pending updates and start polling
        await bot.delete_webhook(drop_pending_updates=True)
        print("🚀 Starting polling...")
        await dp.start_polling(bot)

    except Exception as e:
        critical_error = f"CRITICAL STARTUP ERROR: {e}"
        print(critical_error)
        log_error(critical_error)

        # Try to notify owner
        try:
            await bot.send_message(
                chat_id=7976711112,
                text=f"🚨 <b>COREVANTA AI CRITICAL ERROR</b>\n\n{critical_error}\n\n— Emergency System"
            )
        except:
            pass

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 COREVANTA AI shutdown requested")
        log_error("COREVANTA AI SHUTDOWN - User requested")
    except Exception as e:
        print(f"\n💥 COREVANTA AI crashed: {e}")
        log_error(f"CRITICAL CRASH: {e}")

# Groq health command (separate from /health)
@dp.message(Command(commands=["groqhealth", "groq_health"]))
async def cmd_groq_health(message: Message):
    """Detailed Groq system health check"""
    try:
        if not GROQ_AVAILABLE:
            await message.answer("⚠️ Groq router not available.")
            return
        
        health = GROQ_ROUTER.health()
        
        health_text = "🔥 **Groq System Health Report**\n\n"
        
        # API Status
        groq_api = health['apis']['groq']
        health_text += f"**Groq API:**\n"
        health_text += f"• Configured: {'✅' if groq_api['configured'] else '❌'}\n"
        health_text += f"• Key Count: {groq_api['key_count']}\n"
        
        if groq_api['key_pool_status']:
            status = groq_api['key_pool_status']
            health_text += f"• Available Keys: {status['available_keys']}/{status['total_keys']}\n"
            if status['failed_keys']:
                health_text += f"• Failed Keys: {len(status['failed_keys'])} (in cooldown)\n"
        
        # OpenRouter Fallback
        or_api = health['apis']['openrouter_fallback']
        health_text += f"\n**OpenRouter Fallback:**\n"
        health_text += f"• Configured: {'✅' if or_api['configured'] else '❌'}\n"
        
        # Models
        health_text += f"\n**Models:** {health['total_models']} available\n"
        health_text += f"**Default Models:**\n"
        for model_type, model_name in health['default_models'].items():
            health_text += f"• {model_type.upper()}: {model_name}\n"
        
        await message.answer(health_text)
        
    except Exception as e:
        await log_bot_error(f"Groq health error: {e}", message.from_user.id)
        await message.answer("⚠️ Health check failed.\n\n— Kael Vanta ®️")
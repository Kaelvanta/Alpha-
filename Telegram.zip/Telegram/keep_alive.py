from flask import Flask, jsonify
import threading
import time

app = Flask('')

@app.route('/')
def home():
    return """
    <div style="text-align: center; font-family: 'Courier New', monospace; background: #0a0a0a; color: #00ff41; padding: 50px;">
        <h1>🔥 CORE VANTA AI</h1>
        <h2>⚡ Status: ONLINE</h2>
        <p>Kael Vanta Syndicate ®️</p>
        <p>Futuristic AI | 24/7 Uptime | Hacker-Genius Intelligence</p>
        <div style="margin-top: 30px; font-size: 12px;">
            <p>🧠 Multi-API Strategy Active</p>
            <p>🔍 Enhanced Research Engine</p>
            <p>💻 Advanced Code Analysis</p>
            <p>🎯 Logical Reasoning Mode</p>
        </div>
    </div>
    """

@app.route('/health')
def health():
    try:
        from model_router import ModelRouter
        router = ModelRouter()
        models_count = len(router.list_models())
        return jsonify({"ok": True, "models": models_count}), 200
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = threading.Thread(target=run)
    t.daemon = True
    t.start()
    print("🔥 Core Vanta AI Keep-Alive Server: ONLINE on port 8080")
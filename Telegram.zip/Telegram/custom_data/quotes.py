# custom_data/quotes.py

alpha_quotes = [
    "Discipline is doing it even when no one is watching.",
    "A lion never loses sleep over the opinion of sheep.",
    "Stay focused. Stay savage. Stay unstoppable.",
    "Alpha moves in silence, but his results scream.",
    "She loves power. Become it.",
    "Never beg. Replace. Upgrade. Move on.",
    "Pain builds warriors. Comfort builds weakness.",
    "You either train like a beast or remain average forever.",
    "They doubted you? Perfect. Use that as fuel.",
    "Grind in silence. Let success make the noise."
]
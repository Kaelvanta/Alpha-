# custom_data/flirts.py

flirt_lines = [
    "Are you made of copper and tellurium? Because you’re Cu-Te.",
    "You’re not a magician, but every time I look at you, everyone else disappears.",
    "I must be a snowflake, because I've fallen for you.",
    "Do you believe in fate? Because I think we just matched energy.",
    "Your beauty rivals my ambition — and that says a lot.",
    "You bring chaos to my calm, and I like it.",
    "Are you WiFi? Because I’m feeling a strong connection.",
    "Forget pickup lines. Just give me your number.",
    "You’re the reason kings went to war.",
    "I wasn't planning on falling today, but here we are."
]
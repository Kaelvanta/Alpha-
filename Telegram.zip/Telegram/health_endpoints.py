
"""
Centralized Health Check Endpoints
Monitoring dashboard for all COREVANTA AI features
"""
import json
import os
from datetime import datetime
from flask import Flask, jsonify
from memory import log_error

# Import health check functions
try:
    from core_features.vantavault import vault
    from core_features.moodsync import mood_sync
    from core_features.codeforge import code_forge
    from core_features.swaggerapi import swagger_api
    from core_features.quantumthink import quantum_think
    from core_features.personaforge import forge as persona_forge
    FEATURES_AVAILABLE = True
except ImportError as e:
    print(f"⚠️  Health endpoints: Some features not available - {e}")
    FEATURES_AVAILABLE = False

app = Flask(__name__)

@app.route('/health', methods=['GET'])
def overall_health():
    """Overall system health check"""
    try:
        health_data = {
            "timestamp": datetime.now().isoformat(),
            "status": "healthy",
            "version": "2.0.0",
            "uptime": get_uptime(),
            "features": {},
            "summary": {}
        }
        
        if not FEATURES_AVAILABLE:
            health_data["status"] = "partial"
            health_data["warning"] = "Some features unavailable"
            return jsonify(health_data), 503
        
        # Check each feature
        feature_checks = [
            ("memory", check_memory_health),
            ("vault", check_vault_health), 
            ("moods", check_mood_health),
            ("codeforge", check_codeforge_health),
            ("swagger", check_swagger_health),
            ("quantum", check_quantum_health),
            ("personas", check_persona_health)
        ]
        
        healthy_count = 0
        total_count = len(feature_checks)
        
        for feature_name, check_func in feature_checks:
            try:
                feature_health = check_func()
                health_data["features"][feature_name] = feature_health
                
                if feature_health.get("status") == "healthy":
                    healthy_count += 1
            except Exception as e:
                health_data["features"][feature_name] = {
                    "status": "error",
                    "error": str(e)
                }
        
        # Overall status
        health_ratio = healthy_count / total_count
        if health_ratio >= 0.8:
            health_data["status"] = "healthy"
        elif health_ratio >= 0.5:
            health_data["status"] = "degraded"
        else:
            health_data["status"] = "critical"
            
        health_data["summary"] = {
            "healthy_features": healthy_count,
            "total_features": total_count,
            "health_ratio": round(health_ratio, 2)
        }
        
        status_code = 200 if health_data["status"] == "healthy" else 503
        return jsonify(health_data), status_code
        
    except Exception as e:
        log_error(f"Overall health check failed: {e}")
        return jsonify({
            "timestamp": datetime.now().isoformat(),
            "status": "error",
            "error": str(e)
        }), 500

@app.route('/health/memory', methods=['GET'])
def memory_health():
    """Memory system health"""
    return jsonify(check_memory_health())

@app.route('/health/vault', methods=['GET'])
def vault_health():
    """VantaVault health"""
    return jsonify(check_vault_health())

@app.route('/health/moods', methods=['GET'])
def mood_health():
    """MoodSync health"""
    return jsonify(check_mood_health())

@app.route('/health/codeforge', methods=['GET'])
def codeforge_health():
    """CodeForge health"""
    return jsonify(check_codeforge_health())

@app.route('/health/swagger', methods=['GET'])
def swagger_health():
    """SwaggerAPI health"""
    return jsonify(check_swagger_health())

@app.route('/health/quantum', methods=['GET'])
def quantum_health():
    """QuantumThink health"""
    return jsonify(check_quantum_health())

@app.route('/health/personas', methods=['GET'])
def persona_health():
    """PersonaForge health"""  
    return jsonify(check_persona_health())

# Health check functions
def check_memory_health():
    """Check memory system health"""
    try:
        from memory import load_memory
        memory = load_memory()
        return {
            "status": "healthy",
            "users": len(memory),
            "total_size": len(json.dumps(memory)),
            "backup_available": os.path.exists("backups")
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}

def check_vault_health():
    """Check VantaVault health"""
    if not FEATURES_AVAILABLE:
        return {"status": "unavailable"}
    try:
        return vault.health_check()
    except Exception as e:
        return {"status": "error", "error": str(e)}

def check_mood_health():
    """Check MoodSync health"""
    if not FEATURES_AVAILABLE:
        return {"status": "unavailable"}
    try:
        return mood_sync.get_mood_health_metrics()
    except Exception as e:
        return {"status": "error", "error": str(e)}

def check_codeforge_health():
    """Check CodeForge health"""
    if not FEATURES_AVAILABLE:
        return {"status": "unavailable"}
    try:
        stats = code_forge.get_code_stats()
        stats["status"] = "healthy"
        return stats
    except Exception as e:
        return {"status": "error", "error": str(e)}

def check_swagger_health():
    """Check SwaggerAPI health"""
    if not FEATURES_AVAILABLE:
        return {"status": "unavailable"}
    try:
        stats = swagger_api.get_api_stats()
        stats["status"] = "healthy"
        return stats
    except Exception as e:
        return {"status": "error", "error": str(e)}

def check_quantum_health():
    """Check QuantumThink health"""
    if not FEATURES_AVAILABLE:
        return {"status": "unavailable"}
    try:
        stats = quantum_think.get_quantum_stats()
        stats["status"] = "healthy"
        return stats
    except Exception as e:
        return {"status": "error", "error": str(e)}

def check_persona_health():
    """Check PersonaForge health"""
    if not FEATURES_AVAILABLE:
        return {"status": "unavailable"}
    try:
        # Basic PersonaForge health check
        personas = persona_forge.list_all_personas()
        return {
            "status": "healthy",
            "total_personas": len(personas),
            "built_in_personas": len([p for p in personas if p.get("built_in")]),
            "custom_personas": len([p for p in personas if not p.get("built_in")])
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}

def get_uptime():
    """Get system uptime"""
    try:
        with open('/proc/uptime', 'r') as f:
            uptime_seconds = float(f.readline().split()[0])
            return f"{uptime_seconds:.0f} seconds"
    except:
        return "unknown"

if __name__ == '__main__':
    # Run health server on port 5001 (separate from main bot)
    print("🏥 Starting Health Check Server on port 5001...")
    app.run(host='0.0.0.0', port=5001, debug=False)

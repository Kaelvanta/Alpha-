# Overview

COREVANTA AI is a sophisticated Telegram bot powered by Kael Vanta's personality framework. The system provides advanced AI conversation capabilities with multi-model routing, personality customization, encrypted storage, and comprehensive feature modules. The bot integrates multiple AI providers (OpenRouter, ChatAnywhere, Azure) with intelligent failover and supports voice processing, news fetching, sports data, research tools, and automated monitoring.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Core Bot Framework
- **Telegram Integration**: Built on aiogram framework for async Telegram bot operations
- **Multi-Model AI Routing**: ModelRouter class manages multiple AI providers with automatic failover
- **Personality System**: Kael Vanta's alpha personality with customizable user preferences via PersonaForge
- **Memory Management**: JSON-based conversation history with backup system

## AI Provider Strategy
- **Primary**: ChatAnywhere (OpenAI-compatible API)
- **Secondary**: OpenRouter (multiple free models with key rotation)  
- **Tertiary**: Azure AI Inference (Phi-4-reasoning model)
- **Failover Logic**: Automatic API switching on 401, 403, 429, and 5xx errors
- **Key Management**: Environment-based secrets with rate limiting and health checks

## Data Storage & Security
- **VantaVault**: Fernet-encrypted local storage for sensitive data
- **Memory System**: User conversation history and preferences in JSON format
- **Backup Strategy**: Automatic file backups before modifications
- **Cache Layer**: TTL caching for API responses and research results

## Feature Architecture
- **Modular Design**: Core features organized in separate modules under core_features/
- **Command Router**: Dynamic command handling with custom user commands
- **Voice Processing**: Voice-to-text and text-to-voice capabilities (placeholder implementation)
- **Content Creation**: Multi-format content generation with templates
- **Research Engine**: Multi-source research with Wikipedia, news feeds, and search APIs

## Monitoring & Health
- **Health Endpoints**: Comprehensive system health monitoring via HTTP endpoints
- **Supervisor System**: Always-on monitoring with automated alerts
- **Error Logging**: Centralized error tracking with backup integration
- **Conflict Guard**: Process management to prevent duplicate bot instances

## Advanced Features
- **MoodSync**: Sentiment analysis and emotional intelligence tracking
- **CodeForge**: Safe code generation with validation and templates
- **QuantumThink**: Multi-step reasoning engine for complex problem solving
- **SwaggerAPI**: Automatic API documentation generation

# External Dependencies

## AI Services
- **OpenRouter**: Multi-model AI access with free tier models
- **ChatAnywhere**: OpenAI-compatible API for primary chat completions
- **Azure AI Inference**: Microsoft's AI models via GitHub Models Gateway

## Search & Research
- **SerpAPI**: Google search results for research functionality
- **DuckDuckGo Search**: Fallback search provider
- **Wikipedia API**: Encyclopedia content retrieval
- **GNews API**: News article fetching and search

## Infrastructure
- **Telegram Bot API**: Core messaging platform via aiogram
- **Flask/FastAPI**: HTTP health endpoints and proxy server
- **Replicate**: Image processing and analysis capabilities

## Data & Content
- **RSS Feeds**: News aggregation from multiple sources
- **Sports APIs**: API-Football and TheSportsDB for sports data
- **Cryptography**: Fernet encryption for secure data storage

## Monitoring
- **psutil**: System resource monitoring
- **cachetools**: Memory caching with TTL support
- **feedparser**: RSS feed parsing for news content

"""
CoreVanta AI - Team Search Tester
Tests both API-Football and TheSportsDB team search
— Kael Vanta ®️
"""

import os
import sys
import requests
import json
import asyncio
import aiohttp

async def test_api_football_team_search(team_name):
    """Test API-Football team search"""
    api_key = os.getenv("API_FOOTBALL_KEY")
    if not api_key:
        print(f"❌ API_FOOTBALL_KEY not available for {team_name}")
        return None
    
    try:
        url = "https://v3.football.api-sports.io/teams"
        headers = {"x-apisports-key": api_key}
        params = {"search": team_name}
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers, params=params, timeout=10) as response:
                text = await response.text()
                print(f"API-Football search '{team_name}': {response.status}")
                
                if response.status == 200:
                    data = await response.json()
                    teams = data.get("response", [])
                    if teams:
                        team = teams[0].get("team", {})
                        print(f"✅ Found: {team.get('name')} (ID: {team.get('id')}, Country: {team.get('country')})")
                        return team
                    else:
                        print(f"❌ No teams found for '{team_name}'")
                        return None
                else:
                    print(f"❌ Error {response.status}: {text[:300]}")
                    return None
                    
    except Exception as e:
        print(f"❌ API-Football error for '{team_name}': {e}")
        return None

async def test_thesportsdb_team_search(team_name):
    """Test TheSportsDB team search"""
    try:
        url = f"https://www.thesportsdb.com/api/v1/json/3/searchteams.php?t={team_name}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=10) as response:
                text = await response.text()
                print(f"TheSportsDB search '{team_name}': {response.status}")
                
                if response.status == 200:
                    data = await response.json()
                    teams = data.get("teams")
                    if teams:
                        team = teams[0]
                        print(f"✅ Found: {team.get('strTeam')} (ID: {team.get('idTeam')}, Country: {team.get('strCountry')})")
                        return team
                    else:
                        print(f"❌ No teams found for '{team_name}'")
                        return None
                else:
                    print(f"❌ Error {response.status}: {text[:300]}")
                    return None
                    
    except Exception as e:
        print(f"❌ TheSportsDB error for '{team_name}': {e}")
        return None

async def main():
    team_name = sys.argv[1] if len(sys.argv) > 1 else "Arsenal"
    
    print(f"🔍 Testing team search for: {team_name}")
    print("=" * 50)
    
    # Test API-Football
    print("Testing API-Football...")
    api_result = await test_api_football_team_search(team_name)
    
    print()
    
    # Test TheSportsDB
    print("Testing TheSportsDB...")
    tsdb_result = await test_thesportsdb_team_search(team_name)
    
    print("=" * 50)
    
    if api_result:
        print("🎯 Primary API-Football: SUCCESS")
    elif tsdb_result:
        print("⚠️ Fallback TheSportsDB: SUCCESS")
    else:
        print("❌ Both APIs: FAILED")

if __name__ == "__main__":
    asyncio.run(main())

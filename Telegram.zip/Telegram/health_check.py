
#!/usr/bin/env python3
"""
CoreVanta AI - Health Check Service
Runs HTTP health endpoint for uptime monitoring
— Kael Vanta ®️
"""

import os
import json
import threading
import time
from flask import Flask, jsonify
from datetime import datetime

app = Flask(__name__)

def get_health_status():
    """Get comprehensive health status"""
    
    # Check environment variables
    env_status = {
        "BOT_TOKEN": bool(os.getenv("BOT_TOKEN")),
        "API_FOOTBALL_KEY": bool(os.getenv("API_FOOTBALL_KEY")),
        "THESPORTSDB_KEY": bool(os.getenv("THESPORTSDB_KEY")),
        "SERPAPI_KEY": bool(os.getenv("SERPAPI_KEY")),
        "ADMIN_TELEGRAM_ID": bool(os.getenv("ADMIN_TELEGRAM_ID"))
    }
    
    configured_count = sum(env_status.values())
    
    # Determine overall status
    if env_status["BOT_TOKEN"] and (env_status["API_FOOTBALL_KEY"] or env_status["THESPORTSDB_KEY"]):
        overall_status = "healthy"
    elif env_status["BOT_TOKEN"]:
        overall_status = "degraded"
    else:
        overall_status = "critical"
    
    return {
        "status": overall_status,
        "timestamp": datetime.now().isoformat(),
        "environment": {
            "configured_secrets": f"{configured_count}/5",
            "details": env_status
        },
        "sports_module": {
            "primary_api": "API-Football" if env_status["API_FOOTBALL_KEY"] else None,
            "fallback_api": "TheSportsDB" if env_status["THESPORTSDB_KEY"] else None,
            "last_resort": "SerpAPI" if env_status["SERPAPI_KEY"] else None
        },
        "security": {
            "secrets_from_env": True,
            "no_hardcoded_keys": True,
            "admin_alerts": env_status["ADMIN_TELEGRAM_ID"]
        }
    }

@app.route('/health')
def health():
    """Main health endpoint"""
    try:
        health_data = get_health_status()
        
        if health_data["status"] == "healthy":
            return jsonify(health_data), 200
        elif health_data["status"] == "degraded":
            return jsonify(health_data), 200
        else:
            return jsonify(health_data), 503
            
    except Exception as e:
        return jsonify({
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }), 500

@app.route('/health/sports')
def health_sports():
    """Sports module specific health"""
    health_data = get_health_status()
    return jsonify(health_data["sports_module"])

@app.route('/health/security')
def health_security():
    """Security status check"""
    health_data = get_health_status()
    return jsonify(health_data["security"])

@app.route('/')
def index():
    """Root endpoint"""
    return jsonify({
        "service": "CoreVanta AI",
        "module": "Sports Engine",
        "status": "online",
        "endpoints": ["/health", "/health/sports", "/health/security"],
        "timestamp": datetime.now().isoformat()
    })

def start_health_server():
    """Start health check server in daemon thread"""
    def run_server():
        app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)
    
    health_thread = threading.Thread(target=run_server, daemon=True)
    health_thread.start()
    
    # Give server time to start
    time.sleep(2)
    print("🏥 Health check server started on http://0.0.0.0:5000")
    print("🔍 Available endpoints:")
    print("  • /health - Overall system health")
    print("  • /health/sports - Sports module status")
    print("  • /health/security - Security validation")

if __name__ == "__main__":
    start_health_server()
    
    # Keep main thread alive for testing
    try:
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        print("\n🛑 Health server stopped")


#!/usr/bin/env python3
"""
CoreVanta AI - API Status Test
Tests API-Football connection using environment variable API key
— Kael Vanta ®️
"""

import os
import requests
import sys

def test_api_football_status():
    """Test API-Football status endpoint"""
    
    # Read API key from environment (secure)
    api_key = os.getenv("API_FOOTBALL_KEY")
    
    if not api_key:
        print("❌ API_FOOTBALL_KEY not set in environment variables")
        print("Configure in Replit Secrets: Tools → Secrets → API_FOOTBALL_KEY")
        return False
    
    try:
        url = "https://v3.football.api-sports.io/status"
        headers = {"x-apisports-key": api_key}
        
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            account_info = data.get("response", {}).get("account", {})
            status = account_info.get("firstname", "Unknown")
            requests_today = account_info.get("requests", {}).get("current", 0)
            limit_day = account_info.get("requests", {}).get("limit_day", 0)
            
            print(f"✅ API-Football: {status} | Requests: {requests_today}/{limit_day}")
            return True
        else:
            print(f"❌ API-Football HTTP {response.status_code}: {response.text[:100]}")
            return False
            
    except Exception as e:
        print(f"❌ API-Football connection error: {e}")
        return False

def test_thesportsdb_status():
    """Test TheSportsDB fallback"""
    try:
        url = "https://www.thesportsdb.com/api/v1/json/3/searchteams.php?t=Arsenal"
        response = requests.get(url, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            teams = data.get("teams")
            if teams:
                print("✅ TheSportsDB fallback: Available")
                return True
        
        print("❌ TheSportsDB fallback: No data")
        return False
        
    except Exception as e:
        print(f"❌ TheSportsDB error: {e}")
        return False

if __name__ == "__main__":
    print("🔍 CoreVanta AI - Sports API Status Check")
    print("=" * 50)
    
    primary_ok = test_api_football_status()
    fallback_ok = test_thesportsdb_status()
    
    print("=" * 50)
    
    if primary_ok:
        print("🎯 PRIMARY: API-Football ready")
    elif fallback_ok:
        print("⚠️ FALLBACK: TheSportsDB only")
    else:
        print("❌ CRITICAL: No sports APIs available")
        sys.exit(1)
    
    print("✅ Sports module ready for deployment")
"""
CoreVanta AI - Sports API Status Checker
Tests API-Football and TheSportsDB connectivity
— Kael Vanta ®️
"""

import os
import sys
import requests
import json

def test_api_football_status():
    """Test API-Football status endpoint"""
    api_key = os.getenv("API_FOOTBALL_KEY")
    if not api_key:
        print("❌ API_FOOTBALL_KEY not found in environment")
        return False
    
    try:
        url = "https://v3.football.api-sports.io/status"
        headers = {"x-apisports-key": api_key}
        
        response = requests.get(url, headers=headers, timeout=10)
        
        print(f"API-Football Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            account = data.get("response", {}).get("account", {})
            requests_info = data.get("response", {}).get("requests", {})
            
            print("✅ API-Football: Connected")
            print(f"   Account: {account.get('firstname', 'N/A')} {account.get('lastname', 'N/A')}")
            print(f"   Plan: {account.get('plan', 'N/A')}")
            print(f"   Requests Today: {requests_info.get('current', 0)}/{requests_info.get('limit_day', 0)}")
            return True
        elif response.status_code == 401:
            print("❌ API-Football: Invalid API key (401)")
            print("   Action: Rotate API key and add to Replit Secrets")
            return False
        elif response.status_code == 403:
            print("❌ API-Football: Access forbidden (403)")
            print("   Action: Check API key permissions")
            return False
        else:
            print(f"❌ API-Football: Unexpected status {response.status_code}")
            print(f"   Response: {response.text[:500]}")
            return False
            
    except Exception as e:
        print(f"❌ API-Football connection error: {e}")
        return False

def test_thesportsdb_status():
    """Test TheSportsDB fallback"""
    try:
        url = "https://www.thesportsdb.com/api/v1/json/3/searchteams.php?t=Arsenal"
        response = requests.get(url, timeout=10)
        
        print(f"TheSportsDB Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            teams = data.get("teams")
            if teams:
                print("✅ TheSportsDB: Available")
                print(f"   Test search found: {teams[0].get('strTeam', 'N/A')}")
                return True
            else:
                print("⚠️ TheSportsDB: Connected but no test data")
                return False
        else:
            print(f"❌ TheSportsDB: Status {response.status_code}")
            print(f"   Response: {response.text[:500]}")
            return False
        
    except Exception as e:
        print(f"❌ TheSportsDB error: {e}")
        return False

if __name__ == "__main__":
    print("🔍 CoreVanta AI - Sports API Status Check")
    print("=" * 50)
    
    primary_ok = test_api_football_status()
    fallback_ok = test_thesportsdb_status()
    
    print("=" * 50)
    
    if primary_ok:
        print("🎯 STATUS: Primary API-Football ready")
        sys.exit(0)
    elif fallback_ok:
        print("⚠️ STATUS: Fallback TheSportsDB only")
        sys.exit(0)
    else:
        print("❌ CRITICAL: No sports APIs available")
        sys.exit(1)

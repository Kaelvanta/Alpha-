import wikipedia

def fetch_wikipedia_summary(query, sentences=3):
    try:
        summary = wikipedia.summary(query, sentences=sentences)
        return f"📚 **Wikipedia Summary for** `{query}`:\n\n{summary}"
    except wikipedia.exceptions.DisambiguationError as e:
        return f"⚠️ Too many results. Be more specific:\n{', '.join(e.options[:5])}..."
    except wikipedia.exceptions.PageError:
        return f"❌ No Wikipedia page found for '{query}'."
    except Exception as e:
        return f"🚨 Error fetching Wikipedia info: {str(e)}"
import requests
from bs4 import BeautifulSoup

def youtube_search(query, max_results=3):
    search_url = f"https://www.youtube.com/results?search_query={query}"
    headers = {
        "User-Agent": "Mozilla/5.0"
    }

    response = requests.get(search_url, headers=headers)
    if response.status_code != 200:
        return ["❌ YouTube search failed."]

    soup = BeautifulSoup(response.text, "html.parser")
    results = []

    for script in soup.find_all("script"):
        if "var ytInitialData" in script.text:
            start = script.text.find("var ytInitialData") + len("var ytInitialData = ")
            end = script.text.rfind("};") + 1
            raw_json = script.text[start:end]
            try:
                import json
                data = json.loads(raw_json)
                videos = data["contents"]["twoColumnSearchResultsRenderer"]["primaryContents"]["sectionListRenderer"]["contents"]
                for section in videos:
                    items = section.get("itemSectionRenderer", {}).get("contents", [])
                    for item in items:
                        video_data = item.get("videoRenderer")
                        if video_data:
                            title = video_data["title"]["runs"][0]["text"]
                            video_id = video_data["videoId"]
                            url = f"https://www.youtube.com/watch?v={video_id}"
                            results.append(f"{title}\n{url}")
                            if len(results) == max_results:
                                return results
            except Exception:
                return ["❌ Failed to parse YouTube results."]
    return ["❌ No videos found."]
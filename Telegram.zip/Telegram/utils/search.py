
from .ddg_search import ddg_search

__all__ = ['ddg_search']

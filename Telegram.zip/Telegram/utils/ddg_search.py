import requests
from bs4 import BeautifulSoup

def ddg_search(query, max_results=5):
    try:
        headers = {
            "User-Agent": "Mozilla/5.0"
        }
        params = {
            "q": query,
            "kl": "us-en"  # English region
        }
        url = "https://html.duckduckgo.com/html"
        response = requests.post(url, data=params, headers=headers)

        if response.status_code != 200:
            return ["❌ Failed to fetch search results."]

        soup = BeautifulSoup(response.text, "html.parser")
        results = soup.find_all("a", {"class": "result__a"}, limit=max_results)

        output = []
        for tag in results:
            title = tag.get_text()
            link = tag.get("href")
            output.append(f"🔗 {title}\n{link}")

        return output if output else ["❌ No results found."]

    except Exception as e:
        return [f"❌ Error: {str(e)}"]
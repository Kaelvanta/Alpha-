import requests
from bs4 import BeautifulSoup

def google_search(query, num_results=3):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
    }
    search_url = f"https://www.google.com/search?q={query}&hl=en"

    response = requests.get(search_url, headers=headers)
    if response.status_code != 200:
        return ["❌ Google search failed."]

    soup = BeautifulSoup(response.text, 'html.parser')
    results = []

    for g in soup.find_all('div', class_='tF2Cxc')[:num_results]:
        title = g.find('h3')
        link = g.find('a')
        if title and link:
            results.append(f"{title.text.strip()}\n{link['href']}")

    return results if results else ["❌ No search results found."]
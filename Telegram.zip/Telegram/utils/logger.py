
"""
Logger utility for COREVANTA AI
Simple wrapper around the existing log_error function
"""
from memory import log_error as memory_log_error

def log_error(message):
    """Log error messages - wrapper for memory.log_error"""
    try:
        memory_log_error(message)
    except Exception as e:
        print(f"[LOGGER ERROR] {message} | Logger failure: {e}")

def log_info(message):
    """Log info messages"""
    try:
        print(f"[INFO] {message}")
    except:
        pass

def log_warning(message):
    """Log warning messages"""
    try:
        print(f"[WARNING] {message}")
    except:
        pass

def log_debug(message):
    """Log debug messages"""
    try:
        print(f"[DEBUG] {message}")
    except:
        pass

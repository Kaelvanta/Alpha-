import requests
from bs4 import BeautifulSoup

def fetch_reddit_posts(query, max_results=3):
    headers = {
        "User-Agent": "Mozilla/5.0"
    }
    url = f"https://www.reddit.com/search/?q={query}"

    try:
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            return ["❌ Failed to fetch Reddit posts."]

        soup = BeautifulSoup(response.text, "html.parser")
        results = []

        for link in soup.find_all("a", href=True):
            href = link['href']
            if href.startswith("/r/") and "/comments/" in href:
                title = link.text.strip()
                full_url = "https://www.reddit.com" + href
                if title:
                    results.append(f"🔸 {title}\n{full_url}")
                if len(results) >= max_results:
                    break

        return results if results else ["❌ No Reddit results found."]
    except Exception as e:
        return [f"❌ Error: {str(e)}"]

import requests
import json
from typing import List, Dict, Optional
from memory import log_error

class SerpAPISearchEngine:
    def __init__(self):
        self.api_key = "fada9077b049d353aed29fc4fec7b14cf9d4a928719df48177980a1ba1969708"
        self.base_url = "https://serpapi.com/search"
    
    def search(self, query: str, max_results: int = 8) -> List[Dict]:
        """Search using SerpAPI with comprehensive result extraction"""
        try:
            params = {
                "q": query,
                "api_key": self.api_key,
                "engine": "google",
                "gl": "us",
                "hl": "en",
                "num": max_results
            }
            
            response = requests.get(self.base_url, params=params, timeout=15)
            response.raise_for_status()
            
            data = response.json()
            results = []
            
            # Extract organic results
            organic_results = data.get("organic_results", [])
            for result in organic_results:
                results.append({
                    "title": result.get("title", ""),
                    "snippet": result.get("snippet", ""),
                    "url": result.get("link", ""),
                    "source": "Google (SerpAPI)",
                    "credibility": 0.9,
                    "type": "web_result"
                })
            
            # Extract featured snippet if available
            featured_snippet = data.get("featured_snippet")
            if featured_snippet:
                results.insert(0, {
                    "title": f"Featured: {featured_snippet.get('title', '')}",
                    "snippet": featured_snippet.get("snippet", ""),
                    "url": featured_snippet.get("link", ""),
                    "source": "Google Featured (SerpAPI)",
                    "credibility": 0.95,
                    "type": "featured_snippet"
                })
            
            # Extract knowledge graph if available
            knowledge_graph = data.get("knowledge_graph")
            if knowledge_graph:
                results.insert(0, {
                    "title": f"Knowledge: {knowledge_graph.get('title', '')}",
                    "snippet": knowledge_graph.get("description", ""),
                    "url": knowledge_graph.get("source", {}).get("link", ""),
                    "source": "Google Knowledge (SerpAPI)",
                    "credibility": 0.98,
                    "type": "knowledge_graph"
                })
            
            # Extract news results if available
            news_results = data.get("news_results", [])[:3]
            for news in news_results:
                results.append({
                    "title": news.get("title", ""),
                    "snippet": news.get("snippet", ""),
                    "url": news.get("link", ""),
                    "source": f"News - {news.get('source', 'Unknown')}",
                    "credibility": 0.85,
                    "type": "news_result",
                    "published": news.get("date", "")
                })
            
            return results[:max_results]
            
        except Exception as e:
            log_error(f"SerpAPI search failed: {e}")
            return []

# Global instance
serpapi_engine = SerpAPISearchEngine()

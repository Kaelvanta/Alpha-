import requests
from bs4 import BeautifulSoup

def fetch_lyrics(song_title):
    try:
        # Step 1: Search song on Genius
        query = song_title.replace(" ", "+")
        search_url = f"https://genius.com/search?q={query}"
        headers = {"User-Agent": "Mozilla/5.0"}

        search_response = requests.get(search_url, headers=headers)
        if search_response.status_code != 200:
            return "❌ Failed to search for the song."

        soup = BeautifulSoup(search_response.text, "html.parser")
        song_links = soup.select("a[href*='genius.com']")

        if not song_links:
            return "❌ No lyrics found for that song."

        # Step 2: Pick the first song result
        song_url = song_links[0]['href']
        song_response = requests.get(song_url, headers=headers)
        if song_response.status_code != 200:
            return "❌ Couldn't fetch the song page."

        soup = BeautifulSoup(song_response.text, "html.parser")
        lyrics_div = soup.find("div", class_="lyrics") or soup.select_one("div[class^='Lyrics__Container']")

        if not lyrics_div:
            return "❌ Lyrics section not found on page."

        lyrics = lyrics_div.get_text(separator="\n").strip()
        return lyrics if lyrics else "❌ Lyrics empty or failed to load."

    except Exception as e:
        return f"❌ Error fetching lyrics: {str(e)}"
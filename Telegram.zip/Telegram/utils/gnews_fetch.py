
import requests
import os
from typing import List, Dict, Optional
from datetime import datetime

def fetch_gnews_articles(query: str, lang: str = "en", max_results: int = 5) -> List[Dict]:
    """
    Fetch news articles from GNews API
    
    Args:
        query: Search query
        lang: Language code (default: en)
        max_results: Maximum number of articles to return
    
    Returns:
        List of article dictionaries
    """
    
    api_key = os.getenv("GNEWS_API_KEY")
    if not api_key:
        return [{"error": "GNews API key not configured"}]
    
    try:
        base_url = "https://gnews.io/api/v4/search"
        
        params = {
            "q": query,
            "lang": lang,
            "country": "us",
            "max": min(max_results, 10),  # GNews limits to 10 per request
            "apikey": api_key
        }
        
        response = requests.get(base_url, params=params, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        articles = data.get("articles", [])
        
        formatted_articles = []
        for article in articles:
            formatted_articles.append({
                "title": article.get("title", ""),
                "description": article.get("description", ""),
                "url": article.get("url", ""),
                "source": article.get("source", {}).get("name", "Unknown"),
                "published": article.get("publishedAt", ""),
                "image": article.get("image", ""),
                "content": article.get("content", "")[:200] + "..." if article.get("content") else ""
            })
        
        return formatted_articles
        
    except requests.exceptions.RequestException as e:
        return [{"error": f"GNews API request failed: {str(e)}"}]
    except Exception as e:
        return [{"error": f"GNews processing error: {str(e)}"}]

def fetch_top_headlines(category: str = "general", lang: str = "en") -> List[Dict]:
    """
    Fetch top headlines from GNews API
    
    Args:
        category: News category (general, world, nation, business, technology, entertainment, sports, science, health)
        lang: Language code
    
    Returns:
        List of headline dictionaries
    """
    
    api_key = os.getenv("GNEWS_API_KEY")
    if not api_key:
        return [{"error": "GNews API key not configured"}]
    
    try:
        base_url = "https://gnews.io/api/v4/top-headlines"
        
        params = {
            "category": category,
            "lang": lang,
            "country": "us",
            "max": 10,
            "apikey": api_key
        }
        
        response = requests.get(base_url, params=params, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        articles = data.get("articles", [])
        
        formatted_articles = []
        for article in articles:
            formatted_articles.append({
                "title": article.get("title", ""),
                "description": article.get("description", ""),
                "url": article.get("url", ""),
                "source": article.get("source", {}).get("name", "Unknown"),
                "published": article.get("publishedAt", ""),
                "category": category
            })
        
        return formatted_articles
        
    except requests.exceptions.RequestException as e:
        return [{"error": f"GNews headlines request failed: {str(e)}"}]
    except Exception as e:
        return [{"error": f"GNews headlines processing error: {str(e)}"}]


# 🚨 SECURITY ALERT - Hardcoded API Keys Found

## Critical Security Issue

**Location:** `keys.py` lines 78-81
**Risk:** HIGH - Hardcoded OpenRouter API keys

## Immediate Action Required

1. **REVOKE** all exposed API keys immediately:
   - Login to OpenRouter dashboard
   - Revoke all keys starting with `sk-or-v1-`
   - Generate new keys

2. **MOVE TO SECRETS:**
   - Open Replit Tools → Secrets
   - Add new secrets:
     - `OPENROUTER_API_KEY_1`: (new key)
     - `OPENROUTER_API_KEY_2`: (new key)
     - etc.

3. **UPDATE CODE:**
   - Replace hardcoded keys with `os.getenv()` calls
   - Test all functionality with new environment variables

## New Environment Variables Needed

For DeepSeek functionality:
- `AZURE_KEY`: Your Azure AI key
- `AZURE_ENDPOINT`: Azure endpoint URL  
- `AZURE_MODEL`: Model name (default: microsoft/Phi-4-reasoning)
- `ADMIN_TELEGRAM_ID`: Admin Telegram ID for telemetry

## Prevention

- Never commit secrets to code
- Use Replit Secrets for all API keys
- Regular security scans with tools like `git-secrets`

— Kael Vanta Security Team ®️
